
Use the following instructions to navigate through the rest of the files in this folder and  generate the language game: 

- Always start with the "opening" file and read through it sequentially.
- While reading, follow this syntax:
	- '(A)' for announcements
	- '(AH)' for alternate history
	- '(M)' for messages 
	- '(P)' for paths
	- '(Q)' for paths that are questions
	- '(T)' for input text boxes
	- '(C)' for conditions
	- '(PP)' for pass paths
	- '(FP)' for fail paths
- Render all text after these symbols as is, with the following effects:
	- message: typed in with blinking cursor
	- path: navigable option buttons 
	- announcement: ascii box with a monochrome icon (loudspeaker) and text inside
	- alternate history: ascii box with a monochrome icon (scroll) and text inside 
 - When you encounter a message, render it and wait for the player to continue.
- When you encounter double square brackets (e.g. [[example-text]]) inside a message, treat it as clickable/tappable text. When the player interacts with it, find its corresponding filename and render its content.  
- When you encounter a series of paths, render them as distinct buttons:
	- active: filename enclosed in double square brackets, e.g. [[path-file]]. 
		- render it as an active button, 
		- when clicked, read its contents to continue the game. 
	- inactive: filename not enclosed in double square brackets.
		- render it as a greyed out button,
		- cannot be clicked.
- When you encounter a path that is a question (Q), add a question-mark after rendering the text inside the button. Ensure that the button's navigability is not affected by this addition. 
- Each input text box (T) comes with a condition (C), a pass path (PP) and a fail path (FP). When you encounter T, follow these instructions:
	- render its text as you would a message 
	- add a box below the message for the player to input free text
	- compare the entered text to the condition; ensure that:
		- backend data is the source of truth for a condition to pass or fail
		- proper backend calls are used to determine whether a condition has passed or failed
	- if C passes continue with the pass path (PP) file, if it fails continue with the fail path (FP) file; note that: 
		- if either PP or FP have text enclosed within circular parentheses "()", it refers to data that must be read during the condition's backend call.
- End the game automatically when you:
	- find any error in the game flow, or
	- are done traversing a file, or
	- encounter an empty file. 


