- (AH) 989 days before the non-event, all active locations were hit with sleeper bombs. 
- (M) wake up
- (M) didn't you hear the siren?
	 - (P) [[not really]]
	 - (Q) [[what siren]]

 