- (AH) 989 days before the Non-Event
- (M) wake up
- (M) didn't you hear the siren?
	 - (P) [[not really]]
	 - (Q) [[what happened]]

 