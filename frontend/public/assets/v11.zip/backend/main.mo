import Map "mo:core/Map";
import List "mo:core/List";
import Nat "mo:core/Nat";
import Time "mo:core/Time";
import Array "mo:core/Array";
import Principal "mo:core/Principal";
import Runtime "mo:core/Runtime";
import Iter "mo:core/Iter";
import Order "mo:core/Order";
import Text "mo:core/Text";
import Bool "mo:core/Bool";
import UserApproval "user-approval/approval";
import AccessControl "authorization/access-control";
import Migration "migration";

(with migration = Migration.run) actor {
  public type NodeType = {
    #curation;
    #swarm;
    #annotation;
    #token;
  };

  public type RelationType = {
    #retrieval;
    #reasoning;
  };

  public type TokenType = {
    #positiveLaw;
    #interpretation;
    #link;
  };

  public type SwarmSummary = {
    id : Nat;
    title : Text;
    memberCount : Nat;
    createdAt : Time.Time;
    creator : Principal;
    isMember : Bool;
  };

  public type NodeId = Nat;
  public type RelationId = Nat;
  public type TokenId = Nat;

  public type VoteType = {
    #upvote;
    #downvote;
  };

  public type Token = {
    id : TokenId;
    name : Text;
    tokenType : TokenType;
    creator : Principal;
    createdAt : Time.Time;
    buzzValue : Nat;
    reuseCount : Nat;
    relatedAnnotations : [NodeId];
    immutable : Bool;
  };

  public type RDF = {
    id : Nat;
    subject : Text;
    predicate : Text;
    rdfObject : Text;
    creator : Principal;
    createdAt : Time.Time;
    cumulativeBuzz : Nat;
    originatingAnnotation : Nat;
  };

  public type Node = {
    id : NodeId;
    nodeType : NodeType;
    title : Text;
    bracketedTokenSequence : Text;
    parentId : ?NodeId;
    createdAt : Time.Time;
    owner : Principal;
    swarmId : ?NodeId;
    immutable : Bool;
    attributes : [(Text, Text)];
    upvotes : Nat;
    downvotes : Nat;
    verified : Bool;
    votes : [VoteRecord];
  };

  public type VoteRecord = {
    voter : Principal;
    voteType : VoteType;
    timestamp : Time.Time;
  };

  public type SwarmChatMessage = {
    sender : Principal;
    timestamp : Time.Time;
    content : Text;
  };

  public type LinkRelation = {
    id : Nat;
    sourceAnnotationId : Nat;
    targetAnnotationId : Nat;
    relationType : RelationType;
    relationName : Text;
    creator : Principal;
    createdAt : Time.Time;
    linkTokenId : Nat;
  };

  public type PlaceholderLinkRelation = {
    targetAnnotationId : Nat;
    relationName : Text;
    creator : Principal;
    createdAt : Time.Time;
  };

  public type Relation = {
    id : RelationId;
    sourceNodeId : NodeId;
    targetNodeId : NodeId;
    relationType : RelationType;
    relationStyle : RelationType;
    owner : Principal;
    createdAt : Time.Time;
  };

  public type GraphData = {
    nodes : [Node];
    tokens : [Token];
    relations : [(RelationId, Relation)];
    links : [LinkRelation];
    includesRelations : [(RelationId, Relation)];
  };

  public type CreateNodeInput = {
    title : Text;
    bracketedTokenSequence : Text;
    nodeType : NodeType;
    parentId : ?NodeId;
  };

  public type CreateRelationInput = {
    sourceNodeId : NodeId;
    targetNodeId : NodeId;
    relationType : RelationType;
  };

  public type UserProfile = {
    name : Text;
    owner : Principal;
    createdAt : Time.Time;
    socialUrl : Text;
  };

  public type CommonPoolTransaction = {
    amount : Nat;
    timestamp : Time.Time;
    sender : Principal;
  };

  public type CommonPoolBalance = {
    balance : Nat;
    transactions : [CommonPoolTransaction];
  };

  public type CreateNodeResult = {
    success : Bool;
    nodeId : ?NodeId;
  };

  public type CreateLinkRelationResult = {
    success : Bool;
    relationId : ?Nat;
    linkTokenId : ?Nat;
  };

  public type SwarmMetrics = {
    swarmId : NodeId;
    memberCount : Nat;
    annotationCount : Nat;
    totalBuzzEarned : Nat;
    isActive : Bool;
  };

  public type AutocompleteToken = {
    name : Text;
    buzzValue : Nat;
    relatedAnnotations : [NodeId];
  };

  public type AutocompleteRDF = {
    subject : Text;
    predicate : Text;
    rdfObject : Text;
    originatingAnnotation : Nat;
  };

  public type AutocompleteResults = {
    positiveLawTokens : [AutocompleteToken];
    interpretationTokens : [AutocompleteToken];
    linkTokens : [AutocompleteToken];
    rdfs : [AutocompleteRDF];
  };

  public type JoinRequest = {
    requester : Principal;
    swarmId : Nat;
    timestamp : Time.Time;
    approvers : [Principal];
  };

  public type JoinRequestStatus = {
    requester : Principal;
    swarmId : Nat;
    timestamp : Time.Time;
    approvers : [Principal];
    totalMembers : Nat;
    approvalsNeeded : Nat;
    percentageApproved : Nat;
  };

  public type PendingSwarmApproval = {
    annotationId : Nat;
    swarmId : Nat;
    requestingMember : Principal;
    requestedAt : Time.Time;
    approvalRequestedBy : Principal;
    hasVoted : Bool;
  };

  let accessControlState = AccessControl.initState();
  let approvalState = UserApproval.initState(accessControlState);
  let dailyBuzzRewards = Map.empty<Principal, Time.Time>();
  let buzzBalances = Map.empty<Principal, Nat>();

  var nextNodeId = 1;
  var nextLinkRelationId = 1;
  var nextRelationId = 1;
  var nextTokenId = 1;
  var nextTokenUniqueId = 1;
  var nextRDFId = 1;
  let maxTitleLength = 100;
  let maxSwarmMemberships = 4;
  let dailyBuzzRewardAmount = 100;

  let nodes = Map.empty<Nat, Node>();
  let relations = Map.empty<Nat, Relation>();
  let userProfiles = Map.empty<Principal, UserProfile>();
  let swarmMembers = Map.empty<Nat, List.List<Principal>>();
  let swarmChatMessages = Map.empty<Nat, List.List<SwarmChatMessage>>();
  let tokens = Map.empty<Text, Token>();
  let rdfs = Map.empty<Nat, RDF>();

  let linkRelations = Map.empty<Nat, LinkRelation>();
  let placeholderLinkRelations = Map.empty<Principal, List.List<PlaceholderLinkRelation>>();

  module UserTokenTuple {
    public func compare(a : (Principal, Text), b : (Principal, Text)) : Order.Order {
      let principalOrder = Principal.compare(a.0, b.0);
      if (principalOrder != #equal) { return principalOrder };
      Text.compare(a.1, b.1);
    };
  };

  let userLocalTokenNodes = Map.empty<(Principal, Text), NodeId>();

  module VoteTuple {
    public func compare(a : (Principal, Nat), b : (Principal, Nat)) : Order.Order {
      let principalOrder = Principal.compare(a.0, b.0);
      if (principalOrder != #equal) { return principalOrder };
      Nat.compare(a.1, b.1);
    };
  };

  let userVotes = Map.empty<(Principal, Nat), VoteType>();

  let joinRequests = Map.empty<Text, JoinRequest>();
  let pendingSwarmApprovals = Map.empty<Text, PendingSwarmApproval>();

  var commonPoolState : CommonPoolBalance = {
    balance = 0;
    transactions = [];
  };

  public shared ({ caller }) func initializeAccessControl() : async () {
    AccessControl.initialize(accessControlState, caller);
  };

  public query ({ caller }) func getCallerUserRole() : async AccessControl.UserRole {
    AccessControl.getUserRole(accessControlState, caller);
  };

  public shared ({ caller }) func assignCallerUserRole(user : Principal, role : AccessControl.UserRole) : async () {
    AccessControl.assignRole(accessControlState, caller, user, role);
  };

  public query ({ caller }) func isCallerAdmin() : async Bool {
    AccessControl.isAdmin(accessControlState, caller);
  };

  public query ({ caller }) func isCallerApproved() : async Bool {
    AccessControl.hasPermission(accessControlState, caller, #admin) or UserApproval.isApproved(approvalState, caller);
  };

  public shared ({ caller }) func requestApproval() : async () {
    UserApproval.requestApproval(approvalState, caller);
  };

  public shared ({ caller }) func setApproval(user : Principal, status : UserApproval.ApprovalStatus) : async () {
    // AUTHORIZATION: Admin-only
    if (not (AccessControl.hasPermission(accessControlState, caller, #admin))) {
      Runtime.trap("Unauthorized: Only admins can perform this action");
    };
    UserApproval.setApproval(approvalState, user, status);
  };

  public query ({ caller }) func listApprovals() : async [UserApproval.UserApprovalInfo] {
    // AUTHORIZATION: Admin-only
    if (not (AccessControl.hasPermission(accessControlState, caller, #admin))) {
      Runtime.trap("Unauthorized: Only admins can perform this action");
    };
    UserApproval.listApprovals(approvalState);
  };

  public query ({ caller }) func getCallerUserProfile() : async ?UserProfile {
    // AUTHORIZATION: User-level access required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can access profiles");
    };
    userProfiles.get(caller);
  };

  public query ({ caller }) func getUserProfile(user : Principal) : async ?UserProfile {
    // AUTHORIZATION: Users can view their own profile, admins can view any profile
    if (caller != user and not AccessControl.isAdmin(accessControlState, caller)) {
      Runtime.trap("Unauthorized: Can only view your own profile");
    };
    userProfiles.get(user);
  };

  public shared ({ caller }) func saveCallerUserProfile(name : Text, socialUrl : Text) : async Bool {
    // AUTHORIZATION: User-level permission required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only users can save profiles");
    };

    if (name.size() == 0 or name.size() > 100) {
      Runtime.trap("Invalid name: must be non-empty and ≤ 100 characters");
    };

    if (not (socialUrl.startsWith(#text "http://") or socialUrl.startsWith(#text "https://"))) {
      Runtime.trap("Invalid social URL: must begin with http:// or https://");
    };

    let profile : UserProfile = {
      name = name;
      owner = caller;
      createdAt = Time.now();
      socialUrl = socialUrl;
    };

    userProfiles.add(caller, profile);
    true;
  };

  public shared ({ caller }) func claimDailyReward() : async Bool {
    // AUTHORIZATION: User-level permission required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only authenticated users can claim daily rewards");
    };

    let now = Time.now();
    let lastReward = dailyBuzzRewards.get(caller);

    switch (lastReward) {
      case (?timestamp) {
        let timeSinceLastReward = now - timestamp;
        let oneDayInNanoseconds = 24 * 60 * 60 * 1_000_000_000;

        if (timeSinceLastReward < oneDayInNanoseconds) {
          return false;
        };
      };
      case (null) {};
    };

    let currentBalance = switch (buzzBalances.get(caller)) {
      case (?balance) { balance };
      case (null) { 0 };
    };

    buzzBalances.add(caller, currentBalance + dailyBuzzRewardAmount);
    dailyBuzzRewards.add(caller, now);
    true;
  };

  public query ({ caller }) func getCallerBuzzBalance() : async Nat {
    // AUTHORIZATION: User-level access required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only authenticated users can access BUZZ balance");
    };

    switch (buzzBalances.get(caller)) {
      case (?balance) { balance };
      case (null) { 0 };
    };
  };

  private func isSwarmMember(swarmId : Nat, user : Principal) : Bool {
    switch (swarmMembers.get(swarmId)) {
      case (?members) {
        members.any(func(member) { member == user });
      };
      case (null) { false };
    };
  };

  private func isSwarmCreator(swarmId : Nat, user : Principal) : Bool {
    switch (nodes.get(swarmId)) {
      case (?node) {
        node.owner == user;
      };
      case (null) { false };
    };
  };

  public shared ({ caller }) func createNode(input : CreateNodeInput) : async CreateNodeResult {
    // AUTHORIZATION: User-level permission required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only authenticated users can create nodes");
    };

    if (input.title.size() == 0 or input.title.size() > maxTitleLength) {
      Runtime.trap("Invalid title: must be non-empty and ≤ 100 characters");
    };

    // AUTHORIZATION: Validate parent-child relationships and access
    switch (input.parentId) {
      case (?parentId) {
        switch (nodes.get(parentId)) {
          case (?parentNode) {
            // Validate hierarchy: Curation → Swarm → Annotation
            switch (parentNode.nodeType, input.nodeType) {
              case (#curation, #swarm) {};
              case (#swarm, #annotation) {
                // AUTHORIZATION: Only swarm members can create annotations
                if (not isSwarmMember(parentId, caller) and not isSwarmCreator(parentId, caller)) {
                  Runtime.trap("Unauthorized: Only swarm members can create annotations");
                };
              };
              case _ {
                Runtime.trap("Invalid parent-child relationship");
              };
            };
          };
          case (null) {
            Runtime.trap("Parent node does not exist");
          };
        };
      };
      case (null) {
        // Only curations can be created without a parent
        if (input.nodeType != #curation) {
          Runtime.trap("Only curations can be created without a parent");
        };
      };
    };

    // For annotations, validate BUZZ balance
    if (input.nodeType == #annotation) {
      let cumulativeBuzz = calculateAnnotationCost(input.bracketedTokenSequence);
      let currentBalance = switch (buzzBalances.get(caller)) {
        case (?balance) { balance };
        case (null) { 0 };
      };

      if (currentBalance < cumulativeBuzz) {
        Runtime.trap("Insufficient BUZZ balance to create this annotation.");
      } else {
        buzzBalances.add(caller, currentBalance - cumulativeBuzz);
      };
    };

    let nodeId = nextNodeId;
    nextNodeId += 1;

    let node : Node = {
      id = nodeId;
      nodeType = input.nodeType;
      title = input.title;
      bracketedTokenSequence = input.bracketedTokenSequence;
      parentId = input.parentId;
      createdAt = Time.now();
      owner = caller;
      swarmId = if (input.nodeType == #annotation) { input.parentId } else { null };
      immutable = false;
      attributes = [];
      upvotes = 0;
      downvotes = 0;
      verified = false;
      votes = [];
    };

    nodes.add(nodeId, node);

    // Auto-add creator as swarm member for swarm nodes
    if (input.nodeType == #swarm) {
      let membersList = List.empty<Principal>();
      swarmMembers.add(nodeId, membersList);
    };

    { success = true; nodeId = ?nodeId };
  };

  private func calculateAnnotationCost(content : Text) : Nat {
    // Simplified calculation - in real implementation, parse tokens and sum their BUZZ values
    // For now, return a base cost
    25;
  };

  public shared ({ caller }) func requestToJoinSwarm(swarmId : Nat) : async Bool {
    // AUTHORIZATION: User-level permission required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only authenticated users can request to join swarms");
    };

    // Verify swarm exists
    switch (nodes.get(swarmId)) {
      case (?node) {
        if (node.nodeType != #swarm) {
          Runtime.trap("Node is not a swarm");
        };
      };
      case (null) {
        Runtime.trap("Swarm does not exist");
      };
    };

    // Check if already a member
    if (isSwarmMember(swarmId, caller)) {
      Runtime.trap("Already a member of this swarm");
    };

    // Check if already has a pending request
    let requestKey = caller.toText().concat("-").concat(swarmId.toText());
    switch (joinRequests.get(requestKey)) {
      case (?_) {
        Runtime.trap("Join request already pending");
      };
      case (null) {};
    };

    let request : JoinRequest = {
      requester = caller;
      swarmId = swarmId;
      timestamp = Time.now();
      approvers = [];
    };

    joinRequests.add(requestKey, request);
    true;
  };

  public shared ({ caller }) func approveJoinRequest(requester : Principal, swarmId : Nat) : async Bool {
    // AUTHORIZATION: Only swarm members can approve join requests
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only authenticated users can approve join requests");
    };

    if (not isSwarmMember(swarmId, caller) and not isSwarmCreator(swarmId, caller)) {
      Runtime.trap("Unauthorized: Only swarm members can approve join requests");
    };

    let requestKey = requester.toText().concat("-").concat(swarmId.toText());

    switch (joinRequests.get(requestKey)) {
      case (?request) {
        // Check if caller already approved
        let alreadyApproved = Array.fromIter(request.approvers.vals()).any(
          func(approver) { approver == caller }
        );

        if (alreadyApproved) {
          Runtime.trap("You have already approved this request");
        };

        let updatedApprovers = request.approvers.concat([caller]);
        let updatedRequest : JoinRequest = {
          requester = request.requester;
          swarmId = request.swarmId;
          timestamp = request.timestamp;
          approvers = updatedApprovers;
        };

        joinRequests.add(requestKey, updatedRequest);

        // Check if >50% approval reached
        let totalMembers = switch (swarmMembers.get(swarmId)) {
          case (?members) { members.size() };
          case (null) { 0 };
        };

        let approvalsNeeded = (totalMembers / 2) + 1;

        if (updatedApprovers.size() >= approvalsNeeded) {
          // Add requester to swarm members
          switch (swarmMembers.get(swarmId)) {
            case (?_) {};
            case (null) {
              let newMembers = List.empty<Principal>();
              swarmMembers.add(swarmId, newMembers); // Initialize as empty list
            };
          };

          // Remove join request
          joinRequests.remove(requestKey);
        };

        true;
      };
      case (null) {
        Runtime.trap("Join request not found");
      };
    };
  };

  public shared ({ caller }) func upvoteAnnotation(annotationId : Nat) : async () {
    // AUTHORIZATION: User-level permission required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only authenticated users can vote");
    };

    switch (nodes.get(annotationId)) {
      case (?node) {
        if (node.nodeType != #annotation) {
          Runtime.trap("Node is not an annotation");
        };

        // AUTHORIZATION: Creators cannot vote on their own annotations
        if (node.owner == caller) {
          Runtime.trap("Annotation creators cannot vote on their own annotations");
        };

        // AUTHORIZATION: Only swarm members can vote
        switch (node.swarmId) {
          case (?swarmId) {
            if (not isSwarmMember(swarmId, caller) and not isSwarmCreator(swarmId, caller)) {
              Runtime.trap("Unauthorized: Only swarm members can vote");
            };
          };
          case (null) {
            Runtime.trap("Annotation is not associated with a swarm");
          };
        };

        // Check if user already voted
        let voteKey = (caller, annotationId);
        switch (userVotes.get(voteKey)) {
          case (?_) {
            Runtime.trap("You have already voted on this annotation");
          };
          case (null) {};
        };

        // Record vote
        userVotes.add(voteKey, #upvote);

        let voteRecord : VoteRecord = {
          voter = caller;
          voteType = #upvote;
          timestamp = Time.now();
        };

        let updatedNode : Node = {
          id = node.id;
          nodeType = node.nodeType;
          title = node.title;
          bracketedTokenSequence = node.bracketedTokenSequence;
          parentId = node.parentId;
          createdAt = node.createdAt;
          owner = node.owner;
          swarmId = node.swarmId;
          immutable = node.immutable;
          attributes = node.attributes;
          upvotes = node.upvotes + 1;
          downvotes = node.downvotes;
          verified = (node.upvotes + 1) > node.downvotes;
          votes = node.votes.concat([voteRecord]);
        };

        nodes.add(annotationId, updatedNode);
      };
      case (null) {
        Runtime.trap("Annotation not found");
      };
    };
  };

  public shared ({ caller }) func downvoteAnnotation(annotationId : Nat) : async () {
    // AUTHORIZATION: User-level permission required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only authenticated users can vote");
    };

    switch (nodes.get(annotationId)) {
      case (?node) {
        if (node.nodeType != #annotation) {
          Runtime.trap("Node is not an annotation");
        };

        // AUTHORIZATION: Creators cannot vote on their own annotations
        if (node.owner == caller) {
          Runtime.trap("Annotation creators cannot vote on their own annotations");
        };

        // AUTHORIZATION: Only swarm members can vote
        switch (node.swarmId) {
          case (?swarmId) {
            if (not isSwarmMember(swarmId, caller) and not isSwarmCreator(swarmId, caller)) {
              Runtime.trap("Unauthorized: Only swarm members can vote");
            };
          };
          case (null) {
            Runtime.trap("Annotation is not associated with a swarm");
          };
        };

        // Check if user already voted
        let voteKey = (caller, annotationId);
        switch (userVotes.get(voteKey)) {
          case (?_) {
            Runtime.trap("You have already voted on this annotation");
          };
          case (null) {};
        };

        // Record vote
        userVotes.add(voteKey, #downvote);

        let voteRecord : VoteRecord = {
          voter = caller;
          voteType = #downvote;
          timestamp = Time.now();
        };

        let updatedNode : Node = {
          id = node.id;
          nodeType = node.nodeType;
          title = node.title;
          bracketedTokenSequence = node.bracketedTokenSequence;
          parentId = node.parentId;
          createdAt = node.createdAt;
          owner = node.owner;
          swarmId = node.swarmId;
          immutable = node.immutable;
          attributes = node.attributes;
          upvotes = node.upvotes;
          downvotes = node.downvotes + 1;
          verified = node.upvotes > (node.downvotes + 1);
          votes = node.votes.concat([voteRecord]);
        };

        nodes.add(annotationId, updatedNode);
      };
      case (null) {
        Runtime.trap("Annotation not found");
      };
    };
  };

  public query ({ caller }) func getGraphData() : async GraphData {
    // AUTHORIZATION: User-level access required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only authenticated users can access graph data");
    };

    let nodesArray = Array.fromIter(nodes.values());
    let tokensArray = Array.fromIter(tokens.values());
    let relationsArray = relations.toArray();
    let linksArray = Array.fromIter(linkRelations.values());
    let includesRelationsArray = relations.toArray();

    {
      nodes = nodesArray;
      tokens = tokensArray;
      relations = relationsArray;
      links = linksArray;
      includesRelations = includesRelationsArray;
    };
  };

  public query ({ caller }) func getAllSwarmSummaries() : async [SwarmSummary] {
    // AUTHORIZATION: User-level access required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Runtime.trap("Unauthorized: Only authenticated users can access swarm summaries");
    };

    // Only include Nodes of type Swarm for swarm summaries
    let swarmNodes = Array.fromIter(
      nodes.values()
    ).filter(
      func(node) {
        switch (node.nodeType) {
          case (#swarm) { true };
          case (_) { false };
        };
      }
    );

    swarmNodes.map(
      func(node) {
        let memberCount = switch (swarmMembers.get(node.id)) {
          case (?members) { members.size() };
          case (null) { 0 };
        };

        let isMember = switch (swarmMembers.get(node.id)) {
          case (?members) { members.any(func(member) { member == caller }) };
          case (null) { false };
        };

        {
          id = node.id;
          title = node.title;
          memberCount;
          createdAt = node.createdAt;
          creator = node.owner;
          isMember;
        };
      }
    );
  };

  public shared ({ caller }) func resetAllData() : async () {
    // AUTHORIZATION: Admin-only
    if (not (AccessControl.hasPermission(accessControlState, caller, #admin))) {
      Runtime.trap("Unauthorized: Only admins can reset data");
    };

    // Clear all data structures
    for ((key, _) in nodes.entries()) {
      nodes.remove(key);
    };
    for ((key, _) in relations.entries()) {
      relations.remove(key);
    };
    for ((key, _) in tokens.entries()) {
      tokens.remove(key);
    };
    for ((key, _) in rdfs.entries()) {
      rdfs.remove(key);
    };
    for ((key, _) in swarmMembers.entries()) {
      swarmMembers.remove(key);
    };
    for ((key, _) in linkRelations.entries()) {
      linkRelations.remove(key);
    };
    for ((key, _) in joinRequests.entries()) {
      joinRequests.remove(key);
    };
    for ((key, _) in userVotes.entries()) {
      userVotes.remove(key);
    };

    // Reset counters
    nextNodeId := 1;
    nextRelationId := 1;
    nextTokenId := 1;
    nextRDFId := 1;
    nextLinkRelationId := 1;
  };
};
