import HashMap "mo:base/HashMap";
import Principal "mo:base/Principal";
import Nat "mo:base/Nat";
import Debug "mo:base/Debug";
import Time "mo:base/Time";
import Array "mo:base/Array";
import Iter "mo:base/Iter";
import AccessControl "authorization/access-control";

actor FleaMarket {
  public type PublishedRDF = {
    id : Nat;
    creator : Principal;
    rdfId : Nat;
    tokenIds : [Nat];
    price : Nat;
    published : Bool;
    buyer : ?Principal;
    createdAt : Time.Time;
  };

  let publishedRDFs = HashMap.HashMap<Nat, PublishedRDF>(10, Nat.equal, func(n: Nat) : Nat32 { Nat32.fromNat(n) });
  var nextListingId : Nat = 1;

  let accessControlState = AccessControl.initState();

  stable var mainCanisterPrincipal : ?Principal = null;
  stable var buzzCanisterPrincipal : ?Principal = null;
  stable var initialized : Bool = false;

  type MainCanisterInterface = actor {
    verifyRDFOwnership : shared (caller : Principal, rdfId : Nat) -> async Bool;
    lockRDF : shared (caller : Principal, rdfId : Nat) -> async ();
    transferRDFOwnership : shared (rdfId : Nat, newOwner : Principal) -> async ();
  };

  type BuzzCanisterInterface = actor {
    balanceOf : query (principal : Principal) -> async Nat;
    transfer : shared (from : Principal, to : Principal, amount : Nat) -> async ();
  };

  public shared ({ caller }) func initializeAccessControl() : async () {
    AccessControl.initialize(accessControlState, caller);
  };

  public query ({ caller }) func getCallerUserRole() : async AccessControl.UserRole {
    AccessControl.getUserRole(accessControlState, caller);
  };

  public shared ({ caller }) func assignCallerUserRole(user : Principal, role : AccessControl.UserRole) : async () {
    // AUTHORIZATION: Admin-only (checked inside AccessControl.assignRole)
    AccessControl.assignRole(accessControlState, caller, user, role);
  };

  public query ({ caller }) func isCallerAdmin() : async Bool {
    AccessControl.isAdmin(accessControlState, caller);
  };

  public shared ({ caller }) func initialize(mainCanister : Principal, buzzCanister : Principal) : async () {
    // AUTHORIZATION: Admin-only
    if (not (AccessControl.hasPermission(accessControlState, caller, #admin))) {
      Debug.trap("Unauthorized: Only admins can initialize Flea Market canister");
    };

    if (initialized) {
      Debug.trap("Flea Market canister already initialized");
    };

    mainCanisterPrincipal := ?mainCanister;
    buzzCanisterPrincipal := ?buzzCanister;
    initialized := true;
  };

  public shared ({ caller }) func publishRDF(rdfId : Nat, tokenIds : [Nat], price : Nat) : async Nat {
    // AUTHORIZATION: User-level permission required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Debug.trap("Unauthorized: Only authenticated users can publish RDFs");
    };

    // AUTHORIZATION: Verify inter-canister initialization
    if (not initialized) {
      Debug.trap("Flea Market canister not initialized");
    };

    if (price == 0) {
      Debug.trap("Price must be greater than zero");
    };

    // AUTHORIZATION: Verify caller owns the RDF in main canister
    let mainCanister : MainCanisterInterface = switch (mainCanisterPrincipal) {
      case (?principal) { actor (Principal.toText(principal)) };
      case (null) { Debug.trap("Main canister principal not set") };
    };

    let ownsRDF = await mainCanister.verifyRDFOwnership(caller, rdfId);
    if (not ownsRDF) {
      Debug.trap("Unauthorized: Caller does not own the specified RDF");
    };

    await mainCanister.lockRDF(caller, rdfId);

    let listing : PublishedRDF = {
      id = nextListingId;
      creator = caller;
      rdfId = rdfId;
      tokenIds = tokenIds;
      price = price;
      published = true;
      buyer = null;
      createdAt = Time.now();
    };

    publishedRDFs.put(nextListingId, listing);
    let listingId = nextListingId;
    nextListingId += 1;

    listingId;
  };

  public shared ({ caller }) func purchaseRDF(listingId : Nat) : async () {
    // AUTHORIZATION: User-level permission required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Debug.trap("Unauthorized: Only authenticated users can purchase RDFs");
    };

    // AUTHORIZATION: Verify inter-canister initialization
    if (not initialized) {
      Debug.trap("Flea Market canister not initialized");
    };

    let listing = switch (publishedRDFs.get(listingId)) {
      case (?listing) { listing };
      case (null) { Debug.trap("Listing does not exist") };
    };

    if (not listing.published) {
      Debug.trap("Listing is not available for purchase");
    };

    switch (listing.buyer) {
      case (?_) { Debug.trap("Listing has already been purchased") };
      case (null) {};
    };

    // AUTHORIZATION: Ensure buyer is not seller
    if (caller == listing.creator) {
      Debug.trap("Cannot purchase your own listing");
    };

    let buzzCanister : BuzzCanisterInterface = switch (buzzCanisterPrincipal) {
      case (?principal) { actor (Principal.toText(principal)) };
      case (null) { Debug.trap("Buzz canister principal not set") };
    };

    let buyerBalance = await buzzCanister.balanceOf(caller);
    if (buyerBalance < listing.price) {
      Debug.trap("Insufficient BUZZ balance to purchase RDF");
    };

    await buzzCanister.transfer(caller, listing.creator, listing.price);

    let mainCanister : MainCanisterInterface = switch (mainCanisterPrincipal) {
      case (?principal) { actor (Principal.toText(principal)) };
      case (null) { Debug.trap("Main canister principal not set") };
    };

    await mainCanister.transferRDFOwnership(listing.rdfId, caller);

    let updatedListing : PublishedRDF = {
      id = listing.id;
      creator = listing.creator;
      rdfId = listing.rdfId;
      tokenIds = listing.tokenIds;
      price = listing.price;
      published = listing.published;
      buyer = ?caller;
      createdAt = listing.createdAt;
    };

    publishedRDFs.put(listingId, updatedListing);
  };

  public query ({ caller }) func getListing(listingId : Nat) : async ?PublishedRDF {
    // AUTHORIZATION: User-level permission required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Debug.trap("Unauthorized: Only authenticated users can query listings");
    };

    publishedRDFs.get(listingId);
  };

  public query ({ caller }) func getAllListings() : async [PublishedRDF] {
    // AUTHORIZATION: User-level permission required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Debug.trap("Unauthorized: Only authenticated users can query listings");
    };

    let listingsBuffer = Array.init<?PublishedRDF>(publishedRDFs.size(), null);
    var count = 0;
    
    for ((_, listing) in publishedRDFs.entries()) {
      if (listing.published and listing.buyer == null) {
        listingsBuffer[count] := ?listing;
        count += 1;
      };
    };

    let listings = Array.init<PublishedRDF>(count, {
      id = 0;
      creator = caller;
      rdfId = 0;
      tokenIds = [];
      price = 0;
      published = false;
      buyer = null;
      createdAt = Time.now();
    });

    var i = 0;
    while (i < count) {
      switch (listingsBuffer[i]) {
        case (?listing) { listings[i] := listing };
        case (null) {};
      };
      i += 1;
    };

    Array.freeze(listings);
  };

  public query ({ caller }) func getListingsByCreator(creator : Principal) : async [PublishedRDF] {
    // AUTHORIZATION: User-level permission required
    if (not (AccessControl.hasPermission(accessControlState, caller, #user))) {
      Debug.trap("Unauthorized: Only authenticated users can query listings");
    };

    let listingsBuffer = Array.init<?PublishedRDF>(publishedRDFs.size(), null);
    var count = 0;
    
    for ((_, listing) in publishedRDFs.entries()) {
      if (listing.creator == creator) {
        listingsBuffer[count] := ?listing;
        count += 1;
      };
    };

    let listings = Array.init<PublishedRDF>(count, {
      id = 0;
      creator = caller;
      rdfId = 0;
      tokenIds = [];
      price = 0;
      published = false;
      buyer = null;
      createdAt = Time.now();
    });

    var i = 0;
    while (i < count) {
      switch (listingsBuffer[i]) {
        case (?listing) { listings[i] := listing };
        case (null) {};
      };
      i += 1;
    };

    Array.freeze(listings);
  };
}
