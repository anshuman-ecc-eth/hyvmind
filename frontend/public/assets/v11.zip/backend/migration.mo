import Map "mo:core/Map";
import Principal "mo:core/Principal";
import Nat "mo:core/Nat";

module {
  type OldActor = {
    buzzBalances : Map.Map<Principal, Nat>;
  };

  type NewActor = {
    buzzBalances : Map.Map<Principal, Nat>;
  };

  public func run(old : OldActor) : NewActor {
    old;
  };
};
