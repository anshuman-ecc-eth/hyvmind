# Hyvmind

## Overview
Hyvmind is a hierarchical knowledge management application that allows users to create and visualize interconnected nodes in a structured graph format. The application supports four types of nodes (Curation, Swarm, Annotation, Token) with defined relationships and automatic token extraction capabilities. The system includes an internal BUZZ system with daily rewards, annotation creation costs with BUZZ deduction, swarm activity tracking, swarm membership management with join-approval system, annotation voting system for content verification with creator self-voting restrictions, global-to-local token synchronization with BUZZ inheritance, strict RDF triple extraction and management with enforced validation and dynamic BUZZ calculation, user profile management with mandatory social URL and login functionality, persistent BUZZ balance display in the main interface, hierarchical includes relations for structural organization, hierarchical node creation interface with proper parent-child relationships, comprehensive data reset functionality for clean environment initialization, proper token visibility in TreeView with functional link annotation creation, restored Add Link button functionality in Create Annotation dialog, strict RDF validation with enforced token ordering for structured reasoning connections, corrected interpretation token linking to prevent redundant annotation connections, enhanced TreeView token type display with clear visual labels, D3.js-based interactive graph visualization with stable layout and enhanced link token styling, redesigned My Swarms interface with comprehensive join-approval workflow management, phase-1 post-approval workflow for new swarm members with full access and upvote confirmation dialogs, and stabilized swarm membership visibility with full access rights for approved members.

## Core Features

### Stabilized Backend Public Interface
- **Permanent Method Exposure**: Backend permanently exposes and preserves the following public interface methods in `main.mo` with locked definitions that cannot be accidentally overwritten in subsequent builds
- **createNode Method**: `public shared func createNode(input: CreateNodeInput) : async CreateNodeResult` - handles creation for curations, swarms, and annotations with correct hierarchy validation, maintains proper parent-child relationships, validates access permissions, includes null-guards and AccessControl initialization to prevent Runtime.trap on anonymous or uninitialized callers
- **getGraphData Method**: `public query func getGraphData() : async GraphData` - returns GraphData including nodes, tokens, and relations required for Tree View and Graph View with all token types, hierarchical includes relations, link tokens as actual node entries, and full access integration for approved swarm members
- **getAllSwarmSummaries Method**: `public query func getAllSwarmSummaries() : async [SwarmSummary]` - returns array of SwarmSummary objects for My Swarms tab with all available swarms, membership status, member counts, and join request information
- **requestToJoinSwarm Method**: `public shared func requestToJoinSwarm(swarmId: Nat) : async Bool` - initiates membership approval process requiring over 50% approval from existing swarm members
- **getCallerBuzzBalance Method**: `public query func getCallerBuzzBalance() : async Nat` - returns current BUZZ balance for authenticated caller enabling real-time balance display in frontend
- **Frontend Type Alignment**: All method signatures match exactly what the frontend expects with return types aligned with `types.ts` definitions
- **Swarm Join Logic Verification**: Only swarm creators are automatically added as members at swarm creation; all other users including curation creators must go through the 50% approval process to join swarms
- **Method Definition Locking**: These method definitions are locked and preserved to prevent accidental overwrites in subsequent builds
- **Frontend Query Compatibility**: All existing frontend queries (Tree View, Graph View, My Swarms, BUZZ balance displays) load normally using these exposed functions

### Backend Stability and Connectivity Patch
- **Core Query Exposure**: Backend explicitly declares and publicly exposes essential queries and mutations for frontend connectivity
- **Public Method Declaration**: `createNode` function publicly exposed as shared function handling creation for curations, swarms, and annotations with correct hierarchy validation
- **Swarm Summary Query**: `getAllSwarmSummaries` publicly exposed as query function returning array of SwarmSummary objects for My Swarms tab
- **Graph Data Query**: `getGraphData` publicly exposed as query function returning GraphData including nodes, tokens, and relations for Tree View and Graph View
- **BUZZ Balance Query**: `getCallerBuzzBalance` publicly exposed as query function retrieving calling user's current BUZZ balance
- **Join Request Function**: `requestToJoinSwarm` publicly exposed as shared function initiating membership approval process requiring over 50% approval from existing swarm members
- **Interface Compatibility**: All public functions have return types aligned with frontend expectations (CreateNodeResult, [SwarmSummary], GraphData, and Nat)
- **Stability Guarantees**: Null-guards and AccessControl initialization added to prevent Runtime.trap on anonymous or uninitialized callers
- **Preserved Logic**: All immutable structures, BUZZ calculations, and hierarchy rules (Curation → Swarm → Annotation → Token) remain intact

### Corrected Swarm Joining Privileges
- **Creator Auto-Membership**: Only swarm creators are automatically added as members at swarm creation
- **Universal Approval Process**: All other users, including curation creators, must go through the 50% approval process to join swarms
- **Membership Validation**: System enforces that non-creators cannot bypass the approval workflow regardless of their role in parent curations
- **Access Control Consistency**: Swarm membership privileges are consistently applied across all user types except the original swarm creator

### User Profile Management
- **Profile Registration**: Users can create and update their profiles with name and mandatory social URL
- **Profile Validation**: Name validation (non-empty, ≤ 100 characters) and social URL format checking (must begin with http:// or https://)
- **Mandatory Social URL**: Social URL field is required during profile creation and must be provided
- **Login Functionality**: Frontend login system integrated with backend user profile storage
- **Profile Storage**: User profiles stored in backend with caller principal as key, including mandatory social URL

### BUZZ Balance Display
- **Persistent Balance Label**: Main app interface displays user's current BUZZ balance in "BUZZ: <number>" format
- **Strategic Positioning**: Balance label positioned between theme toggle and profile button in top-right corner
- **Live Data Integration**: Balance pulls real-time data from backend using `getCallerBuzzBalance` query
- **Automatic Updates**: Balance updates automatically on login, annotation creation, and daily reward claims
- **Cross-Tab Visibility**: Balance label remains visible across all main authenticated app tabs
- **Theme Consistency**: Balance label styling adapts to current theme (dark/light mode)
- **Cache Invalidation**: Balance data refreshes when relevant BUZZ transactions occur

### Daily BUZZ Reward System
- **Daily Login Rewards**: Authenticated users receive 100 BUZZ once every 24 hours during login
- **Timestamp Tracking**: System stores last reward timestamp per user to prevent abuse
- **Single Session Claim**: Frontend claim process only calls `claimDailyReward()` once per user session to prevent duplicate toasts
- **Duplicate Prevention**: System avoids redundant polling or reconnection triggers that could cause multiple reward claims
- **Reward Prevention**: Users cannot claim multiple rewards within 24-hour periods

### Annotation Creation Cost System
- **BUZZ Deduction**: Annotation creation automatically deducts BUZZ equal to the annotation's cumulative BUZZ (sum of associated token weights) from the creator's balance
- **Accurate Cumulative Calculation**: System calculates cumulative BUZZ weight as the sum of all BUZZ (weight) values of tokens associated with the annotation, including positive law, interpretation, and link tokens
- **Balance Validation**: System checks if creator has sufficient BUZZ before allowing annotation creation
- **Error Handling**: If insufficient BUZZ balance exists, annotation creation traps gracefully with clear error message "Insufficient BUZZ balance to create this annotation."
- **Balance Updates**: Upon successful annotation creation with sufficient balance, the deducted amount is removed from user's BUZZ balance and updated balance is returned
- **Real-Time Synchronization**: BUZZ balance immediately reflects deductions and synchronizes with frontend BUZZ label after each annotation creation
- **Negative Balance Prevention**: System prevents BUZZ balances from going negative through pre-creation validation
- **Proper Deduction Logic**: Backend validates user's current BUZZ balance against required cumulative BUZZ cost before finalizing annotation creation
- **Clean State Testing**: System supports testing scenarios where users with specific BUZZ amounts (e.g., 100 BUZZ) create annotations with calculated costs (e.g., 25 BUZZ from 5 tokens at 5 BUZZ each) resulting in precise balance reductions (e.g., 75 BUZZ remaining)

### Node Types and Relationships
- **Curation Nodes**: Top-level organizational containers
- **Swarm Nodes**: Collaborative workspaces with membership management and join-approval system
- **Annotation Nodes**: Content containers with token and RDF extraction, requiring BUZZ payment for creation
- **Token Nodes**: Extracted knowledge units with BUZZ weighting and type classification

### Hierarchical Node Creation Interface
- **Curation Creation Controls**: Curations display a "+" button that opens the CreateNodeDialog configured for creating new swarms as child nodes
- **Swarm Creation Controls**: Swarms display a "+" button that opens the CreateNodeDialog configured for creating new annotations as child nodes
- **Annotation Restriction**: Annotations do not display "+" buttons since tokens are handled automatically through text parsing
- **Parent-Child Context**: CreateNodeDialog correctly initializes the child node type based on the clicked parent node type
- **Access Validation**: "+" buttons appear with proper access validation for swarm creators and members
- **Hierarchical Logic**: System maintains proper parent-child relationships during node creation
- **Clean Hierarchy Display**: Tree interface displays hierarchical structure with appropriate creation controls at each level

### Hierarchical Includes Relations
- **Automatic Structural Relations**: System automatically generates non-tokenized retrieval-type (`#retrieval`) relations connecting Curations → Swarms → Annotations
- **Non-Node Relations**: These hierarchical relations do not appear as separate nodes in the graph but display as solid gold lines
- **Consistent Reconstruction**: Default hierarchical links are always reconstructed in `getGraphData()` even if missing from stored relations
- **Structural Organization**: Provides clear visual hierarchy showing organizational structure from curations down to annotations

### Token Type System
- **Unified Token Registry**: Single global registry for all token types with tokenType variant field
- **Positive Law Tokens**: Created using curly bracket `{token}` syntax, representing factual or legal content
- **Interpretation Tokens**: Created using parentheses `(token)` syntax, representing analysis or commentary
- **Link Tokens**: Created from custom named link relations between annotations and from strict RDF validation within boxed RDFs, representing reasoning connections with BUZZ deduction applied using the modified reuse count formula
- **Corrected Interpretation Token Linking**: Interpretation tokens link only one-way to their corresponding link tokens via reasoning relations, with no direct back-links to annotation nodes to prevent redundant connections
- **Sequential Link Relations**: Interpretation tokens automatically link to the immediately preceding positive law token within the same annotation through link tokens
- **Type-Specific Relations**: Interpretation tokens generate link relations to positive law tokens they interpret through intermediary link tokens
- **Modified BUZZ Logic**: All token types use modified BUZZ calculation with proper reuse count logic: positive law and interpretation tokens use `reuseCount = number of distinct annotations linked - 1`, link tokens use `reuseCount = max(0, (number of distinct annotations linked ÷ 2) - 1)`, and BUZZ formula `buzzValue = 5 + 2 * reuseCount`
- **Atomic BUZZ Updates**: Reuse count calculations are atomically updated to ensure BUZZ values remain consistent
- **Visual Distinction**: Different token types rendered with distinct colors in graph visualization: positive law tokens blue, interpretation tokens pink, link tokens cyan (#27F5D3)
- **Intra-Annotation Reuse Tracking**: When a token appears multiple times within the same annotation, its reuse count increases by 1 and weight increases by 7 BUZZ per reuse (5 base + 2 * newReuseCount)
- **Global Registry Only**: Link tokens are stored exclusively in the global token registry without duplication as local nodes
- **Annotation-Only Relations**: Link tokens maintain direct reasoning-type relations only between their two connected annotations, without indirect attachment to swarms or curations
- **Strict RDF Link Token Creation**: Link tokens created from strict RDF validation with enforced `[ {positiveLawToken}, <linkToken>, (interpretationToken) ]` pattern, establishing reasoning-type relations between positive law token → link token → interpretation token

### TreeView Token Display with Type Labels
- **Token Visibility**: All token types (positive law, interpretation, and link tokens) are properly displayed as child nodes under their respective annotations in TreeView
- **Token Type Labels**: Each token displays its type with clear visual labels: "Positive Law", "Link", or "Interpretation" beside the token name
- **Hierarchical Token Structure**: Tokens appear as expandable child nodes beneath their parent annotations in the tree structure
- **Type-Specific Styling**: TreeView displays tokens with appropriate visual indicators and consistent labeling for their type
- **Real-Time Updates**: Token display updates immediately when new tokens are created or linked to annotations
- **Proper Data Fetching**: TreeView correctly fetches token data from `getGraphData()` and displays all associated tokens for each annotation with type information
- **Synchronized Display**: Token visibility in TreeView remains synchronized with GraphView to ensure consistent data representation
- **Clear Visual Hierarchy**: Token type labels provide immediate visual identification of token classification within the tree structure

### Link Token Creation and Visualization
- **Direct Creation**: `createCustomLinkRelation` directly creates one unique link token per (source annotation + relation name + target annotation) tuple and stores it only once in the global token registry
- **Exclusive Global Storage**: Link tokens are never added to any swarm or curation node and are only connected to the two related annotations via reasoning-type relations
- **Single Shared Nodes**: During `getGraphData()`, link tokens are fetched exclusively from the global token registry wherever they mediate reasoning relations, appearing as single shared token nodes without disconnected duplicates
- **Midpoint Positioning**: Link token nodes are visually placed at the exact midpoint of the line between their source and target annotations, calculated based on graph layout coordinates
- **Direct Creation Flow**: All placeholder creation messages and triggers are removed from LinkAnnotationsDialog and useQueries to ensure direct creation flow only
- **Clean Data State**: System resets and rebuilds data to clear all old placeholder entries and duplicate link token nodes
- **Strict RDF Link Token Positioning**: Link tokens created from strict RDF validation are positioned at the midpoint between their connected positive law and interpretation tokens in GraphView

### Link Token Validation and Creation
- **Node Type Validation**: System validates source and target node types during link token creation to prevent invalid annotation-token cross-links
- **Reasoning Relations Only**: Link tokens only mediate valid reasoning relations (`#reasoning`) between eligible nodes (annotation ↔ annotation, token ↔ token)
- **Researcher-Named Tokens**: Link tokens use the exact researcher-entered link name from the Add Link dialog or strict RDF validation as the token name, not autogenerated placeholders
- **BUZZ Deduction Application**: Link tokens apply the modified BUZZ deduction formula `(5 + 2 * reuseCount)` when created, consistent with other token types
- **Distinct Annotation Counting**: Reuse counting logic for link tokens uses distinct annotation counts computed as `max(0, (distinctAnnotationCount / 2) - 1)`
- **Clean Relations Dataset**: System clears legacy relations and regenerates all hierarchical and reasoning-type connections for consistent graph structure
- **Direct Annotation Relations**: Link tokens maintain direct relations only with their connected annotation pairs, not with parent swarms or curations
- **Direct Link Token Creation**: Link tokens are created immediately when users click "Add Link" or when strict RDF validation is processed without placeholder creation logic or intermediate messages
- **Automatic Link Token Generation**: Every reasoning-type relation automatically generates a corresponding link token in the backend `createCustomLinkRelation` function
- **Unique Token Creation**: Link tokens are created once per unique (source annotation + target annotation + relation name) tuple to prevent duplicates
- **Mandatory Token Creation**: No logic suppresses or bypasses link token creation after placeholder removal
- **Strict RDF Link Token Validation**: RDF link tokens validate the exact pattern `[ {positiveLawToken}, <linkToken>, (interpretationToken) ]` and reject any malformed or misordered sequences

### Target Annotation Visibility
- **Expanded Annotation Access**: Target annotations available for linking include all annotations owned or co-owned by the caller
- **Ownership Definition**: For current implementation, ownership means caller is creator; co-ownership logic placeholder left for future extension
- **Comprehensive Link Options**: Users can create links to any annotation they have access to within their ownership scope

### Strict RDF Triple System
- **Enforced RDF Validation**: Annotations support only the exact form `[ {positiveLawToken}, <linkToken>, (interpretationToken) ]` with strict bracket type ordering
- **Pattern Enforcement**: RDF parser rejects (traps) any sequences that do not match the exact pattern or have misordered bracket types
- **Automatic Reasoning Relations**: Valid RDFs automatically create reasoning-type relations: positive law token → link token → interpretation token
- **Link Token Creation**: The middle element `<linkToken>` is created as a reasoning-type token with BUZZ deduction identical to other tokens using the modified formula
- **Global RDF Registry**: Centralized storage of all validated RDF triples with unique identification
- **RDF-Annotation Linking**: Each RDF maintains reference to its originating annotation
- **Dynamic BUZZ Calculation**: RDFs dynamically derive and update their BUZZ values based on the BUZZ values of their constituent tokens using modified reuse count logic
- **Strict Syntax Processing**: RDF extraction operates with enforced validation to prevent malformed entries
- **Token-to-Token Reasoning**: Link tokens establish reasoning-type relations between positive law and interpretation tokens
- **Validation Trapping**: System traps with clear error messages when RDF patterns do not match the required format
- **Data Reset Requirement**: Existing RDF and relation data must be reset to remove malformed entries before applying strict validation logic

### Token Extraction and Management
- **Triple Token Syntax**: Annotations support `{token}` curly bracket syntax for positive law tokens, `(token)` parentheses syntax for interpretation tokens, and custom named link relations for link tokens
- **Sequential Parsing Logic**: Parser identifies `{law}(interpretation)` sequences within annotation text and creates automatic link relations
- **Immediate Precedence Linking**: Each interpretation token automatically links to the positive law token immediately preceding it in the same annotation
- **Independent Token Parsing**: Token extraction operates independently from RDF parsing for all token types
- **Global Token Registry**: Centralized token storage with modified BUZZ weighting system and tokenType classification supporting #positiveLaw, #interpretation, and #link
- **Token-Node Relationships**: Tokens maintain references to their source nodes regardless of type
- **BUZZ Inheritance**: All token types inherit and propagate BUZZ values through the hierarchy using modified reuse count logic
- **Automatic Link Relations**: System creates link relations between positive law tokens (source) and interpretation tokens (target) when parsed in sequence
- **Intra-Annotation Reuse Logic**: When the same token appears multiple times within a single annotation, the system increases the token's reuse count by 1 and adds 7 BUZZ to its weight for each additional occurrence (5 base + 2 * newReuseCount)
- **Strict RDF Link Token Extraction**: Parser enforces exact `[ {positiveLawToken}, <linkToken>, (interpretationToken) ]` pattern and creates link tokens with reasoning-type relations between the specified tokens
- **RDF-Exclusive Strict Validation**: Strict RDF validation is applied exclusively to content within boxed RDF expressions
- **Token-to-Token Link Creation**: Link tokens created from strict RDF validation connect tokens directly with enforced ordering

### Custom Named Link Relations
- **User-Defined Relations**: Users can create custom named link relations between annotations through the Add Link interface in Create Annotation dialog
- **Link Token Creation**: Each custom named link relation is recorded as a link token in the global token registry with BUZZ deduction applied using the modified reuse count formula
- **Exact Name Preservation**: Link tokens use the exact researcher-entered name from the Add Link dialog, not autogenerated placeholders
- **BUZZ Value Assignment**: Link tokens receive their own BUZZ value and participate in reuse tracking like other token types using modified logic
- **Relation Persistence**: Custom link relations are stored and maintained in the backend for graph visualization
- **Multiple Relations Support**: Users can create multiple link relations between the same or different annotation pairs
- **Direct Link Creation**: When users create custom link relations, link tokens are created immediately without placeholder creation logic
- **Direct Annotation Connections**: Link tokens connect only their two associated annotations without indirect relations to parent swarms or curations

### BUZZ System
- **Internal BUZZ Ledger**: Application maintains internal BUZZ balances and transactions
- **User BUZZ Tracking**: Each user has a BUZZ balance for participation rewards and daily login rewards
- **Daily Reward Distribution**: Users receive 100 BUZZ per day during login with timestamp tracking
- **Annotation Creation Costs**: Users pay BUZZ equal to cumulative token weights when creating annotations
- **Balance Validation**: System validates sufficient BUZZ before allowing annotation creation
- **Token BUZZ Weighting**: Tokens accumulate BUZZ based on usage and validation regardless of type using modified reuse count logic with formula `buzzValue = 5 + 2 * reuseCount`
- **RDF BUZZ Synchronization**: RDFs automatically update their BUZZ values based on constituent token values using modified reuse count logic
- **Swarm Activity Rewards**: Swarm members receive daily BUZZ rewards for participation
- **Real-Time Balance Queries**: Backend provides live BUZZ balance queries for frontend display
- **Proper Economy Logic**: All BUZZ operations follow consistent deduction and validation rules with clean state management
- **Link Token BUZZ Deduction**: Link tokens follow the modified BUZZ deduction formula using proper reuse count logic during creation
- **Strict RDF BUZZ**: Link tokens created from strict RDF validation apply identical BUZZ deduction and tracking as other token types using the modified formula

### Stabilized Swarm Membership Visibility and Access Rights
- **Full Visibility for Approved Members**: Newly approved swarm members automatically see all existing annotations and their tokens in Tree View, Graph View, and Schema Builder with the same level of access as creators
- **Complete Data Access**: Backend access and filtering logic updated to remove all restrictive visibility checks that hide annotation or token information from approved swarm members
- **Creator-Level Access**: Once approved through the join process, members inherit identical access rights to creators for viewing annotations, tokens, and all associated data
- **Automatic Membership for Creators**: Only swarm creators are automatically members; all others, including curation creators, must go through the join approval process before gaining visibility
- **Consistent Data Functions**: Data access functions like `getGraphData`, `getNode`, and `getSwarmData` return full detail for approved members without restrictions
- **Immutable Content Structure**: Annotations and tokens remain immutable but data access is fully opened for approved members
- **Clean Membership State**: System resets existing test or inconsistent swarm membership data and token visibility data to ensure correct propagation of visibility and membership rights
- **Unified Access Control**: Access control logic consistently treats approved members and creators with identical visibility permissions across all data retrieval functions

### Phase-1 Post-Approval Workflow for New Swarm Members
- **Automatic Full Access**: After a user's join request gains >50% approval and they are automatically added to swarm membership, they immediately receive full access identical to creators for all annotations within that swarm
- **Complete Annotation Visibility**: Newly approved members can view annotation titles, content, and all associated tokens through `getGraphData()` and `getSwarmData()` with full modification and import capabilities
- **Full Interaction Rights**: Approved members can see and interact with all interface elements including upvote/downvote buttons on visible annotations within their joined swarms
- **Upvote Confirmation Dialog**: When an approved member clicks upvote, a confirmation dialog appears outlining the exact BUZZ deduction and credit logic that would occur, but no actual BUZZ transfer or ownership updates are performed
- **Creator Auto-Membership**: Swarm creators remain automatically included as members with full access rights
- **Instant Member Count Updates**: Member counts refresh immediately after approval processing and new member addition
- **Access Synchronization**: Full access is synchronized across `getGraphData()` and `getSwarmData()` to ensure consistent annotation visibility for approved members
- **Voting Interface Preparation**: Upvote/downvote interface is prepared for future BUZZ transfer implementation while currently only displaying confirmation dialogs
- **Data Reset Integration**: Existing swarm, join-request, and membership data is reset for consistency when applying the new post-approval workflow logic

### Redesigned My Swarms Interface
- **Join Request Management**: Dedicated section displays all pending join requests for swarms where the user is a member, showing requester's name and social profile link
- **Approval Controls**: Each pending request displays "Approve" and "Disapprove" buttons that trigger `approveJoinRequest` backend calls and refresh swarm data automatically
- **Real-Time Member Counts**: Member counts update immediately when approval reaches the >50% threshold and new members are automatically added
- **All Swarms View**: Comprehensive list of all available swarms with "Join Swarm" buttons for non-members that trigger `requestJoinSwarm` mutations
- **Pending Status Display**: After submitting a join request, swarms display a "Pending" badge to indicate request status
- **Joined Swarms View**: Shows swarms where the user is already a member with current member counts and visibility of existing annotations
- **Automatic Cache Invalidation**: React Query cache invalidations ensure member lists and request views update automatically after approval actions
- **Clean Data State**: System resets existing swarm and membership data for clean start with new join-approval UI workflow
- **Social Profile Integration**: Join request displays include clickable social profile links from user's mandatory social URL
- **Request Status Tracking**: Interface tracks and displays the current approval status and progress toward majority threshold
- **Member List Display**: Shows current members for each swarm with their names and social profile links
- **Full Annotation Access**: Members can view and interact with existing annotations within joined swarms with complete access and upvote confirmation dialogs
- **Responsive UI Updates**: All swarm-related actions trigger immediate UI updates through proper state management and cache invalidation

### Swarm Management
- **Swarm Creation**: Users can create collaborative swarms with automatic creator membership
- **Join-Approval System**: Users can request to join swarms with member approval process
- **Membership System**: Users can join existing swarms through approval-based system
- **Activity Tracking**: System tracks swarm participation for reward distribution
- **Daily Rewards**: Active swarm members receive BUZZ rewards
- **Social URL Verification**: Swarm approval processes can reference user's mandatory social URL
- **Creator Membership**: Swarm creators are automatically included as initial members at swarm creation
- **Majority Approval**: Join requests require approval from more than 50% of current swarm members
- **Automatic Processing**: Once majority approval is reached, requesters are automatically added to swarm membership
- **Request Management**: System maintains join request records with requester principal, target swarmId, timestamp, and approving members list
- **Type-Safe Join Request Handling**: All join request operations use properly typed data structures with consistent field names and Candid-compatible types
- **Backend Method Alignment**: Frontend components correctly reference backend methods `getPendingJoinRequests`, `approveJoinRequest`, `getJoinRequestStatus`, and `requestToJoinSwarm` with matching parameter and return types
- **Post-Approval Full Access**: Newly approved members automatically receive complete access identical to creators for all swarm annotations with full interaction capabilities

### Annotation Voting System with Creator Self-Voting Restrictions
- **Content Verification**: Users can vote on annotation quality and accuracy
- **BUZZ Impact**: Voting affects BUZZ distribution and token weighting
- **Quality Control**: Community-driven content validation system
- **Creator Self-Voting Restriction**: Annotation creators cannot upvote or downvote their own annotations, with authorization checks blocking self-voting attempts and returning clear error messages
- **Member-Only Voting**: Only verified swarm members (non-creators) can cast votes on annotations within their joined swarms
- **Irreversible Voting**: Each swarm member can cast only one vote (upvote or downvote) per annotation, with votes being permanent and non-changeable
- **Access Control**: Only verified swarm members (creator or joined) can view annotation content, but only non-creators can vote
- **Vote Recording**: System stores all votes to prevent duplicate voting attempts and maintains voting history
- **Verification Status Updates**: Annotations are marked as verified when upvote/downvote ratio exceeds 1
- **Full Token Sequence Access**: Swarm members can view complete annotation content and token sequences to make informed voting decisions
- **Error Handling**: Clear error messages returned for unauthorized voting attempts, including self-voting by creators
- **Membership Validation**: Voting authorization follows the same 50%+ approval logic used for swarm membership verification

### Schema Builder Interface
- **My Tokens**: Display user's created and associated tokens with type distinction
- **My RDFs**: Display user's created RDF triples with originating annotation references
- **Token Management**: Interface for viewing and managing token relationships across all token types
- **RDF Management**: Interface for viewing RDF triples and their source annotations

### Create Annotation Dialog Enhancement
- **Updated Field Labels**: The Create Annotation dialog includes updated field labels with "Annotation Name" field using placeholder text "section of a statute, para of a case, etc." and "Content" field (renamed from "Bracketed Token Sequence")
- **Enhanced Content Placeholder**: Content field includes comprehensive placeholder text: "Use curly brackets for positive law tokens, e.g. {appropriate authority} {means}{the State}. Use a combination of boxed, angled and round brackets to add your interpretation via custom links, e.g. [{the State} <is not> (the Nation in this context)]."
- **Simplified Interface**: Dialog removes all descriptive helper text following the input fields and removes both "Add Link" and "Add Attributes" buttons for a cleaner, more focused interface
- **Token Extraction Guidance**: Placeholder text provides clear guidance on using curly brackets `{token}` syntax for positive law token extraction
- **Interpretation Token Guidance**: Placeholder text shows users how to use parentheses `(token)` syntax for interpretation token extraction
- **Sequential Syntax Guidance**: Placeholder text demonstrates how `{law}(interpretation)` sequences create automatic link relations
- **Strict RDF Triple Extraction Guidance**: Placeholder text shows users how to use the exact pattern `[ {positiveLawToken}, <linkToken>, (interpretationToken) ]` for validated RDF triple creation
- **Theme-Aware Styling**: Input fields and placeholder text are styled consistently with the application theme and adapt to dark/light mode
- **Streamlined Workflow**: Simplified interface focuses on essential annotation creation without additional complexity from removed buttons and descriptive text

### Enhanced Autocomplete Feature
- **Bracket-Triggered Autocomplete**: Typing opening brackets `{`, `(`, `[`, or `<` triggers context-specific dropdown suggestions
- **Real-Time Auto-Filtering**: As users type after triggering autocomplete, suggestions dynamically filter to show only matching tokens or RDFs
- **Debounced Search Performance**: Filtering uses 150ms debounce to optimize performance with large registries
- **Positive Law Token Autocomplete**: Typing `{` shows dropdown of user's existing positive law tokens with real-time filtering
- **Interpretation Token Autocomplete**: Typing `(` shows dropdown of user's existing interpretation tokens with real-time filtering
- **Strict RDF Autocomplete**: Typing `[` shows dropdown of user's existing validated RDF triples with real-time filtering
- **Link Token Autocomplete**: Typing `<` within RDF context shows dropdown of user's existing link tokens with real-time filtering
- **User-Scoped Suggestions**: Autocomplete only shows tokens and RDFs owned by the current user
- **Immutable Insertion**: Selected items are inserted as greyed-out, immutable elements maintaining proper bracket syntax
- **Cursor Position Detection**: Dropdowns only trigger when typing directly after opening brackets to avoid interference with existing content
- **Privacy Protection**: No exposure of other users' data through autocomplete suggestions
- **Cache Management**: Token and RDF registry caches are reset and rebuilt for consistency after implementation
- **Strict RDF Context Awareness**: RDF autocomplete only suggests validated RDF patterns matching the exact required format

### Debug Panel Interface
- **Full Scrollability**: Debug Panel interface supports complete vertical and horizontal scrolling when content exceeds viewport dimensions using proper overflow handling (`overflow-y-auto` and `overflow-x-auto` where needed)
- **Accessible Reset Button**: "Reset Data" button remains clickable and accessible regardless of panel content overflow, properly responding to clicks and executing the backend method `resetAllData()`
- **Responsive Layout**: CSS and layout structure ensures smooth scrolling across all Debug Panel sections without blocking interactions, maintaining consistent layout across different screen sizes
- **Admin Authorization**: Reset functionality properly validates admin user authorization before executing backend reset operations
- **Success/Error Feedback**: Clear user feedback messages displayed after reset operations, indicating success or failure with appropriate messaging
- **Frontend Cache Refresh**: After successful data reset, frontend automatically refreshes and clears all cached data to reflect the clean state
- **Modal Compatibility**: Modal dialogs and confirmation boxes do not interfere with panel scrolling or pointer events
- **Fixed Element Management**: Fixed UI elements positioned to avoid blocking scroll functionality within the Debug Panel
- **Overflow Handling**: Proper CSS overflow properties applied to enable natural content navigation in both directions
- **Viewport Adaptation**: Panel layout adapts to various screen sizes while maintaining scroll accessibility and button functionality
- **Preserved Features**: All other Debug Panel features, layouts, and styles remain intact while fixing scrolling and reset functionality

### Data Management
- **Comprehensive Reset**: System supports complete data reset for clean initialization through `resetAllData()` backend method
- **BUZZ Reward Migration**: Initialize daily reward tracking structures for existing users
- **Profile Migration**: Update existing profiles to include mandatory social URL field
- **Strict RDF Data Reset**: Specific reset functionality for RDF data to ensure clean parsing of new annotations with strict validation
- **Token Structure Reset**: Clean existing token data to prevent conflicts with new tokenType system including link tokens and modified reuse count logic
- **Link Relation Reset**: Clean existing link relations to ensure proper sequential linking and custom named relations with modified reuse count logic
- **Cache Reset**: Reset and rebuild token and RDF registry caches for autocomplete consistency
- **Data Persistence**: All nodes, tokens, RDFs, swarms, user profiles with mandatory social URLs, BUZZ data, daily reward timestamps, custom link relations, voting data, join requests, and swarm membership data stored in backend
- **Relationship Integrity**: System maintains referential integrity between all data types
- **Clean State Management**: Reset or clear existing data where necessary to ensure all BUZZ operations follow proper economy logic with modified reuse count calculations
- **Clean Relations Regeneration**: Clear legacy relations from previous builds and regenerate all hierarchical and reasoning-type connections for consistent graph structure
- **Link Token Data Cleanup**: Clean and reset link token data to eliminate all redundant or standalone nodes, ensuring link tokens exist only in the global registry
- **Legacy Artifact Removal**: Reset existing data to eliminate legacy placeholder artifacts and rebuild the graph with correct single link token nodes and reasoning connections
- **Hierarchical Creation Reset**: Reset and clean old data to reload the hierarchy cleanly after implementing hierarchical node creation fixes
- **Token Display Fix Reset**: Reset all data to ensure proper token visibility in TreeView and restore missing token display functionality
- **Placeholder Data Cleanup**: Reset all old placeholder and duplicate link token data for clean start with direct creation flow
- **Strict RDF Validation Reset**: Reset existing RDF and relation data to remove malformed entries before applying strict validation logic
- **Corrected Token-Link Model Reset**: Reset existing data to ensure clean migration of the corrected interpretation token linking model that prevents redundant annotation connections
- **Swarm Interface Reset**: Reset existing swarm membership and join request data for clean start with redesigned My Swarms interface and join-approval workflow
- **Post-Approval Workflow Reset**: Reset existing swarm, join-request, and membership data for consistency when applying the new phase-1 post-approval workflow logic
- **Membership Visibility Reset**: Reset existing test or inconsistent swarm membership data and token visibility data to ensure clean state and correct propagation of full visibility and membership rights for approved members

### D3.js Graph Visualization
- **D3.js Integration**: GraphView component uses D3.js library for interactive graph visualization with stable layout configuration
- **D3.js Imports**: Uses standard D3.js modules for force simulation, selection, and graph rendering
- **Force Simulation Configuration**: Implements D3 force simulation with adjusted parameters for stability: low `alphaDecay` (0.01), increased `velocityDecay` (0.8), and suitable link strength (0.3) to ensure the graph remains stable after settling but maintains drag interactivity
- **Link Token Force Isolation**: Link tokens (identified by node type `#token` and token subtype "link") have zero force influence with `forceX`, `forceY`, and `charge` strengths set to 0, ensuring they remain anchored at their positioned coordinates unless manually dragged
- **Static Draggable Structure**: Graph achieves stable, static positioning without continuous rotation while preserving full drag interactivity for all node types
- **Node and Link Mapping**: Each node represents a graph element from `graphData.nodes` using SVG circles colored by node type (Curation, Swarm, Annotation, Token), with each edge corresponding to relations or includesRelations from backend, colored by relation type: retrieval (gold solid), reasoning (green dashed)
- **Interactive Canvas**: D3.js force simulation provides interactive, draggable graph canvas within React component
- **Node Rendering**: Uses D3 selection and data binding to display nodes (Curations, Swarms, Annotations, Tokens) with color-coded categories
- **Edge Visualization**: SVG lines represent retrieval and reasoning relations, preserving link type styling (solid for retrieval, dashed/green for reasoning)
- **Interactive Features**: Enables zooming, panning, hover tooltips showing node title/type, and drag interactions with maintained stability
- **Theme Integration**: Graph coloring synchronized with current light/dark mode theme through D3 color schemes triggered via React context state
- **Dynamic Updates**: Graph dynamically re-renders when backend graphData updates, with stable positioning after initial settling period
- **Resource Management**: Proper resource cleanup and disposal on component unmount
- **HTML Mounting**: Embeds D3 visualization inside HTML div with ref returned by `useRef<HTMLDivElement>` and ensures cleanup on component unmount
- **Performance Optimization**: Maintains responsiveness on window resize and limits rendering to data changes for optimal performance with stable layout
- **Frontend Consistency**: Preserves existing layout, theme-based cursor logic, BUZZ color scheme, and event bindings for tab changes
- **Crosshair Cursor**: Theme-based crosshair cursor remains visible with D3.js canvas
- **Token Type Rendering**: Positive law, interpretation, and link tokens appear in graph with distinct visual styling using D3.js components
- **Distinct Color Mapping**: Curation nodes appear gold, Swarm nodes appear teal, Annotation nodes appear purple, Positive Law tokens appear blue, Interpretation tokens appear pink, Link tokens appear cyan (#27F5D3) using D3 color mapping with distinct colors for each node type
- **Link Token Nodes**: Link tokens appear as actual node entries with proper positioning and styling in D3.js visualization
- **Precise Midpoint Positioning**: Link tokens positioned exactly at the midpoint between source and target annotation nodes using D3.js coordinate system
- **Hierarchical Relation Display**: Hierarchical includes relations (curation → swarm → annotation) displayed as solid gold lines using D3.js line elements
- **Link Relation Visualization**: Link relations between annotations displayed as dashed green links with link tokens as visible midpoint nodes
- **Sequential Linkage Display**: Graph correctly renders automatic link relations created from `{law}(interpretation)` sequences with link tokens as visible nodes
- **Custom Relation Display**: Graph renders user-defined named link relations as dashed green links between connected annotations with link tokens as visible midpoint nodes
- **Consistent Node Rules**: All tokens follow existing node interaction and display rules regardless of type within D3.js framework
- **Visual Overlap Prevention**: D3.js layout prevents visual overlap or duplication errors in graph rendering
- **Updated Color Legend**: Left legend panel displays distinct color coding for Gold (Curation), Teal (Swarm), Purple (Annotation), Blue (Positive Law), Pink (Interpretation), and Cyan (Link Tokens) with removal of the general "Token" label
- **Clean Midline Rendering**: Link tokens appear as small cyan nodes labeled with the exact name specified in the Add Link dialog, positioned midway between connected annotations
- **Disconnected Node Cleanup**: System removes any disconnected or placeholder nodes generated by previous link relation implementations
- **Valid Annotation Pairs Only**: Link tokens are included in graph visualization only if they connect valid annotation pairs
- **Global Registry Retrieval**: Link token data is fetched exclusively from the global token registry, not from local node storage
- **Strict RDF Link Token Visualization**: Link tokens created from strict RDF validation appear as cyan nodes positioned at the midpoint between their connected positive law and interpretation tokens
- **Token-to-Token Link Display**: Strict RDF link tokens display reasoning-type relations as dashed green lines connecting positive law tokens → link tokens → interpretation tokens
- **Stable Graph Layout**: D3.js graph remains stable after initial settling period without continuous rotation or automatic motion, with nodes staying stationary unless manually dragged by the user
- **Preserved Interactivity**: Zoom, pan, and drag interactions remain fully functional while preventing automatic node movement after settling
- **Force Simulation Stability**: Layout forces configured with appropriate parameters to achieve stability: `alphaDecay(0.01)`, `velocityDecay(0.8)`, and `force("link").strength(0.3)` to ensure the graph settles into a stable state but remains draggable
- **Enhanced Link Token Styling**: Link tokens specifically assigned the color #27F5D3 (cyan) to visually differentiate them from swarm nodes and other node types

### Type Safety and Schema Validation
- **Backend-Frontend Type Alignment**: All TypeScript type definitions in frontend declarations exactly match Motoko backend type definitions with consistent field names, capitalization, and data structures
- **Candid Interface Consistency**: Backend method signatures properly marked as `public` and return valid Candid-compatible types for all join-approval functions
- **Join Request Type Safety**: `JoinRequest`, `SwarmData`, and `GraphData` types used in frontend align exactly with backend definitions without array vs. optional type mismatches
- **Method Signature Validation**: Backend methods `getPendingJoinRequests`, `approveJoinRequest`, `getJoinRequestStatus`, and `requestToJoinSwarm` have proper public visibility and Candid-compatible return types
- **TypeScript Declaration Export**: All missing TypeScript bindings for join-approval functions are properly added and exported in `frontend/src/declarations`
- **Schema Consistency Validation**: System validates that frontend components correctly reference existing backend methods with matching parameter types and field names
- **Compilation Error Prevention**: All type mismatches, schema inconsistencies, and missing declarations are resolved to prevent deployment failures
- **Data Structure Alignment**: Frontend data handling components use type-safe operations that match backend data structures exactly

## Backend Data Storage
- **User Profile Registry**: Stores user profiles with name, owner principal, creation timestamp, and mandatory social URL
- **Daily Reward Tracking**: Stores last reward timestamp per user for 24-hour reward prevention
- **Node Registry**: Stores all node types with hierarchical relationships
- **Unified Token Registry**: Global token storage with modified BUZZ weighting using proper reuse count logic, node references, reuse tracking, and tokenType variant field supporting #positiveLaw, #interpretation, and #link
- **Strict RDF Registry**: Global RDF triple storage with enforced validation, annotation links, and dynamic BUZZ calculation using modified reuse count logic (subject, predicate, rdfObject, creator, createdAt, originatingAnnotation, buzzValue)
- **Swarm Registry**: Swarm data with membership and activity tracking
- **User Registry**: User profiles with BUZZ balances, participation history, and daily reward timestamps
- **BUZZ Ledger**: Internal transaction system for BUZZ distribution, tracking, daily rewards, and annotation creation costs with proper deduction logic using modified reuse count calculations
- **Link Relations Registry**: Storage for automatic link relations between positive law tokens (source) and interpretation tokens (target), plus custom named link relations with link tokens stored in global token registry using modified reuse count logic
- **Custom Link Relations**: Storage for user-defined named link relations between annotations with associated link tokens and BUZZ deduction using modified reuse count logic
- **Hierarchical Relations Registry**: Storage for automatic retrieval-type relations connecting Curations → Swarms → Annotations with consistent reconstruction capability
- **Strict RDF Link Token Registry**: Storage for link tokens created from strict RDF validation, connecting positive law and interpretation tokens with reasoning-type relations
- **Corrected Token-Link Relations**: Storage for corrected interpretation token linking that enforces one-way connections to link tokens only, preventing redundant annotation-interpretation links
- **Voting Registry**: Storage for annotation votes with creator self-voting restrictions and user voting history
- **Join Request Registry**: Storage for swarm join requests with requester principal, target swarmId, timestamp, and list of approving members using type-safe data structures
- **Swarm Membership Registry**: Storage for swarm membership data with automatic creator inclusion and majority approval processing using Candid-compatible types
- **Full Access Registry**: Storage for tracking complete access permissions for approved swarm members to view and interact with all annotations within their joined swarms with creator-level rights

## Backend Methods
- **saveCallerUserProfile**: Shared method that accepts name (Text) and mandatory socialUrl (Text), validates input parameters including social URL format, creates or updates UserProfile record keyed by caller principal, and returns success flag (Bool)
- **claimDailyReward**: Shared method that checks if 24 hours have elapsed since last reward, grants 100 BUZZ if eligible, updates timestamp, and returns success flag (Bool)
- **createNode**: Public shared method that handles creation for curations, swarms, and annotations with correct hierarchy validation, maintains proper parent-child relationships, validates access permissions, includes null-guards and AccessControl initialization to prevent Runtime.trap on anonymous or uninitialized callers, and returns CreateNodeResult type aligned with frontend expectations
- **createAnnotation**: Enhanced method that accurately calculates cumulative BUZZ cost as the sum of all BUZZ (weight) values of tokens associated with the annotation (including positive law, interpretation, and link tokens) using modified reuse count logic, handles intra-annotation token reuse by increasing reuse count and weight, validates user has sufficient BUZZ balance, deducts cost from user's balance if sufficient, traps gracefully with "Insufficient BUZZ balance to create this annotation." error if insufficient, creates link tokens directly from custom link relations with BUZZ deduction using modified reuse count formula, processes strict RDF validation with enforced `[ {positiveLawToken}, <linkToken>, (interpretationToken) ]` pattern to create token-to-token reasoning connections, enforces corrected interpretation token linking to prevent redundant annotation connections, maintains all existing swarm membership and access validation logic, and returns updated balance after successful creation with real-time synchronization and proper deduction logic
- **createPositiveLawAnnotation**: Enhanced method that maintains existing access validation without automatic creator upvote functionality
- **createSwarm**: Shared method that creates new swarm nodes with proper parent-child relationship to curation nodes, validates access permissions, maintains hierarchical structure, and automatically includes creator as initial member in swarm membership registry
- **createCuration**: Shared method that creates new top-level curation nodes with proper initialization and access control
- **createCustomLinkRelation**: Shared method that directly creates one unique link token per (source annotation + relation name + target annotation) tuple and stores it only once in the global token registry, validates node types, automatically generates corresponding link tokens with BUZZ tracking and deduction using modified reuse count formula, uses exact researcher-entered link names as token names, ensures no logic suppresses or bypasses link token creation, enforces corrected interpretation token linking to prevent redundant annotation connections, and triggers immediate BUZZ deduction using modified formula (5 + 2 × reuseCount)
- **requestToJoinSwarm**: Public shared method that initiates membership approval process whereby all existing swarm members receive the join request, succeeds only when over 50% approve, creates or updates a join request for the caller to join the specified swarm, records requester principal, target swarmId, timestamp, and initializes empty approving members list with Candid-compatible return type, includes null-guards and AccessControl initialization to prevent Runtime.trap on anonymous or uninitialized callers
- **approveJoinRequest**: Public shared method that registers an approval by the calling swarm member for a specific join request, validates caller is current swarm member, adds caller to approving members list, checks if more than 50% of current swarm members have approved, automatically processes approval by adding requester to swarm membership and granting full access identical to creators for all swarm annotations, and deletes processed join request when majority threshold is reached with proper Candid-compatible return type
- **getPendingJoinRequests**: Public query method that returns all pending join requests for a specific swarm, including requester information, timestamp, and current approval status with type-safe data structures matching frontend expectations
- **getJoinRequestStatus**: Public query method that returns the approval status for a specific join request, including list of approving members and percentage of required approvals achieved with Candid-compatible return type
- **upvoteAnnotation**: Public shared method that validates caller is not the annotation creator, checks caller is a verified swarm member with access to the annotation, prevents duplicate voting by the same user, records the upvote in voting registry, updates annotation verification status when upvote/downvote ratio exceeds 1, and returns clear error message "Annotation creators cannot vote on their own annotations" for self-voting attempts
- **downvoteAnnotation**: Public shared method that validates caller is not the annotation creator, checks caller is a verified swarm member with access to the annotation, prevents duplicate voting by the same user, records the downvote in voting registry, updates annotation verification status when upvote/downvote ratio exceeds 1, and returns clear error message "Annotation creators cannot vote on their own annotations" for self-voting attempts
- **getCallerBuzzBalance**: Public query method that returns the current BUZZ balance for the authenticated caller as Nat type, enabling real-time balance display in the frontend, includes null-guards and AccessControl initialization to prevent Runtime.trap on anonymous or uninitialized callers
- **getAllSwarmSummaries**: Public query method that returns an array of SwarmSummary objects for the My Swarms tab, includes all available swarms with membership status, member counts, and join request information, includes null-guards and AccessControl initialization to prevent Runtime.trap on anonymous or uninitialized callers, and returns [SwarmSummary] type aligned with frontend expectations
- **getGraphData**: Public query method that returns GraphData including nodes, tokens, and relations required for Tree View and Graph View, updated to include all token types with distinct color mapping (Curation gold, Swarm teal, Annotation purple, Positive Law blue, Interpretation pink, Link tokens cyan #27F5D3), link tokens as actual node entries returned within the nodes array with precise midpoint positioning along their dashed green link relations between annotations, hierarchical includes relations as solid gold lines with consistent reconstruction, link tokens fetched exclusively from the global registry wherever they mediate reasoning relations appearing as single shared token nodes, proper token data structure for TreeView display with all tokens properly associated with their parent annotations including token type information for clear labeling, strict RDF link tokens positioned at midpoints between connected positive law and interpretation tokens with reasoning-type relations, corrected interpretation token linking that prevents redundant annotation connections, static positioning without continuous rotation or automatic motion, full access integration for approved swarm members to view and interact with all annotations within their joined swarms with creator-level rights, updated backend access logic that removes all restrictive visibility checks for approved members, includes null-guards and AccessControl initialization to prevent Runtime.trap on anonymous or uninitialized callers, and returns GraphData type aligned with frontend expectations
- **getSwarmData**: Enhanced method that returns swarm data including all annotations visible to approved members with complete access identical to creators, ensuring newly approved members can view annotation titles, content, and all associated tokens within their joined swarms without restrictions
- **getNode**: Updated method that returns full node details for approved swarm members without any visibility restrictions, treating approved members with identical access rights as creators
- **getUserTokens**: Returns user's positive law tokens for autocomplete suggestions with filtering support
- **getUserInterpretationTokens**: Returns user's interpretation tokens for autocomplete suggestions with filtering support
- **getUserLinkTokens**: Returns user's link tokens for autocomplete suggestions with filtering support
- **getUserRDFs**: Returns user's validated RDF triples for autocomplete suggestions with filtering support
- **getTargetAnnotations**: Returns all annotations owned or co-owned by the caller for link target selection with expanded visibility
- **resetTokenCache**: Method to reset and rebuild token registry caches for consistency
- **resetRDFCache**: Method to reset and rebuild RDF registry caches for consistency
- **migrateBuzzRewards**: Method to initialize daily reward tracking for existing users
- **migrateProfiles**: Method to update existing profiles with mandatory social URL field
- **resetAllData**: Shared method that performs comprehensive data reset for clean initialization, accessible from Debug Panel Reset Data button, automatically clearing old token and relation data to safely reapply modified reuse counting logic, regenerating clean hierarchical and reasoning relations, cleaning link token data to eliminate redundant or standalone nodes, removing all placeholder-related entries and orphaned nodes, eliminating legacy placeholder artifacts to rebuild the graph with correct single link token nodes and reasoning connections, resetting hierarchical creation data to reload the hierarchy cleanly, ensuring proper token visibility restoration in TreeView after data reset, cleaning all old placeholder and duplicate link token data for clean start, resetting strict RDF validation data to remove malformed entries before applying new logic, resetting existing data to ensure clean migration of the corrected interpretation token linking model, resetting existing swarm membership and join request maps for clean start with redesigned My Swarms interface, resetting existing swarm, join-request, and membership data for consistency when applying the new phase-1 post-approval workflow logic, and resetting existing test or inconsistent swarm membership data and token visibility data to ensure clean state and correct propagation of full visibility and membership rights for approved members
- **updateAllRDFBuzzValues**: Method to recalculate all RDF BUZZ values using modified reuse count logic for constituent tokens
- **ensureSingleLocalToken**: Modified method that uses the updated BUZZ calculation formula `buzzValue = 5 + (2 * newReuseCount)` for all token types when reuse counts increment, maintaining all other BUZZ deduction and reuse count logic unchanged

## Parsing Logic
- **Sequential Token Extraction**: Parse `{token}` syntax for positive law tokens and `(token)` syntax for interpretation tokens, identifying `{law}(interpretation)` sequences within the same annotation
- **Intra-Annotation Reuse Handling**: When the same token appears multiple times within a single annotation, increase the token's reuse count by 1 and add 7 BUZZ to its weight for each additional occurrence (5 base + 2 * newReuseCount)
- **Automatic Relation Creation**: Create link relations between positive law tokens (source) and interpretation tokens (target) when parsed in immediate sequence
- **Custom Link Token Creation**: Create link tokens from user-defined named link relations with node type validation, BUZZ tracking and deduction using modified reuse count formula, and exact researcher-entered names
- **Strict RDF Validation**: New enforced parser validates only the exact form `[ {positiveLawToken}, <linkToken>, (interpretationToken) ]` and traps on any malformed or misordered patterns
- **Pattern Enforcement**: RDF parser rejects any sequences that do not match the exact bracket type ordering or contain invalid elements
- **Automatic Reasoning Relations**: Valid RDFs automatically create reasoning-type relations: positive law token → link token → interpretation token
- **Independent Processing**: Token (all types) and RDF extraction operate simultaneously but independently on annotation content
- **Registry Integration**: Extracted tokens automatically registered in unified global registry with proper tokenType classification including link tokens using modified reuse count logic
- **Strict RDF Registry Integration**: Extracted RDF triples automatically stored in global RDF registry with proper field mapping and annotation references using modified reuse count logic for BUZZ calculations
- **Mixed Syntax Handling**: Support for complex expressions containing `{}`, `()`, `[]`, and `<>` syntax with independent parsing pipelines
- **Sequential Link Relation Generation**: Interpretation tokens automatically generate link relations to immediately preceding positive law tokens within the same annotation
- **Strict RDF Field Storage**: RDFs stored with proper fields including subject, predicate, rdfObject, creator, createdAt, originatingAnnotation, and dynamically calculated buzzValue using modified reuse count logic
- **Dynamic BUZZ Updates**: RDF BUZZ values automatically recalculate when constituent token BUZZ values change using modified reuse count logic
- **Relation Persistence**: Automatic link relations and custom named link relations stored in backend registry for graph visualization
- **BUZZ Cost Calculation**: During annotation creation, system accurately calculates total BUZZ cost by summing all BUZZ (weight) values of tokens associated with the annotation, including positive law, interpretation, and link tokens, accounting for intra-annotation reuse increases, before processing payment with proper validation and deduction logic using modified reuse count calculations
- **Direct Link Token Creation**: When custom link relations are created, link tokens are created immediately with proper BUZZ deduction applied using modified reuse count formula
- **Modified Reuse Count Logic**: For positive law and interpretation tokens: `reuseCount = number of distinct annotations linked - 1`, for link tokens: `reuseCount = max(0, (number of distinct annotations linked ÷ 2) - 1)`, with BUZZ formula `buzzValue = 5 + 2 * reuseCount`
- **Hierarchical Relation Generation**: System automatically generates retrieval-type relations connecting Curations → Swarms → Annotations with consistent reconstruction in getGraphData()
- **Link Token Registry Exclusivity**: Link tokens are stored only in the global token registry without duplication as local nodes or indirect attachment to swarms or curations
- **Strict RDF Link Token Parsing**: Parser enforces exact `[ {positiveLawToken}, <linkToken>, (interpretationToken) ]` pattern exclusively within boxed RDF content and creates link tokens connecting the specified positive law and interpretation tokens
- **RDF-Exclusive Strict Validation**: Strict RDF validation and link token creation is restricted exclusively to boxed RDF content, not available in general annotation text
- **Token-to-Token Link Relations**: Link tokens created from strict RDF validation establish reasoning-type relations between positive law and interpretation tokens with enforced ordering
- **Validation Error Trapping**: System traps with clear error messages when RDF patterns do not match the required format or contain misordered bracket types
- **Data Reset Integration**: Existing RDF and relation data is reset to remove malformed entries before applying strict validation logic
- **Corrected Interpretation Token Linking**: Enforce in relation creation logic that interpretation tokens only connect one-way to their corresponding link tokens via reasoning relations, removing any redundant annotation-interpretation links

## Comprehensive Pruning Audit

### Safe-to-Remove Backend Components

#### Obsolete Multi-Canister Modules
- **buzz.mo** - BUZZ functionality merged into main.mo internal ledger system
- **flea_market.mo** - Marketplace functionality removed from application scope
- **http-outcalls.mo** - HTTP outcall functionality no longer required
- **blob-storage.mo** - Blob storage functionality not used in current implementation
- **access-control.mo** - Access control logic integrated directly into main.mo

#### Deprecated Backend Utilities
- **Multi-canister actor references** - All external canister dependencies removed
- **BUZZ ledger integration** - Replaced with internal BUZZ register in main.mo
- **Marketplace transaction logic** - No longer part of application functionality
- **HTTP request handlers** - External API calls removed from scope
- **Blob upload/download functions** - File storage not required for current features
- **Old multi-bracket RDF parser** - Replaced with strict single-bracket validation parser
- **Placeholder creation logic** - All placeholder-related backend methods and data structures removed

### Safe-to-Remove Frontend Components

#### Deprecated UI Panels
- **OntologyBuilderPanel.tsx** - Replaced by Schema Builder with three-pane layout
- **FleaMarketPanel.tsx** - Marketplace functionality removed from application
- **BuzzDashboard.tsx** - BUZZ display integrated into main interface
- **SwarmViewPanel.tsx** - Merged into unified My Swarms tab

#### Obsolete Frontend References
- **HIVE token references** - Application uses internal BUZZ system only
- **Marketplace UI components** - All marketplace functionality removed
- **External BUZZ ledger displays** - Replaced with internal BUZZ balance display
- **Multi-canister connection logic** - Single canister architecture implemented
- **Placeholder creation messages** - All placeholder-related UI messages and logic removed from LinkAnnotationsDialog and related components

### Safe-to-Remove Dependencies & Hooks

#### Deprecated Actor Hooks
- **useBuzzActor.ts** - BUZZ functionality moved to main actor
- **useFleaMarketActor.ts** - Marketplace functionality removed
- **useHttpOutcallActor.ts** - HTTP outcall functionality not required
- **useBlobStorageActor.ts** - Blob storage not used in current implementation

#### Obsolete Type Definitions
- **BuzzActor interface types** - BUZZ types integrated into main actor interface
- **FleaMarketActor interface types** - Marketplace types no longer needed
- **HttpOutcallActor interface types** - HTTP outcall types not required
- **BlobStorageActor interface types** - Blob storage types not used
- **Placeholder-related type definitions** - All placeholder creation types removed

#### Deprecated Candid Interfaces
- **buzz.did** - BUZZ interface merged into main.did
- **flea_market.did** - Marketplace interface removed
- **http_outcalls.did** - HTTP outcall interface not required
- **blob_storage.did** - Blob storage interface not used

### Safe-to-Remove Configuration Files

#### Deployment Configuration
- **Multi-canister dfx.json entries** - Single canister deployment configuration
- **Canister-specific build scripts** - Consolidated build process for main canister only
- **Inter-canister communication setup** - Single canister architecture eliminates need

#### Environment Variables
- **BUZZ_CANISTER_ID** - Internal BUZZ system doesn't require separate canister ID
- **FLEA_MARKET_CANISTER_ID** - Marketplace functionality removed
- **HTTP_OUTCALL_CANISTER_ID** - HTTP outcall functionality not required
- **BLOB_STORAGE_CANISTER_ID** - Blob storage not used

### Safe-to-Remove Asset Files

#### Deprecated Images
- **Marketplace-related images** - All marketplace UI assets can be removed
- **HIVE token logos** - Application uses BUZZ branding only
- **External service icons** - Single canister architecture eliminates external service references

#### Obsolete Documentation
- **Multi-canister setup guides** - Single canister deployment documentation sufficient
- **BUZZ ledger integration docs** - Internal BUZZ system documentation replaces external ledger docs
- **Marketplace user guides** - Marketplace functionality removed from scope

### Dependency Cleanup Recommendations

#### Package Dependencies
- **@dfinity/ledger** - External ledger integration no longer required
- **HTTP client libraries** - HTTP outcall functionality removed
- **File upload libraries** - Blob storage functionality not used
- **Multi-canister management tools** - Single canister architecture implemented

#### Development Dependencies
- **Canister-specific testing utilities** - Consolidated testing for main canister only
- **Multi-canister deployment tools** - Single canister deployment sufficient
- **Inter-canister communication testing** - Not required for single canister architecture
