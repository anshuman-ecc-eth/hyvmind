import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import { useInternetIdentity } from './useInternetIdentity';
import type { UserRole } from '../backend';
import type { 
  CreateNodeInput, 
  CreateNodeResult, 
  NodeId, 
  GraphData, 
  Token, 
  RDF, 
  AutocompleteResults, 
  Node, 
  JoinRequest, 
  JoinRequestStatus, 
  SwarmSummary,
  UserProfile
} from '../types';
import { Principal } from '@icp-sdk/core/principal';

export function useGetGraphData() {
  const { actor, isFetching } = useActor();

  return useQuery<GraphData>({
    queryKey: ['graphData'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getGraphData();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetAllUserRDFs() {
  const { actor, isFetching } = useActor();

  return useQuery<RDF[]>({
    queryKey: ['allUserRDFs'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return (actor as any).getAllUserRDFs();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetAutocompleteResults() {
  const { actor, isFetching } = useActor();

  return useQuery<AutocompleteResults>({
    queryKey: ['autocompleteResults'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return (actor as any).getUserAutocompleteResults();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useCreateNode() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation<CreateNodeResult, Error, CreateNodeInput>({
    mutationFn: async (input) => {
      if (!actor) throw new Error('Actor not available');
      return (actor as any).createNode(input);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['graphData'] });
      queryClient.invalidateQueries({ queryKey: ['allSwarmMetrics'] });
      queryClient.invalidateQueries({ queryKey: ['swarmData'] });
      queryClient.invalidateQueries({ queryKey: ['swarmMembers'] });
      queryClient.invalidateQueries({ queryKey: ['allSwarmSummaries'] });
    },
  });
}

export function useCreateAnnotationWithTokens() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation<CreateNodeResult, Error, CreateNodeInput>({
    mutationFn: async (input) => {
      if (!actor) throw new Error('Actor not available');
      return (actor as any).createNode(input);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['graphData'] });
      queryClient.invalidateQueries({ queryKey: ['allUserRDFs'] });
      queryClient.invalidateQueries({ queryKey: ['autocompleteResults'] });
      queryClient.invalidateQueries({ queryKey: ['callerBuzzBalance'] });
      queryClient.invalidateQueries({ queryKey: ['allSwarmMetrics'] });
      queryClient.invalidateQueries({ queryKey: ['swarmMetrics'] });
      queryClient.invalidateQueries({ queryKey: ['swarmMembers'] });
      queryClient.invalidateQueries({ queryKey: ['allSwarmSummaries'] });
    },
  });
}

export function useUpvoteAnnotation() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation<void, Error, NodeId>({
    mutationFn: async (annotationId) => {
      if (!actor) throw new Error('Actor not available');
      return (actor as any).upvoteAnnotation(annotationId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['graphData'] });
    },
  });
}

export function useDownvoteAnnotation() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation<void, Error, NodeId>({
    mutationFn: async (annotationId) => {
      if (!actor) throw new Error('Actor not available');
      return (actor as any).downvoteAnnotation(annotationId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['graphData'] });
    },
  });
}

export function useRequestJoinSwarm() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation<void, Error, NodeId>({
    mutationFn: async (swarmId) => {
      if (!actor) throw new Error('Actor not available');
      return (actor as any).requestJoinSwarm(swarmId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pendingJoinRequests'] });
      queryClient.invalidateQueries({ queryKey: ['joinRequestStatus'] });
      queryClient.invalidateQueries({ queryKey: ['swarmData'] });
      queryClient.invalidateQueries({ queryKey: ['swarmMembers'] });
      queryClient.invalidateQueries({ queryKey: ['allSwarmSummaries'] });
    },
  });
}

export function useApproveJoinRequest() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation<void, Error, { swarmId: bigint; requester: Principal }>({
    mutationFn: async ({ swarmId, requester }) => {
      if (!actor) throw new Error('Actor not available');
      return (actor as any).approveJoinRequest(swarmId, requester);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['graphData'] });
      queryClient.invalidateQueries({ queryKey: ['pendingJoinRequests'] });
      queryClient.invalidateQueries({ queryKey: ['joinRequestStatus'] });
      queryClient.invalidateQueries({ queryKey: ['allSwarmMetrics'] });
      queryClient.invalidateQueries({ queryKey: ['swarmMetrics'] });
      queryClient.invalidateQueries({ queryKey: ['swarmData'] });
      queryClient.invalidateQueries({ queryKey: ['swarmMembers'] });
      queryClient.invalidateQueries({ queryKey: ['allSwarmSummaries'] });
    },
  });
}

export function useGetPendingJoinRequests(swarmId: NodeId | null) {
  const { actor, isFetching } = useActor();

  return useQuery<JoinRequest[]>({
    queryKey: ['pendingJoinRequests', swarmId?.toString()],
    queryFn: async () => {
      if (!actor || !swarmId) throw new Error('Actor or swarmId not available');
      return (actor as any).getPendingJoinRequests(swarmId);
    },
    enabled: !!actor && !isFetching && swarmId !== null,
  });
}

export function useGetJoinRequestStatus(swarmId: NodeId | null, requester: Principal | null) {
  const { actor, isFetching } = useActor();

  return useQuery<JoinRequestStatus | null>({
    queryKey: ['joinRequestStatus', swarmId?.toString(), requester?.toString()],
    queryFn: async () => {
      if (!actor || !swarmId || !requester) return null;
      return (actor as any).getJoinRequestStatus(swarmId, requester);
    },
    enabled: !!actor && !isFetching && swarmId !== null && requester !== null,
  });
}

export function useGetSwarmMembers(swarmId: NodeId | null) {
  const { actor, isFetching } = useActor();

  return useQuery<Principal[]>({
    queryKey: ['swarmMembers', swarmId?.toString()],
    queryFn: async () => {
      if (!actor || !swarmId) return [];
      return (actor as any).getSwarmMembers(swarmId);
    },
    enabled: !!actor && !isFetching && swarmId !== null,
  });
}

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation<boolean, Error, { name: string; socialUrl: string }>({
    mutationFn: async ({ name, socialUrl }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserProfile(name, socialUrl);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

export function useClaimDailyBuzzReward() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation<boolean, Error, void>({
    mutationFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return (actor as any).claimDailyReward();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['callerBuzzBalance'] });
    },
  });
}

export function useGetCallerBuzzBalance() {
  const { actor, isFetching } = useActor();

  return useQuery<bigint>({
    queryKey: ['callerBuzzBalance'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return (actor as any).getCallerBuzzBalance();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useResetAllData() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation<boolean, Error, void>({
    mutationFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return (actor as any).resetAllData();
    },
    onSuccess: () => {
      queryClient.clear();
    },
  });
}

export function useGetCallerUserRole() {
  const { actor, isFetching } = useActor();

  return useQuery<UserRole>({
    queryKey: ['callerUserRole'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserRole();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useHasDebugAccess() {
  const { actor, isFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['hasDebugAccess'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.isCallerAdmin();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useIsResetAuthorized() {
  const { actor, isFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['isResetAuthorized'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.isCallerAdmin();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetUserTokens() {
  const { data: graphData, isLoading } = useGetGraphData();
  const { identity } = useInternetIdentity();

  return useQuery<Token[]>({
    queryKey: ['userTokens', identity?.getPrincipal().toString()],
    queryFn: async () => {
      if (!graphData || !identity) return [];
      const userPrincipal = identity.getPrincipal().toString();
      return graphData.tokens.filter(token => token.creator.toString() === userPrincipal);
    },
    enabled: !!graphData && !!identity && !isLoading,
  });
}

export function useGetUserAnnotations() {
  const { data: graphData, isLoading } = useGetGraphData();
  const { identity } = useInternetIdentity();

  return useQuery<Array<{ annotation: Node; cumulativeBuzz: bigint }>>({
    queryKey: ['userAnnotations', identity?.getPrincipal().toString()],
    queryFn: async () => {
      if (!graphData || !identity) return [];
      const userPrincipal = identity.getPrincipal().toString();
      
      const userAnnotations = graphData.nodes.filter(
        node => node.nodeType === 'annotation' && node.owner.toString() === userPrincipal
      );

      return userAnnotations.map(annotation => {
        let cumulativeBuzz = BigInt(0);
        
        const annotationRelations = graphData.relations.filter(
          ([_, rel]) => rel.sourceNodeId === annotation.id
        );

        for (const [_, relation] of annotationRelations) {
          const targetNode = graphData.nodes.find(n => n.id === relation.targetNodeId);
          if (targetNode && targetNode.nodeType === 'token') {
            const tokenName = targetNode.title.toLowerCase().trim();
            const globalToken = graphData.tokens.find(t => t.name === tokenName);
            if (globalToken) {
              cumulativeBuzz += globalToken.buzzValue;
            }
          }
        }

        return { annotation, cumulativeBuzz };
      });
    },
    enabled: !!graphData && !!identity && !isLoading,
  });
}

export function useGetUserRDFs() {
  return useGetAllUserRDFs();
}

export function useGetAllSwarmMetrics() {
  const { data: graphData, isLoading } = useGetGraphData();
  const { actor } = useActor();

  return useQuery<Array<{
    id: NodeId;
    title: string;
    memberCount: bigint;
    annotationCount: bigint;
    totalBuzzEarned: bigint;
    activityStatus: 'active' | 'inactive';
    buzzRegister: bigint;
  }>>({
    queryKey: ['allSwarmMetrics'],
    queryFn: async () => {
      if (!graphData || !actor) return [];
      
      const swarms = graphData.nodes.filter(node => node.nodeType === 'swarm');
      
      const metricsPromises = swarms.map(async (swarm) => {
        const members = await (actor as any).getSwarmMembers(swarm.id);
        const metrics = await (actor as any).getSwarmMetrics(swarm.id);

        return {
          id: swarm.id,
          title: swarm.title,
          memberCount: BigInt(members.length),
          annotationCount: metrics?.annotationCount || BigInt(0),
          totalBuzzEarned: metrics?.totalBuzzEarned || BigInt(0),
          activityStatus: (metrics?.isActive ? 'active' : 'inactive') as 'active' | 'inactive',
          buzzRegister: BigInt(0),
        };
      });

      return Promise.all(metricsPromises);
    },
    enabled: !!graphData && !!actor && !isLoading,
  });
}

export function useGetSwarmMetrics(swarmId: NodeId) {
  const { data: graphData, isLoading } = useGetGraphData();
  const { actor } = useActor();

  return useQuery<{
    id: NodeId;
    title: string;
    memberCount: bigint;
    annotationCount: bigint;
    totalBuzzEarned: bigint;
    activityStatus: 'active' | 'inactive';
    buzzRegister: bigint;
    chat: Array<{ sender: any; timestamp: bigint; content: string }>;
  }>({
    queryKey: ['swarmMetrics', swarmId.toString()],
    queryFn: async () => {
      if (!graphData || !actor) throw new Error('Graph data or actor not available');
      
      const swarm = graphData.nodes.find(node => node.id === swarmId && node.nodeType === 'swarm');
      if (!swarm) throw new Error('Swarm not found');

      const members = await (actor as any).getSwarmMembers(swarmId);
      const metrics = await (actor as any).getSwarmMetrics(swarmId);
      const chat = await (actor as any).getSwarmChatMessages(swarmId);

      const annotationCount = graphData.nodes.filter(
        node => node.nodeType === 'annotation' && node.swarmId === swarmId
      ).length;

      const activityStatus: 'active' | 'inactive' = metrics?.isActive ? 'active' : 'inactive';

      return {
        id: swarm.id,
        title: swarm.title,
        memberCount: BigInt(members.length),
        annotationCount: BigInt(annotationCount),
        totalBuzzEarned: metrics?.totalBuzzEarned || BigInt(0),
        activityStatus,
        buzzRegister: BigInt(0),
        chat: chat || [],
      };
    },
    enabled: !!graphData && !!actor && !isLoading,
  });
}

export function useGetAllSwarmSummaries() {
  const { actor, isFetching } = useActor();

  return useQuery<SwarmSummary[]>({
    queryKey: ['allSwarmSummaries'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getAllSwarmSummaries();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetSwarmData() {
  const { data: allSwarmSummaries, isLoading, error } = useGetAllSwarmSummaries();

  return useQuery<{ joined: SwarmSummary[]; available: SwarmSummary[] }>({
    queryKey: ['swarmData', allSwarmSummaries],
    queryFn: async () => {
      if (!allSwarmSummaries) {
        return { joined: [], available: [] };
      }

      const joined = allSwarmSummaries.filter(swarm => swarm.isMember);
      const available = allSwarmSummaries.filter(swarm => !swarm.isMember);

      return { joined, available };
    },
    enabled: !!allSwarmSummaries && !isLoading,
  });
}
