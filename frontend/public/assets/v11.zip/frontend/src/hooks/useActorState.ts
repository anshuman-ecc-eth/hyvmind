import { useActor } from './useActor';
import { useInternetIdentity } from './useInternetIdentity';
import { type backendInterface } from '../backend';

export function useActorState() {
  const { actor, isFetching: isMainActorFetching } = useActor();
  const { loginStatus } = useInternetIdentity();

  const isActorReady = !!actor && !isMainActorFetching && loginStatus === 'success';
  const areAllActorsReady = isActorReady;

  let error: string | null = null;
  
  if (!actor && !isMainActorFetching && loginStatus === 'success') {
    error = 'Failed to initialize connection to the Internet Computer. Please try refreshing the page.';
  }

  let initializationMessage: string | null = null;
  if (isMainActorFetching && loginStatus === 'success') {
    initializationMessage = 'Initializing canister connection...';
  }

  return {
    actor: actor as backendInterface | null,
    isFetching: isMainActorFetching,
    isActorReady,
    areAllActorsReady,
    initializationMessage,
    isError: !!error,
    error,
  };
}
