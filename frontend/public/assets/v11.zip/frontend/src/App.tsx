import { useInternetIdentity } from './hooks/useInternetIdentity';
import { useGetCallerUserProfile, useSaveCallerUserProfile, useClaimDailyBuzzReward } from './hooks/useQueries';
import { useActorState } from './hooks/useActorState';
import LandingPage from './pages/LandingPage';
import MainApp from './pages/MainApp';
import ProfileSetupDialog from './components/ProfileSetupDialog';
import { Toaster } from './components/ui/sonner';
import { ThemeProvider } from 'next-themes';
import { AlertCircle, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useEffect, useRef } from 'react';

export default function App() {
  const { identity, isInitializing } = useInternetIdentity();
  const { areAllActorsReady, initializationMessage, error: actorError, isFetching } = useActorState();
  const { data: userProfile, isLoading: profileLoading, isFetched } = useGetCallerUserProfile();
  const { mutate: saveProfile, isPending: savingProfile, error: saveError, isSuccess } = useSaveCallerUserProfile();
  const { mutate: claimReward } = useClaimDailyBuzzReward();

  const isAuthenticated = !!identity;
  const showProfileSetup = isAuthenticated && areAllActorsReady && !profileLoading && isFetched && userProfile === null;

  // Track if we've already attempted to claim the daily reward in this session
  const hasAttemptedClaimRef = useRef(false);
  const lastClaimPrincipalRef = useRef<string | null>(null);

  // Attempt to claim daily BUZZ reward after successful login and profile load
  useEffect(() => {
    const currentPrincipal = identity?.getPrincipal().toString() || null;
    
    // Reset claim attempt flag if user changed
    if (currentPrincipal !== lastClaimPrincipalRef.current) {
      hasAttemptedClaimRef.current = false;
      lastClaimPrincipalRef.current = currentPrincipal;
    }

    // Only attempt claim once per session per user
    if (
      isAuthenticated && 
      areAllActorsReady && 
      userProfile && 
      !profileLoading && 
      !hasAttemptedClaimRef.current
    ) {
      hasAttemptedClaimRef.current = true;
      
      claimReward(undefined, {
        onSuccess: (claimed) => {
          // Only show toast if reward was actually claimed
          if (claimed) {
            toast.success('Daily BUZZ reward claimed! +100 BUZZ', {
              description: 'Come back tomorrow for another reward',
            });
          }
        },
        onError: (error: any) => {
          // Silently fail - user already claimed today or other non-critical error
          console.debug('Daily reward claim result:', error?.message || 'Already claimed');
        },
      });
    }
  }, [isAuthenticated, areAllActorsReady, userProfile, profileLoading, claimReward, identity]);

  // Show success toast when profile is saved
  useEffect(() => {
    if (isSuccess) {
      toast.success('Profile saved successfully!');
    }
  }, [isSuccess]);

  // Show error toast when profile save fails
  useEffect(() => {
    if (saveError) {
      toast.error('Failed to save profile. Please try again.');
    }
  }, [saveError]);

  const handleSaveProfile = (name: string, socialUrl: string) => {
    saveProfile({ name, socialUrl });
  };

  if (isInitializing) {
    return (
      <div className="flex h-screen items-center justify-center bg-gradient-to-br from-background via-background to-accent/5">
        <div className="text-center">
          <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto" />
          <p className="text-muted-foreground">Initializing Hyvmind...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <LandingPage />
        <Toaster />
      </ThemeProvider>
    );
  }

  // Show loading state while actor is initializing
  if (!areAllActorsReady && !actorError && isFetching) {
    return (
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <div className="flex h-screen items-center justify-center bg-gradient-to-br from-background via-background to-accent/5">
          <div className="text-center max-w-md mx-auto px-4">
            <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Connecting to Internet Computer</h2>
            <p className="text-muted-foreground mb-2">
              {initializationMessage || 'Initializing secure connection...'}
            </p>
            <div className="flex items-center justify-center gap-2 mt-4">
              <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
              <div className="h-2 w-2 rounded-full bg-primary animate-pulse delay-75" />
              <div className="h-2 w-2 rounded-full bg-primary animate-pulse delay-150" />
            </div>
          </div>
        </div>
        <Toaster />
      </ThemeProvider>
    );
  }

  // Show error state if actor initialization failed
  if (actorError) {
    return (
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <div className="flex h-screen items-center justify-center bg-gradient-to-br from-background via-background to-accent/5">
          <div className="text-center max-w-md mx-auto px-4">
            <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Connection Error</h2>
            <p className="text-muted-foreground mb-4">
              Failed to connect to the Internet Computer network.
            </p>
            <p className="text-sm text-muted-foreground mb-6">
              {actorError}
            </p>
            <button
              onClick={() => window.location.reload()}
              className="px-6 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
            >
              Retry Connection
            </button>
          </div>
        </div>
        <Toaster />
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      {showProfileSetup ? (
        <ProfileSetupDialog
          onSave={handleSaveProfile}
          isSaving={savingProfile}
          error={saveError?.message}
        />
      ) : (
        <MainApp userProfile={userProfile ?? null} />
      )}
      <Toaster />
    </ThemeProvider>
  );
}
