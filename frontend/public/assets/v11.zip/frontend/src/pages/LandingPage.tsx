import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Button } from '../components/ui/button';
import { Network, Sparkles, Users, ArrowRight } from 'lucide-react';
import ThemeToggle from '../components/ThemeToggle';
import { useTheme } from 'next-themes';

export default function LandingPage() {
  const { login, isLoggingIn } = useInternetIdentity();
  const { resolvedTheme } = useTheme();

  const logoSrc = resolvedTheme === 'dark' 
    ? '/assets/hyvmind_logo white, transparent.png'
    : '/assets/hyvmind_logo black, transparent.png';

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>
      
      <div className="container mx-auto px-4 py-16">
        <header className="mb-20 text-center">
          <div className="mb-6 flex justify-center">
            <div className="relative">
              <div className="absolute inset-0 animate-pulse rounded-full bg-primary/20 blur-2xl" />
              <img 
                src={logoSrc}
                alt="hyvmind Logo" 
                className="relative h-16 w-16 object-contain"
              />
            </div>
          </div>
          <h1 className="mb-4 text-5xl font-bold tracking-tight">
            hyvmind
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            join swarms, build annotations, create buzz
          </p>
        </header>

        <div className="mb-16 flex justify-center">
          <Button
            onClick={login}
            disabled={isLoggingIn}
            size="lg"
            className="group relative overflow-hidden px-8 py-6 text-lg"
          >
            {isLoggingIn ? (
              <>
                <div className="mr-2 h-5 w-5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                Connecting...
              </>
            ) : (
              <>
                Get Started
                <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
              </>
            )}
          </Button>
        </div>

        <div className="grid gap-8 md:grid-cols-3 max-w-5xl mx-auto">
          <FeatureCard
            icon={<Users className="h-8 w-8" />}
            title="Collaborative Tokens"
            description="Construct token-sequences with fellow-researchers"
          />
          <FeatureCard
            icon={<Network className="h-8 w-8" />}
            title="Visual Graph"
            description="See your community's knowledge come alive with interactive graphs"
          />
          <FeatureCard
            icon={<Sparkles className="h-8 w-8" />}
            title="Custom Ontologies"
            description="Build ontologies that solve real-world problems"
          />
        </div>

        <footer className="mt-20 text-center text-sm text-muted-foreground">
          <p>
            © 2025. Built with love using{' '}
            <a
              href="https://caffeine.ai"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              caffeine.ai
            </a>
          </p>
        </footer>
      </div>
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="group relative overflow-hidden rounded-lg border bg-card p-6 transition-all hover:shadow-lg">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
      <div className="relative">
        <div className="mb-4 inline-flex rounded-lg bg-primary/10 p-3 text-primary">
          {icon}
        </div>
        <h3 className="mb-2 text-lg font-semibold">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}
