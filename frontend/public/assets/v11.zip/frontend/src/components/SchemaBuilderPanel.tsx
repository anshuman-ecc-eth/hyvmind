import { useActorState } from '../hooks/useActorState';
import { useGetUserTokens, useGetUserAnnotations, useGetUserRDFs } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Loader2, BookOpen, Coins, FileText, Sparkles, ArrowRight } from 'lucide-react';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { RDF, TokenType } from '../types';

export default function SchemaBuilderPanel() {
  const { isActorReady } = useActorState();
  const { data: userTokens, isLoading: tokensLoading } = useGetUserTokens();
  const { data: userAnnotations, isLoading: annotationsLoading } = useGetUserAnnotations();
  const { data: userRDFs, isLoading: rdfsLoading } = useGetUserRDFs();

  if (!isActorReady) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground">Connecting to network...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full overflow-auto bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="space-y-6">
          {/* Header */}
          <div className="space-y-2">
            <h2 className="text-3xl font-bold flex items-center gap-2">
              <BookOpen className="h-8 w-8 text-primary" />
              Schema Builder
            </h2>
            <p className="text-muted-foreground">
              View your tokens, annotations, and RDF triples extracted from your content
            </p>
          </div>

          {/* Three-Pane Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Pane 1: My Tokens */}
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Coins className="h-5 w-5 text-primary" />
                  My Tokens
                </CardTitle>
                <CardDescription>
                  Tokens you've created with their current BUZZ values and types
                </CardDescription>
              </CardHeader>
              <CardContent>
                {tokensLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                ) : !userTokens || userTokens.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground text-sm">
                    No tokens created yet. Create annotations with {'{token}'} or (token) syntax to extract tokens.
                  </div>
                ) : (
                  <ScrollArea className="h-[400px] pr-4">
                    <div className="space-y-3">
                      {userTokens.map((token) => (
                        <div
                          key={token.id.toString()}
                          className="p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <p className="font-medium text-sm truncate">
                                  {token.name}
                                </p>
                                <Badge 
                                  variant={
                                    token.tokenType === TokenType.positiveLaw 
                                      ? "default" 
                                      : token.tokenType === TokenType.interpretation
                                      ? "secondary"
                                      : "outline"
                                  }
                                  className="text-xs"
                                >
                                  {token.tokenType === TokenType.positiveLaw 
                                    ? 'Law' 
                                    : token.tokenType === TokenType.interpretation
                                    ? 'Interp'
                                    : 'Link'}
                                </Badge>
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                Reused {token.reuseCount.toString()} times
                              </p>
                            </div>
                            <div className="flex-shrink-0">
                              <span className="inline-flex items-center px-2 py-1 rounded-md bg-primary/10 text-primary text-xs font-semibold">
                                {token.buzzValue.toString()} BUZZ
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>

            {/* Pane 2: My Annotations */}
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <FileText className="h-5 w-5 text-primary" />
                  My Annotations
                </CardTitle>
                <CardDescription>
                  Your annotations with cumulative BUZZ from all tokens
                </CardDescription>
              </CardHeader>
              <CardContent>
                {annotationsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                ) : !userAnnotations || userAnnotations.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground text-sm">
                    No annotations created yet
                  </div>
                ) : (
                  <ScrollArea className="h-[400px] pr-4">
                    <div className="space-y-3">
                      {userAnnotations.map(({ annotation, cumulativeBuzz }) => (
                        <div
                          key={annotation.id.toString()}
                          className="p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-sm truncate">
                                {annotation.title}
                              </p>
                              {annotation.bracketedTokenSequence && (
                                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                                  {annotation.bracketedTokenSequence}
                                </p>
                              )}
                            </div>
                            <div className="flex-shrink-0">
                              <span className="inline-flex items-center px-2 py-1 rounded-md bg-secondary text-secondary-foreground text-xs font-semibold">
                                Σ {cumulativeBuzz.toString()} BUZZ
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>

            {/* Pane 3: My RDFs */}
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Sparkles className="h-5 w-5 text-primary" />
                  My RDFs
                </CardTitle>
                <CardDescription>
                  RDF triples extracted from your annotations using [subject, predicate, object] syntax
                </CardDescription>
              </CardHeader>
              <CardContent>
                {rdfsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                  </div>
                ) : !userRDFs || userRDFs.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground text-sm">
                    <p>No RDF triples created yet.</p>
                    <p className="mt-2 text-xs">
                      Use [subject, predicate, object] syntax in annotations to create RDF triples.
                    </p>
                  </div>
                ) : (
                  <ScrollArea className="h-[400px] pr-4">
                    <div className="space-y-3">
                      {userRDFs.map((rdf: RDF) => (
                        <div
                          key={rdf.id.toString()}
                          className="p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                        >
                          <div className="space-y-2">
                            {/* RDF Triple Display */}
                            <div className="flex items-center gap-2 text-sm">
                              <Badge variant="outline" className="font-mono text-xs">
                                {rdf.subject}
                              </Badge>
                              <ArrowRight className="h-3 w-3 text-muted-foreground" />
                              <Badge variant="secondary" className="font-mono text-xs">
                                {rdf.predicate}
                              </Badge>
                              <ArrowRight className="h-3 w-3 text-muted-foreground" />
                              <Badge variant="outline" className="font-mono text-xs">
                                {rdf.rdfObject}
                              </Badge>
                            </div>
                            
                            {/* Metadata */}
                            <div className="flex items-center justify-between text-xs text-muted-foreground">
                              <span>
                                From annotation #{rdf.originatingAnnotation.toString()}
                              </span>
                              <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-primary/10 text-primary font-semibold">
                                {rdf.cumulativeBuzz.toString()} BUZZ
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
