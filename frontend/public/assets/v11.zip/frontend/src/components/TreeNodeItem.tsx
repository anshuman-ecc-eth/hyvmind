import { useState, useMemo } from 'react';
import { ChevronRight, ChevronDown, ThumbsUp, ThumbsDown, CheckCircle2, Users, Link, Plus, Clock } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useRequestJoinSwarm, useGetGraphData, useGetJoinRequestStatus, useUpvoteAnnotation, useDownvoteAnnotation } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { NodeType, TokenType, Node } from '../types';
import { toast } from 'sonner';
import LinkAnnotationsDialog from './LinkAnnotationsDialog';
import CreateNodeDialog from './CreateNodeDialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';

interface TreeNodeItemProps {
  node: Node;
  children: Node[];
  level: number;
  onNodeClick?: (nodeId: bigint) => void;
  swarmMemberCounts?: Map<bigint, number>;
  userJoinedSwarms?: Set<bigint>;
}

export default function TreeNodeItem({ 
  node, 
  children, 
  level, 
  onNodeClick,
  swarmMemberCounts,
  userJoinedSwarms,
}: TreeNodeItemProps) {
  const [isExpanded, setIsExpanded] = useState(level < 2);
  const [linkDialogOpen, setLinkDialogOpen] = useState(false);
  const [createNodeDialogOpen, setCreateNodeDialogOpen] = useState(false);
  const [upvoteDialogOpen, setUpvoteDialogOpen] = useState(false);
  const [downvoteDialogOpen, setDownvoteDialogOpen] = useState(false);
  const { mutate: requestJoinSwarm, isPending: isRequesting } = useRequestJoinSwarm();
  const { mutate: upvoteAnnotation, isPending: isUpvoting } = useUpvoteAnnotation();
  const { mutate: downvoteAnnotation, isPending: isDownvoting } = useDownvoteAnnotation();
  const { identity } = useInternetIdentity();
  const { data: graphData } = useGetGraphData();
  
  const { data: joinRequestStatus } = useGetJoinRequestStatus(
    node.nodeType === NodeType.swarm ? node.id : null,
    identity ? identity.getPrincipal() : null
  );

  // Build children map from the flat children array
  const childrenByParent = useMemo(() => {
    const map = new Map<bigint, Node[]>();
    children.forEach((child) => {
      const parentId = child.parentId;
      if (parentId !== undefined) {
        if (!map.has(parentId)) {
          map.set(parentId, []);
        }
        map.get(parentId)!.push(child);
      }
    });
    return map;
  }, [children]);

  const directChildren = childrenByParent.get(node.id) || [];
  const hasChildren = directChildren.length > 0;
  const isOwner = identity ? node.owner.toString() === identity.getPrincipal().toString() : false;
  const isSwarmMember = userJoinedSwarms?.has(node.id) || false;
  const hasSwarmAccess = isOwner || isSwarmMember;

  // Check if user has access to the annotation's swarm (for voting)
  const hasAnnotationAccess = useMemo(() => {
    if (!identity || node.nodeType !== NodeType.annotation) return false;
    if (!node.swarmId) return false;
    
    // Owner always has access
    if (isOwner) return true;
    
    // Check if user is a member of the annotation's swarm
    return userJoinedSwarms?.has(node.swarmId) || false;
  }, [identity, node, isOwner, userJoinedSwarms]);

  // Calculate cumulative BUZZ for the annotation
  const annotationCumulativeBuzz = useMemo(() => {
    if (node.nodeType !== NodeType.annotation || !graphData) return BigInt(0);
    
    let totalBuzz = BigInt(0);
    const annotationRelations = graphData.relations.filter(
      ([_, rel]) => rel.sourceNodeId === node.id
    );

    for (const [_, relation] of annotationRelations) {
      const targetNode = graphData.nodes.find(n => n.id === relation.targetNodeId);
      if (targetNode && targetNode.nodeType === NodeType.token) {
        const tokenName = targetNode.title.toLowerCase().trim();
        const globalToken = graphData.tokens.find(t => t.name === tokenName);
        if (globalToken) {
          totalBuzz += globalToken.buzzValue;
        }
      }
    }

    return totalBuzz;
  }, [node, graphData]);

  // Get token type for token nodes
  const getTokenType = (tokenNode: Node): TokenType | null => {
    if (tokenNode.nodeType !== NodeType.token) return null;
    
    const tokenName = tokenNode.title.toLowerCase().trim();
    const token = graphData?.tokens.find(t => t.name === tokenName);
    return token?.tokenType || null;
  };

  // Get token type label
  const getTokenTypeLabel = (tokenType: TokenType | null): string => {
    if (!tokenType) return 'Token';
    
    switch (tokenType) {
      case TokenType.positiveLaw:
        return 'Positive Law';
      case TokenType.interpretation:
        return 'Interpretation';
      case TokenType.link:
        return 'Link';
      default:
        return 'Token';
    }
  };

  const handleToggle = () => {
    if (hasChildren) {
      setIsExpanded(!isExpanded);
    }
  };

  const handleRequestJoinSwarm = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!identity) {
      toast.error('Please log in to request to join swarms');
      return;
    }

    if (isOwner) {
      toast.info('You are the creator of this swarm');
      return;
    }

    if (isSwarmMember) {
      toast.info('You are already a member of this swarm');
      return;
    }

    if (joinRequestStatus) {
      toast.info('You already have a pending join request for this swarm');
      return;
    }

    requestJoinSwarm(node.id, {
      onSuccess: () => {
        toast.success('Join request submitted! Waiting for member approval.');
      },
      onError: (error) => {
        if (error.message.includes('Maximum swarm membership limit reached')) {
          toast.error('You have reached the maximum limit of 4 swarm memberships');
        } else if (error.message.includes('Already a member')) {
          toast.info('You are already a member of this swarm');
        } else {
          toast.error(error.message || 'Failed to submit join request');
        }
      },
    });
  };

  const handleLinkAnnotations = (e: React.MouseEvent) => {
    e.stopPropagation();
    setLinkDialogOpen(true);
  };

  const handleCreateChildNode = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCreateNodeDialogOpen(true);
  };

  const handleUpvoteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!identity) {
      toast.error('Please log in to vote on annotations');
      return;
    }

    if (!hasAnnotationAccess) {
      toast.error('You must be a member of this swarm to vote');
      return;
    }

    if (isOwner) {
      toast.error('Annotation creators cannot vote on their own annotations');
      return;
    }

    setUpvoteDialogOpen(true);
  };

  const handleDownvoteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!identity) {
      toast.error('Please log in to vote on annotations');
      return;
    }

    if (!hasAnnotationAccess) {
      toast.error('You must be a member of this swarm to vote');
      return;
    }

    if (isOwner) {
      toast.error('Annotation creators cannot vote on their own annotations');
      return;
    }

    setDownvoteDialogOpen(true);
  };

  const handleConfirmUpvote = () => {
    upvoteAnnotation(node.id, {
      onSuccess: () => {
        toast.success('Annotation upvoted successfully');
        setUpvoteDialogOpen(false);
      },
      onError: (error) => {
        if (error.message.includes('cannot vote on their own annotations')) {
          toast.error('Annotation creators cannot vote on their own annotations');
        } else if (error.message.includes('already voted')) {
          toast.error('You have already voted on this annotation');
        } else if (error.message.includes('Must be swarm member')) {
          toast.error('You must be a swarm member to vote on annotations');
        } else {
          toast.error(error.message || 'Failed to upvote annotation');
        }
        setUpvoteDialogOpen(false);
      },
    });
  };

  const handleConfirmDownvote = () => {
    downvoteAnnotation(node.id, {
      onSuccess: () => {
        toast.success('Annotation downvoted successfully');
        setDownvoteDialogOpen(false);
      },
      onError: (error) => {
        if (error.message.includes('cannot vote on their own annotations')) {
          toast.error('Annotation creators cannot vote on their own annotations');
        } else if (error.message.includes('already voted')) {
          toast.error('You have already voted on this annotation');
        } else if (error.message.includes('Must be swarm member')) {
          toast.error('You must be a swarm member to vote on annotations');
        } else {
          toast.error(error.message || 'Failed to downvote annotation');
        }
        setDownvoteDialogOpen(false);
      },
    });
  };

  // Determine if this node can have children created
  const canCreateChildren = (): boolean => {
    if (!identity) return false;
    
    // Curations: anyone can create swarms
    if (node.nodeType === NodeType.curation) {
      return true;
    }
    
    // Swarms: only creator or members can create annotations
    if (node.nodeType === NodeType.swarm) {
      return hasSwarmAccess;
    }
    
    // Annotations and tokens: no child creation
    return false;
  };

  const getNodeIcon = () => {
    if (node.nodeType === NodeType.token) {
      const tokenType = getTokenType(node);
      const typeLabel = getTokenTypeLabel(tokenType);
      return <Badge variant="outline" className="text-xs px-1.5 py-0.5">{typeLabel}</Badge>;
    }
    if (hasChildren) {
      return isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />;
    }
    return <div className="w-4" />;
  };

  const getNodeColor = () => {
    switch (node.nodeType) {
      case NodeType.curation:
        return 'text-yellow-600 dark:text-yellow-400';
      case NodeType.swarm:
        return 'text-green-600 dark:text-green-400';
      case NodeType.annotation:
        return 'text-purple-600 dark:text-purple-400';
      case NodeType.token:
        const tokenType = getTokenType(node);
        if (tokenType === TokenType.positiveLaw) {
          return 'text-blue-600 dark:text-blue-400';
        } else if (tokenType === TokenType.interpretation) {
          return 'text-pink-600 dark:text-pink-400';
        } else if (tokenType === TokenType.link) {
          return 'text-green-600 dark:text-green-400';
        }
        return 'text-orange-600 dark:text-orange-400';
      default:
        return 'text-foreground';
    }
  };

  const verificationRatio = node.downvotes > 0n 
    ? Number(node.upvotes) / Number(node.downvotes) 
    : Number(node.upvotes);

  const memberCount = node.nodeType === NodeType.swarm && swarmMemberCounts 
    ? swarmMemberCounts.get(node.id) || 0 
    : 0;

  // Count token children
  const tokenChildren = directChildren.filter(child => child.nodeType === NodeType.token);
  const tokenCount = tokenChildren.length;

  // Determine if voting buttons should be disabled
  const votingDisabled = !hasAnnotationAccess || isOwner;
  const votingTooltip = !identity 
    ? "Log in to vote" 
    : isOwner 
    ? "Creators cannot vote on their own annotations" 
    : !hasAnnotationAccess 
    ? "Join swarm to vote" 
    : "Vote on annotation";

  return (
    <>
      <div className="group">
        <div
          className={`flex items-center gap-2 py-1.5 px-2 rounded hover:bg-accent cursor-pointer transition-colors ${getNodeColor()}`}
          style={{ paddingLeft: `${level * 1.5 + 0.5}rem` }}
          onClick={handleToggle}
        >
          <button
            onClick={handleToggle}
            className="flex items-center justify-center w-auto h-4 hover:bg-accent-foreground/10 rounded transition-colors"
          >
            {getNodeIcon()}
          </button>

          <span className="flex-1 truncate text-sm font-medium">
            {node.title}
            {node.verified && (
              <CheckCircle2 className="inline-block ml-1 h-3 w-3 text-blue-500" />
            )}
          </span>

          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            {/* Create child node button for Curations and Swarms */}
            {canCreateChildren() && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleCreateChildNode}
                className="h-6 px-2 text-xs gap-1"
                title={node.nodeType === NodeType.curation ? 'Create Swarm' : 'Create Annotation'}
              >
                <Plus className="h-3 w-3" />
              </Button>
            )}

            {node.nodeType === NodeType.swarm && (
              <>
                <Badge variant="outline" className="text-xs gap-1">
                  <Users className="h-3 w-3" />
                  {memberCount}
                </Badge>
                {!isOwner && !isSwarmMember && (
                  <>
                    {joinRequestStatus ? (
                      <Badge variant="outline" className="text-xs gap-1">
                        <Clock className="h-3 w-3" />
                        Pending
                      </Badge>
                    ) : (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleRequestJoinSwarm}
                        disabled={isRequesting}
                        className="h-6 px-2 text-xs"
                      >
                        Request
                      </Button>
                    )}
                  </>
                )}
              </>
            )}

            {node.nodeType === NodeType.annotation && (
              <>
                {tokenCount > 0 && (
                  <Badge variant="outline" className="text-xs">
                    {tokenCount} token{tokenCount !== 1 ? 's' : ''}
                  </Badge>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLinkAnnotations}
                  disabled={!hasSwarmAccess}
                  className="h-6 px-2 text-xs gap-1"
                  title="Link to other annotations"
                >
                  <Link className="h-3 w-3" />
                </Button>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleUpvoteClick}
                    disabled={votingDisabled || isUpvoting}
                    className="h-6 px-1.5"
                    title={votingTooltip}
                  >
                    <ThumbsUp className="h-3 w-3" />
                  </Button>
                  <span className="text-xs font-medium min-w-[2ch] text-center">
                    {node.upvotes.toString()}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleDownvoteClick}
                    disabled={votingDisabled || isDownvoting}
                    className="h-6 px-1.5"
                    title={votingTooltip}
                  >
                    <ThumbsDown className="h-3 w-3" />
                  </Button>
                  <span className="text-xs font-medium min-w-[2ch] text-center">
                    {node.downvotes.toString()}
                  </span>
                </div>
                {verificationRatio > 0 && (
                  <Badge variant="outline" className="text-xs">
                    {verificationRatio.toFixed(2)}
                  </Badge>
                )}
              </>
            )}

            {node.nodeType !== NodeType.token && (
              <Badge variant="outline" className="text-xs capitalize">
                {node.nodeType}
              </Badge>
            )}
          </div>
        </div>

        {isExpanded && hasChildren && (
          <div className="ml-2">
            {directChildren
              .sort((a, b) => {
                // Sort annotations by verification ratio (descending)
                if (a.nodeType === NodeType.annotation && b.nodeType === NodeType.annotation) {
                  const ratioA = Number(a.downvotes) > 0 
                    ? Number(a.upvotes) / Number(a.downvotes) 
                    : Number(a.upvotes);
                  const ratioB = Number(b.downvotes) > 0 
                    ? Number(b.upvotes) / Number(b.downvotes) 
                    : Number(b.upvotes);
                  return ratioB - ratioA;
                }
                return 0;
              })
              .map((child) => {
                // Get all descendants for this child from the children array
                const childDescendants = children.filter(n => {
                  // Check if this node is a descendant of child
                  let current = n;
                  while (current.parentId !== undefined) {
                    if (current.parentId === child.id) {
                      return true;
                    }
                    // Find parent in children array
                    const parent = children.find(p => p.id === current.parentId);
                    if (!parent) break;
                    current = parent;
                  }
                  return false;
                });
                
                return (
                  <TreeNodeItem
                    key={child.id.toString()}
                    node={child}
                    children={childDescendants}
                    level={level + 1}
                    onNodeClick={onNodeClick}
                    swarmMemberCounts={swarmMemberCounts}
                    userJoinedSwarms={userJoinedSwarms}
                  />
                );
              })}
          </div>
        )}
      </div>

      {/* Link Annotations Dialog */}
      {node.nodeType === NodeType.annotation && (
        <LinkAnnotationsDialog
          open={linkDialogOpen}
          onOpenChange={setLinkDialogOpen}
          sourceAnnotationId={node.id}
        />
      )}

      {/* Create Child Node Dialog */}
      <CreateNodeDialog
        open={createNodeDialogOpen}
        onOpenChange={setCreateNodeDialogOpen}
        parentId={node.id}
      />

      {/* Upvote Confirmation Dialog */}
      <AlertDialog open={upvoteDialogOpen} onOpenChange={setUpvoteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Upvote Annotation</AlertDialogTitle>
            <AlertDialogDescription className="space-y-3">
              <p>
                You are about to upvote the annotation <strong>"{node.title}"</strong>.
              </p>
              <div className="bg-muted p-3 rounded-lg space-y-2 text-sm">
                <h4 className="font-semibold">Voting Details:</h4>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  <li>
                    Your vote will be recorded and cannot be changed
                  </li>
                  <li>
                    This will increase the annotation's upvote count
                  </li>
                  <li>
                    The verification ratio will be updated based on all votes
                  </li>
                  <li>
                    Only swarm members (non-creators) can vote on annotations
                  </li>
                </ul>
              </div>
              <p className="text-xs text-muted-foreground italic">
                Note: Your vote is permanent and cannot be undone. Make sure you have reviewed the annotation content.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isUpvoting}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmUpvote} disabled={isUpvoting}>
              {isUpvoting ? 'Upvoting...' : 'Confirm Upvote'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Downvote Confirmation Dialog */}
      <AlertDialog open={downvoteDialogOpen} onOpenChange={setDownvoteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Downvote Annotation</AlertDialogTitle>
            <AlertDialogDescription className="space-y-3">
              <p>
                You are about to downvote the annotation <strong>"{node.title}"</strong>.
              </p>
              <div className="bg-muted p-3 rounded-lg space-y-2 text-sm">
                <h4 className="font-semibold">Voting Details:</h4>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  <li>
                    Your vote will be recorded and cannot be changed
                  </li>
                  <li>
                    This will increase the annotation's downvote count
                  </li>
                  <li>
                    The verification ratio will be updated based on all votes
                  </li>
                  <li>
                    Downvotes help maintain annotation quality through community feedback
                  </li>
                </ul>
              </div>
              <p className="text-xs text-muted-foreground italic">
                Note: Your vote is permanent and cannot be undone. Make sure you have reviewed the annotation content.
              </p>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDownvoting}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDownvote} disabled={isDownvoting}>
              {isDownvoting ? 'Downvoting...' : 'Confirm Downvote'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
