import { useHasDebugAccess, useResetAllData, useIsResetAuthorized, useGetGraphData } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { AlertCircle, Database, Trash2, CheckCircle, ShieldAlert, Coins } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from './ui/alert-dialog';

export default function DebugPanel() {
  const { data: hasAccess, isLoading: isCheckingAccess } = useHasDebugAccess();
  const { data: isResetAuthorized, isLoading: isCheckingResetAuth } = useIsResetAuthorized();
  const { data: graphData, isLoading: isLoadingGraphData } = useGetGraphData();
  const { mutate: resetAllData, isPending: isResetting } = useResetAllData();

  const handleResetData = () => {
    resetAllData(undefined, {
      onSuccess: () => {
        toast.success('All data reset successfully', {
          description: 'The graph environment has been cleared. All components will initialize with clean state.',
          icon: <CheckCircle className="h-5 w-5" />,
        });
      },
      onError: (error) => {
        toast.error('Failed to reset data', {
          description: error.message || 'An error occurred while resetting the data. Please try again.',
        });
      },
    });
  };

  // Calculate token statistics from graph data
  const tokenStats = graphData ? {
    totalTokens: BigInt(graphData.tokens.length),
    mostReusedTokens: graphData.tokens
      .map(token => [token.name, token.reuseCount] as [string, bigint])
      .sort((a, b) => Number(b[1]) - Number(a[1]))
  } : null;

  if (isCheckingAccess) {
    return (
      <div className="h-full flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto">
          <div className="container mx-auto p-6 space-y-6">
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-[#d4a017] border-t-transparent mx-auto" />
                <p className="text-muted-foreground">Checking access permissions...</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div className="h-full flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto">
          <div className="container mx-auto p-6 space-y-6">
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                You do not have permission to access the Debug Panel. This panel is restricted to authorized administrators only.
              </AlertDescription>
            </Alert>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <div className="flex-1 overflow-y-auto">
        <div className="container mx-auto p-6 space-y-6 pb-24">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Debug Panel</h1>
              <p className="text-muted-foreground mt-1">
                System administration and debugging tools
              </p>
            </div>
            <Badge variant="outline" className="bg-[#d4a017]/10 text-[#d4a017] border-[#d4a017]">
              Admin Access
            </Badge>
          </div>

          {/* Global Token Registry Statistics */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Coins className="h-5 w-5" />
                <CardTitle>Global Token Registry</CardTitle>
              </div>
              <CardDescription>
                Statistics from the unified global token registry
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingGraphData ? (
                <div className="flex items-center justify-center py-8">
                  <div className="text-center">
                    <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-[#d4a017] border-t-transparent mx-auto" />
                    <p className="text-sm text-muted-foreground">Loading token statistics...</p>
                  </div>
                </div>
              ) : tokenStats ? (
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">Total Tokens</p>
                    <p className="text-2xl font-bold">{tokenStats.totalTokens.toString()}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Unique tokens extracted from annotations
                    </p>
                  </div>
                  
                  {tokenStats.mostReusedTokens.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm">Global Most Reused Tokens</h4>
                      <p className="text-xs text-muted-foreground">
                        Sorted by reuse count (descending). Weight formula: 5 + (5 × reuse_count)
                      </p>
                      <div className="space-y-2">
                        {tokenStats.mostReusedTokens.slice(0, 10).map(([name, count], index) => (
                          <div
                            key={index}
                            className="flex items-center justify-between p-3 border rounded-lg bg-muted/30"
                          >
                            <div className="flex-1 min-w-0">
                              <p className="font-medium truncate">{name}</p>
                              <p className="text-xs text-muted-foreground">
                                Weight: {(5n + 5n * count).toString()}
                              </p>
                            </div>
                            <Badge variant="outline" className="ml-2">
                              {count.toString()} reuses
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No token statistics available
                </p>
              )}
            </CardContent>
          </Card>

          {/* Data Management Section */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                <CardTitle>Data Management</CardTitle>
              </div>
              <CardDescription>
                Manage system data and perform administrative operations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {isCheckingResetAuth ? (
                <div className="flex items-center justify-center py-8">
                  <div className="text-center">
                    <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-[#d4a017] border-t-transparent mx-auto" />
                    <p className="text-sm text-muted-foreground">Checking authorization...</p>
                  </div>
                </div>
              ) : isResetAuthorized ? (
                <div className="p-4 border border-destructive/50 rounded-lg bg-destructive/5">
                  <div className="flex items-start gap-3">
                    <Trash2 className="h-5 w-5 text-destructive mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <h3 className="font-semibold text-destructive mb-1">Reset All Data</h3>
                      <p className="text-sm text-muted-foreground mb-3">
                        This will permanently delete all nodes, relations, votes, swarm memberships, chat messages, user profiles, BUZZ balances, daily rewards, and global token registry. 
                        This action cannot be undone.
                      </p>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" size="sm" disabled={isResetting}>
                            {isResetting ? (
                              <>
                                <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                                Resetting...
                              </>
                            ) : (
                              <>
                                <Trash2 className="h-4 w-4 mr-2" />
                                Reset All Data
                              </>
                            )}
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure? This will permanently erase all data.</AlertDialogTitle>
                            <AlertDialogDescription className="space-y-3">
                              <p>
                                This action cannot be undone. This will permanently delete:
                              </p>
                              <ul className="list-disc list-inside space-y-1 text-sm">
                                <li>All nodes (curations, swarms, annotations, tokens)</li>
                                <li>All global token registry entries</li>
                                <li>All relations between nodes</li>
                                <li>All votes and verification status</li>
                                <li>All swarm membership and chat data</li>
                                <li>All user profiles</li>
                                <li>All BUZZ balances and daily reward claims</li>
                                <li>All RDF triples</li>
                              </ul>
                              <p className="font-semibold text-foreground">
                                The system will be completely reset to initial state.
                              </p>
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={handleResetData}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Yes, reset all data
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 border border-muted rounded-lg bg-muted/30">
                  <div className="flex items-start gap-3">
                    <ShieldAlert className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <h3 className="font-semibold mb-1">Reset All Data</h3>
                      <p className="text-sm text-muted-foreground mb-3">
                        This operation is restricted to administrators only. You do not have permission to reset all data.
                      </p>
                      <Button variant="outline" size="sm" disabled>
                        <Trash2 className="h-4 w-4 mr-2" />
                        Reset All Data (Restricted)
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              <div className="p-4 border rounded-lg bg-muted/30">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">Post-Reset Validation</h3>
                    <p className="text-sm text-muted-foreground">
                      After resetting, the system will automatically validate that all components can initialize cleanly. 
                      You can verify this by checking that Tree View, Graph View, and other panels show empty states without errors.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
