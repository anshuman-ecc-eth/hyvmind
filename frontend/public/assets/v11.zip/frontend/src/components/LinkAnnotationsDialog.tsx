import { useState, useEffect, useMemo } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useGetGraphData } from '../hooks/useQueries';
import { useActorState } from '../hooks/useActorState';
import { AlertCircle, Plus, X } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { NodeType } from '../types';
import { toast } from 'sonner';

interface LinkAnnotationsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sourceAnnotationId: bigint;
}

interface LinkRelationInput {
  targetAnnotationId: bigint;
  relationName: string;
}

export default function LinkAnnotationsDialog({ 
  open, 
  onOpenChange,
  sourceAnnotationId,
}: LinkAnnotationsDialogProps) {
  const [relations, setRelations] = useState<LinkRelationInput[]>([
    { targetAnnotationId: BigInt(0), relationName: '' }
  ]);

  const { isActorReady, error: actorError } = useActorState();
  const { data: graphData } = useGetGraphData();

  // Filter to only show annotation nodes
  const annotationNodes = useMemo(() => {
    if (!graphData?.nodes) return [];
    return graphData.nodes.filter(node => node.nodeType === NodeType.annotation);
  }, [graphData]);

  useEffect(() => {
    if (open) {
      setRelations([{ targetAnnotationId: BigInt(0), relationName: '' }]);
    }
  }, [open]);

  const handleAddRelation = () => {
    setRelations([...relations, { targetAnnotationId: BigInt(0), relationName: '' }]);
  };

  const handleRemoveRelation = (index: number) => {
    if (relations.length > 1) {
      setRelations(relations.filter((_, i) => i !== index));
    }
  };

  const handleRelationChange = (index: number, field: 'targetAnnotationId' | 'relationName', value: string | bigint) => {
    const newRelations = [...relations];
    if (field === 'targetAnnotationId') {
      newRelations[index][field] = typeof value === 'string' ? BigInt(value) : value;
    } else {
      newRelations[index][field] = value as string;
    }
    setRelations(newRelations);
  };

  const handleCreateRelations = (e: React.FormEvent) => {
    e.preventDefault();
    
    toast.error('Link relation creation is not yet implemented in the backend');
  };

  const isFormDisabled = !isActorReady || true; // Always disabled until backend implements createCustomLinkRelation

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Link Annotations</DialogTitle>
          <DialogDescription>
            Create custom named link relations to other annotations. Each relation creates a unique link token in the global registry.
          </DialogDescription>
        </DialogHeader>

        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <strong>Feature Not Available:</strong> The backend method <code className="bg-muted px-1 py-0.5 rounded">createCustomLinkRelation</code> needs to be implemented to enable link annotation functionality.
          </AlertDescription>
        </Alert>

        {!isActorReady && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {actorError || 'Connecting to the network... Please wait.'}
            </AlertDescription>
          </Alert>
        )}

        {annotationNodes.length === 0 && isActorReady && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              No annotation nodes available. Create annotations first to link them.
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleCreateRelations} className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-semibold">Link Relations</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleAddRelation}
                disabled={isFormDisabled}
                className="gap-1"
              >
                <Plus className="h-3 w-3" />
                Add Relation
              </Button>
            </div>

            <ScrollArea className="max-h-[400px] pr-4">
              <div className="space-y-4">
                {relations.map((relation, index) => (
                  <div key={index} className="p-4 border rounded-lg bg-muted/30 space-y-3">
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-xs">
                        Relation {index + 1}
                      </Badge>
                      {relations.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveRelation(index)}
                          disabled={isFormDisabled}
                          className="h-8 w-8 p-0"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor={`target-${index}`} className="text-xs">
                          Target Annotation
                        </Label>
                        <Select
                          value={relation.targetAnnotationId.toString()}
                          onValueChange={(value) => handleRelationChange(index, 'targetAnnotationId', value)}
                          disabled={isFormDisabled || annotationNodes.length === 0}
                        >
                          <SelectTrigger id={`target-${index}`}>
                            <SelectValue placeholder="Select target annotation" />
                          </SelectTrigger>
                          <SelectContent>
                            <ScrollArea className="h-[200px]">
                              {annotationNodes.map((node) => (
                                <SelectItem 
                                  key={node.id.toString()} 
                                  value={node.id.toString()}
                                  disabled={node.id === sourceAnnotationId}
                                >
                                  <div className="flex items-center gap-2">
                                    <Badge variant="outline" className="text-xs">
                                      annotation
                                    </Badge>
                                    <span className="truncate">{node.title}</span>
                                  </div>
                                </SelectItem>
                              ))}
                            </ScrollArea>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`name-${index}`} className="text-xs">
                          Relation Name
                        </Label>
                        <Input
                          id={`name-${index}`}
                          placeholder="e.g., supports, contradicts, extends"
                          value={relation.relationName}
                          onChange={(e) => handleRelationChange(index, 'relationName', e.target.value)}
                          disabled={isFormDisabled}
                          maxLength={50}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>

          <div className="rounded-lg border bg-muted/50 p-3 text-sm text-muted-foreground">
            <p>
              <strong className="text-foreground">Note:</strong> Each named relation will create a unique link token in the global registry. Link tokens appear as nodes positioned at the midpoint between connected annotations in the graph view.
            </p>
          </div>

          <div className="flex gap-2 justify-end pt-4 border-t">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isFormDisabled || annotationNodes.length === 0}
            >
              Create Relations
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
