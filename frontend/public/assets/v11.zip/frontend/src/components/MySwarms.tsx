import { useState } from 'react';
import { useGetSwarmData, useGetSwarmMetrics, useRequestJoinSwarm, useGetPendingJoinRequests, useApproveJoinRequest, useGetJoinRequestStatus, useGetCallerUserProfile } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { Users, FileText, Coins, Activity, UserPlus, CheckCircle, Clock, XCircle, ExternalLink } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';
import { AlertCircle, Info } from 'lucide-react';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { NodeId, JoinRequest, SwarmSummary } from '../types';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';
import { toast } from 'sonner';
import { Principal } from '@icp-sdk/core/principal';

export default function MySwarms() {
  const { data: swarmData, isLoading, error } = useGetSwarmData();
  const { identity } = useInternetIdentity();
  const [confirmJoinSwarmId, setConfirmJoinSwarmId] = useState<NodeId | null>(null);
  const requestJoinMutation = useRequestJoinSwarm();

  const handleRequestJoin = async (swarmId: NodeId) => {
    try {
      await requestJoinMutation.mutateAsync(swarmId);
      toast.success('Join request submitted! Waiting for member approval.');
      setConfirmJoinSwarmId(null);
    } catch (error: any) {
      console.error('Failed to request join:', error);
      if (error.message?.includes('Maximum swarm membership limit reached')) {
        toast.error('You have reached the maximum limit of 4 swarm memberships');
      } else if (error.message?.includes('Already a member')) {
        toast.error('You are already a member of this swarm');
      } else {
        toast.error('Failed to submit join request. Please try again.');
      }
    }
  };

  if (isLoading) {
    return (
      <div className="h-full overflow-auto bg-background">
        <div className="container mx-auto p-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading swarms...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-full overflow-auto bg-background">
        <div className="container mx-auto p-6">
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Failed to load swarms. Please try again later.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  const joinedSwarms = swarmData?.joined || [];
  const availableSwarms = swarmData?.available || [];

  return (
    <div className="h-full overflow-auto bg-background">
      <div className="container mx-auto p-6 space-y-8">
        {/* Joined Swarms Section */}
        <section>
          <div className="mb-4">
            <h3 className="text-2xl font-bold tracking-tight flex items-center gap-2">
              <Users className="h-6 w-6" />
              My Swarms
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              Swarms you've joined or created
            </p>
          </div>

          {joinedSwarms.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Users className="h-16 w-16 text-muted-foreground mb-4" />
                <h4 className="text-lg font-semibold mb-2">No Swarms Joined</h4>
                <p className="text-muted-foreground text-center max-w-md">
                  Request to join swarms from the "All Swarms" section below. Once approved by the majority of members, you'll gain access.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {joinedSwarms.map((swarm) => (
                <SwarmCard
                  key={swarm.id.toString()}
                  swarmId={swarm.id}
                  swarmSummary={swarm}
                  identity={identity}
                  showJoinRequests={true}
                />
              ))}
            </div>
          )}
        </section>

        {/* All Swarms Section */}
        <section>
          <div className="mb-4">
            <h3 className="text-2xl font-bold tracking-tight flex items-center gap-2">
              <Activity className="h-6 w-6" />
              All Swarms
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              Browse and request to join available swarms
            </p>
          </div>

          {availableSwarms.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Activity className="h-16 w-16 text-muted-foreground mb-4" />
                <h4 className="text-lg font-semibold mb-2">No Available Swarms</h4>
                <p className="text-muted-foreground text-center max-w-md">
                  All swarms are currently joined. Create a new swarm to expand your network.
                </p>
              </CardContent>
            </Card>
          ) : (
            <>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {availableSwarms.map((swarm) => (
                  <Card key={swarm.id.toString()} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-xl mb-2">{swarm.title}</CardTitle>
                          <CardDescription className="text-xs font-mono">
                            ID: {swarm.id.toString()}
                          </CardDescription>
                        </div>
                        <Badge variant="secondary" className="ml-2">
                          Available
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Users className="h-4 w-4" />
                            <span>Members</span>
                          </div>
                          <span className="font-semibold">{swarm.memberCount.toString()}</span>
                        </div>

                        {identity && (
                          <JoinRequestButton swarmId={swarm.id} onRequestJoin={() => setConfirmJoinSwarmId(swarm.id)} />
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="mt-6 p-4 bg-muted/50 rounded-lg">
                <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                  <Info className="h-4 w-4" />
                  About Swarm Membership & Approval
                </h4>
                <p className="text-sm text-muted-foreground">
                  To join a swarm, submit a join request. Once <strong>more than 50%</strong> of current members approve your request, 
                  you'll automatically become a member. You can join up to <strong>4 swarms</strong> total, 
                  but you can create unlimited personal swarms.
                </p>
              </div>
            </>
          )}
        </section>
      </div>

      <AlertDialog open={confirmJoinSwarmId !== null} onOpenChange={(open) => !open && setConfirmJoinSwarmId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Request to join this swarm?</AlertDialogTitle>
            <AlertDialogDescription>
              Your join request will be sent to all current swarm members. Once more than 50% of members approve, 
              you'll automatically become a member and gain access to the swarm's annotations and tokens.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => confirmJoinSwarmId && handleRequestJoin(confirmJoinSwarmId)}
              disabled={requestJoinMutation.isPending}
            >
              {requestJoinMutation.isPending ? 'Submitting...' : 'Submit Request'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

interface JoinRequestButtonProps {
  swarmId: NodeId;
  onRequestJoin: () => void;
}

function JoinRequestButton({ swarmId, onRequestJoin }: JoinRequestButtonProps) {
  const { identity } = useInternetIdentity();
  const { data: requestStatus } = useGetJoinRequestStatus(
    swarmId,
    identity ? identity.getPrincipal() : null
  );

  if (requestStatus) {
    return (
      <div className="pt-3 border-t space-y-2">
        <Badge variant="outline" className="w-full justify-center gap-2">
          <Clock className="h-3 w-3" />
          Request Pending
        </Badge>
        <div className="text-xs text-center text-muted-foreground">
          {requestStatus.approvers.length} / {requestStatus.approvalsNeeded.toString()} approvals ({requestStatus.percentageApproved.toString()}%)
        </div>
      </div>
    );
  }

  return (
    <div className="pt-3 border-t">
      <Button
        variant="outline"
        size="sm"
        className="w-full gap-2"
        onClick={onRequestJoin}
      >
        <UserPlus className="h-4 w-4" />
        Request to Join
      </Button>
    </div>
  );
}

interface SwarmCardProps {
  swarmId: NodeId;
  swarmSummary: SwarmSummary;
  identity: any;
  showJoinRequests?: boolean;
}

function SwarmCard({ swarmId, swarmSummary, identity, showJoinRequests = false }: SwarmCardProps) {
  const { data: metrics, isLoading } = useGetSwarmMetrics(swarmId);
  const { data: pendingRequests } = useGetPendingJoinRequests(showJoinRequests ? swarmId : null);
  const approveMutation = useApproveJoinRequest();
  const [disapprovingRequest, setDisapprovingRequest] = useState<Principal | null>(null);

  const handleApprove = async (requester: Principal) => {
    try {
      await approveMutation.mutateAsync({ swarmId, requester });
      toast.success('Join request approved!');
    } catch (error: any) {
      console.error('Failed to approve request:', error);
      toast.error(error.message || 'Failed to approve request');
    }
  };

  const handleDisapprove = async (requester: Principal) => {
    toast.info('Disapprove functionality will be available once backend implements it');
    setDisapprovingRequest(null);
  };

  if (isLoading || !metrics) {
    return (
      <Card className="animate-pulse">
        <CardHeader>
          <div className="h-6 bg-muted rounded w-3/4 mb-2"></div>
          <div className="h-4 bg-muted rounded w-1/2"></div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-4 bg-muted rounded"></div>
            <div className="h-4 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-xl mb-2">{swarmSummary.title}</CardTitle>
            <CardDescription className="text-xs font-mono">
              ID: {swarmSummary.id.toString()}
            </CardDescription>
          </div>
          <Badge 
            variant={metrics.activityStatus === 'active' ? 'default' : 'secondary'}
            className="ml-2"
          >
            {metrics.activityStatus}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col space-y-4">
        {/* Swarm Stats */}
        <div className="grid grid-cols-3 gap-2 text-sm">
          <div className="flex flex-col items-center p-2 bg-muted/50 rounded">
            <Users className="h-4 w-4 mb-1 text-muted-foreground" />
            <span className="font-semibold">{swarmSummary.memberCount.toString()}</span>
            <span className="text-xs text-muted-foreground">Members</span>
          </div>
          <div className="flex flex-col items-center p-2 bg-muted/50 rounded">
            <FileText className="h-4 w-4 mb-1 text-muted-foreground" />
            <span className="font-semibold">{metrics.annotationCount.toString()}</span>
            <span className="text-xs text-muted-foreground">Annotations</span>
          </div>
          <div className="flex flex-col items-center p-2 bg-muted/50 rounded">
            <Coins className="h-4 w-4 mb-1 text-muted-foreground" />
            <span className="font-semibold text-primary">{metrics.totalBuzzEarned.toString()}</span>
            <span className="text-xs text-muted-foreground">BUZZ</span>
          </div>
        </div>

        {/* Join Requests Section */}
        {showJoinRequests && pendingRequests && pendingRequests.length > 0 && (
          <div className="border rounded-lg p-3 space-y-2">
            <h4 className="text-sm font-semibold flex items-center gap-2">
              <UserPlus className="h-4 w-4" />
              Pending Join Requests ({pendingRequests.length})
            </h4>
            <ScrollArea className="max-h-64">
              <div className="space-y-2">
                {pendingRequests.map((request, idx) => (
                  <JoinRequestItem
                    key={idx}
                    request={request}
                    onApprove={handleApprove}
                    onDisapprove={handleDisapprove}
                    isApproving={approveMutation.isPending}
                    isDisapproving={disapprovingRequest?.toString() === request.requester.toString()}
                  />
                ))}
              </div>
            </ScrollArea>
          </div>
        )}
      </CardContent>

      <AlertDialog open={disapprovingRequest !== null} onOpenChange={(open) => !open && setDisapprovingRequest(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Disapprove Join Request</AlertDialogTitle>
            <AlertDialogDescription>
              This feature will be available once the backend implements the disapprove functionality.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Close</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}

interface JoinRequestItemProps {
  request: JoinRequest;
  onApprove: (requester: Principal) => void;
  onDisapprove: (requester: Principal) => void;
  isApproving: boolean;
  isDisapproving: boolean;
}

function JoinRequestItem({ request, onApprove, onDisapprove, isApproving, isDisapproving }: JoinRequestItemProps) {
  const { data: requesterProfile } = useGetCallerUserProfile();
  
  const requesterName = requesterProfile?.name || request.requester.toString().slice(0, 12) + '...';
  const requesterSocialUrl = requesterProfile?.socialUrl;

  return (
    <div className="flex flex-col gap-2 bg-muted/50 p-3 rounded">
      <div className="flex items-center justify-between">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-sm truncate">{requesterName}</span>
            {requesterSocialUrl && (
              <a
                href={requesterSocialUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:text-primary/80 transition-colors"
                onClick={(e) => e.stopPropagation()}
              >
                <ExternalLink className="h-3 w-3" />
              </a>
            )}
          </div>
          <p className="text-xs text-muted-foreground font-mono truncate">
            {request.requester.toString()}
          </p>
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        <Button
          size="sm"
          variant="default"
          className="flex-1 h-7 gap-1"
          onClick={() => onApprove(request.requester)}
          disabled={isApproving || isDisapproving}
        >
          <CheckCircle className="h-3 w-3" />
          Approve
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="flex-1 h-7 gap-1"
          onClick={() => onDisapprove(request.requester)}
          disabled={isApproving || isDisapproving}
        >
          <XCircle className="h-3 w-3" />
          Disapprove
        </Button>
      </div>

      {request.approvers.length > 0 && (
        <div className="text-xs text-muted-foreground pt-1 border-t">
          <span className="font-medium">{request.approvers.length}</span> member{request.approvers.length !== 1 ? 's' : ''} approved
        </div>
      )}
    </div>
  );
}
