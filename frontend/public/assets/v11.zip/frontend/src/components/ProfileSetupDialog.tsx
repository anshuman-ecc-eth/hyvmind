import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { User, AlertCircle, Link as LinkIcon } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

interface ProfileSetupDialogProps {
  onSave: (name: string, socialUrl: string) => void;
  isSaving: boolean;
  error?: string | null;
}

export default function ProfileSetupDialog({ onSave, isSaving, error }: ProfileSetupDialogProps) {
  const [name, setName] = useState('');
  const [socialUrl, setSocialUrl] = useState('');
  const [validationError, setValidationError] = useState<string | null>(null);

  const validateSocialUrl = (url: string): boolean => {
    const trimmed = url.trim();
    if (!trimmed) {
      setValidationError('Social URL is required');
      return false;
    }
    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
      setValidationError('Social URL must start with http:// or https://');
      return false;
    }
    setValidationError(null);
    return true;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      setValidationError('Name is required');
      return;
    }
    
    if (!validateSocialUrl(socialUrl)) {
      return;
    }
    
    onSave(name.trim(), socialUrl.trim());
  };

  const handleSocialUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSocialUrl(e.target.value);
    if (validationError) {
      setValidationError(null);
    }
  };

  const isFormValid = name.trim() && socialUrl.trim();

  return (
    <Dialog open={true}>
      <DialogContent className="sm:max-w-md" showCloseButton={false}>
        <DialogHeader>
          <div className="mb-4 flex justify-center">
            <div className="rounded-full bg-primary/10 p-4">
              <User className="h-8 w-8 text-primary" />
            </div>
          </div>
          <DialogTitle className="text-center text-2xl">Welcome to Hyvmind</DialogTitle>
          <DialogDescription className="text-center">
            Let's get started by setting up your profile.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {(error || validationError) && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error || validationError}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="name">Your Name *</Label>
            <Input
              id="name"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={isSaving}
              autoFocus
              maxLength={100}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="socialUrl" className="flex items-center gap-2">
              <LinkIcon className="h-4 w-4" />
              Social URL *
            </Label>
            <Input
              id="socialUrl"
              type="url"
              placeholder="https://example.com/yourprofile"
              value={socialUrl}
              onChange={handleSocialUrlChange}
              disabled={isSaving}
            />
            <p className="text-xs text-muted-foreground">
              Required: Add a link to your website, social profile, or portfolio
            </p>
          </div>

          <Button type="submit" className="w-full" disabled={!isFormValid || isSaving}>
            {isSaving ? (
              <>
                <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                Saving...
              </>
            ) : (
              'Continue'
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
