import { useEffect, useRef, useState } from 'react';
import { useGetGraphData } from '../hooks/useQueries';
import { NodeType, RelationType, TokenType, Node, Relation } from '../types';
import { Alert, AlertDescription } from './ui/alert';
import { AlertCircle, ZoomIn, ZoomOut, Maximize2, ChevronDown, ChevronUp, Filter, Download, Upload } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Slider } from './ui/slider';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { Checkbox } from './ui/checkbox';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { useTheme } from 'next-themes';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';

interface GraphNode extends Node {
  x: number;
  y: number;
  vx: number;
  vy: number;
  fx?: number;
  fy?: number;
}

interface LinkTokenNode {
  id: bigint;
  nodeType: NodeType.token;
  title: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  fx?: number;
  fy?: number;
  sourceAnnotationId: bigint;
  targetAnnotationId: bigint;
  linkRelationId: bigint;
}

type GraphElement = GraphNode | LinkTokenNode;

interface ForceConfig {
  chargeStrength: number;
  linkDistance: number;
  collisionRadius: number;
  lineWidth: number;
  nodeSize: number;
}

interface NodeColors {
  [NodeType.curation]: string;
  [NodeType.swarm]: string;
  [NodeType.annotation]: string;
  [NodeType.token]: string;
  positiveLaw: string;
  interpretation: string;
  link: string;
}

interface FilterState {
  nodeTypes: Set<NodeType>;
  relationTypes: Set<RelationType>;
  showHierarchical: boolean;
}

const DEFAULT_COLORS: NodeColors = {
  [NodeType.curation]: '#d4a017',    // Gold
  [NodeType.swarm]: '#14b8a6',       // Teal
  [NodeType.annotation]: '#9b59b6',  // Purple
  [NodeType.token]: '#f97316',       // Orange (default for tokens)
  positiveLaw: '#3b82f6',            // Blue for positive law tokens
  interpretation: '#ec4899',         // Pink for interpretation tokens
  link: '#27F5D3',                   // Cyan (#27F5D3) for link tokens
};

// Relation colors
const HIERARCHICAL_COLOR = '#d4a017'; // Gold for hierarchical includes relations (solid lines)
const REASONING_COLOR = '#10b981';    // Green for reasoning relations (dashed lines)

// Debounce delay for initial render stabilization (ms)
const INITIAL_RENDER_DELAY = 150;

// Velocity threshold for considering the simulation "stable"
const VELOCITY_THRESHOLD = 0.002;

// Adjusted force simulation parameters for stability
const ALPHA_DECAY = 0.01;           // Low alpha decay for gradual settling
const VELOCITY_DECAY = 0.8;         // High velocity decay for stability
const LINK_STRENGTH = 0.3;          // Suitable link strength

function isGraphNode(element: GraphElement): element is GraphNode {
  return 'nodeType' in element && !('sourceAnnotationId' in element);
}

function isLinkTokenNode(element: GraphElement): element is LinkTokenNode {
  return 'sourceAnnotationId' in element && 'targetAnnotationId' in element;
}

export default function GraphView() {
  const { data: graphData, isLoading, error } = useGetGraphData();
  const { theme, systemTheme } = useTheme();
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [elements, setElements] = useState<GraphElement[]>([]);
  const [selectedElement, setSelectedElement] = useState<GraphElement | null>(null);
  const [focusedElement, setFocusedElement] = useState<GraphElement | null>(null);
  const [forceControlsOpen, setForceControlsOpen] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1 });
  const animationRef = useRef<number | undefined>(undefined);
  const isDraggingElementRef = useRef<GraphElement | null>(null);
  const isPanningRef = useRef(false);
  const panStartRef = useRef({ x: 0, y: 0 });
  const [isInitialized, setIsInitialized] = useState(false);
  const [isRenderReady, setIsRenderReady] = useState(false);
  const [isSimulationStable, setIsSimulationStable] = useState(false);
  const renderTimeoutRef = useRef<NodeJS.Timeout | undefined>(undefined);

  // Determine if dark mode is active
  const isDarkMode = theme === 'dark' || (theme === 'system' && systemTheme === 'dark');

  // Default values set to 50% of slider range
  const [forceConfig, setForceConfig] = useState<ForceConfig>(() => {
    const saved = localStorage.getItem('graphForceConfig');
    return saved ? JSON.parse(saved) : {
      chargeStrength: -525,
      linkDistance: 175,
      collisionRadius: 55,
      lineWidth: 2,
      nodeSize: 8,
    };
  });

  const [filters, setFilters] = useState<FilterState>(() => {
    const saved = localStorage.getItem('graphFilters');
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        nodeTypes: new Set(parsed.nodeTypes as NodeType[]),
        relationTypes: new Set(parsed.relationTypes as RelationType[]),
        showHierarchical: parsed.showHierarchical !== undefined ? parsed.showHierarchical : true,
      };
    }
    return {
      nodeTypes: new Set<NodeType>([NodeType.curation, NodeType.swarm, NodeType.annotation, NodeType.token]),
      relationTypes: new Set<RelationType>([RelationType.retrieval, RelationType.reasoning]),
      showHierarchical: true,
    };
  });

  const [nodeColors] = useState<NodeColors>(() => {
    const saved = localStorage.getItem('graphNodeColors');
    return saved ? JSON.parse(saved) : DEFAULT_COLORS;
  });

  useEffect(() => {
    localStorage.setItem('graphForceConfig', JSON.stringify(forceConfig));
  }, [forceConfig]);

  useEffect(() => {
    localStorage.setItem('graphFilters', JSON.stringify({
      nodeTypes: Array.from(filters.nodeTypes),
      relationTypes: Array.from(filters.relationTypes),
      showHierarchical: filters.showHierarchical,
    }));
  }, [filters]);

  const toggleNodeTypeFilter = (nodeType: NodeType) => {
    setFilters(prev => {
      const newTypes = new Set(prev.nodeTypes);
      if (newTypes.has(nodeType)) {
        newTypes.delete(nodeType);
      } else {
        newTypes.add(nodeType);
      }
      return { ...prev, nodeTypes: newTypes };
    });
  };

  const toggleRelationTypeFilter = (relationType: RelationType) => {
    setFilters(prev => {
      const newTypes = new Set(prev.relationTypes);
      if (newTypes.has(relationType)) {
        newTypes.delete(relationType);
      } else {
        newTypes.add(relationType);
      }
      return { ...prev, relationTypes: newTypes };
    });
  };

  const toggleHierarchicalFilter = () => {
    setFilters(prev => ({ ...prev, showHierarchical: !prev.showHierarchical }));
  };

  // Helper function to get element title with fallback
  const getElementTitle = (element: GraphElement): string => {
    if (element.title && element.title.trim() !== '') {
      return element.title;
    }
    return `[${element.nodeType}]`;
  };

  // Helper to determine relation type from backend data
  const getRelationType = (relation: Relation): RelationType => {
    return relation.relationType;
  };

  // Helper to get token type from graph data
  const getTokenType = (element: GraphElement): TokenType | null => {
    if (element.nodeType !== NodeType.token) return null;
    
    // For link token nodes, always return link type
    if (isLinkTokenNode(element)) {
      return TokenType.link;
    }
    
    const tokenName = element.title.toLowerCase().trim();
    const token = graphData?.tokens.find(t => t.name === tokenName);
    return token?.tokenType || null;
  };

  // Deduplicate annotations: keep only highest-ranked annotation per name within each swarm
  const deduplicateAnnotations = (nodes: Node[]): { dedupedNodes: Node[]; duplicateMap: Map<bigint, bigint> } => {
    const dedupedNodes: Node[] = [];
    const duplicateMap = new Map<bigint, bigint>();
    
    const annotationsBySwarmAndName = new Map<string, Node[]>();
    
    nodes.forEach(node => {
      if (node.nodeType === NodeType.annotation && node.swarmId !== undefined) {
        const key = `${node.swarmId.toString()}_${node.title}`;
        if (!annotationsBySwarmAndName.has(key)) {
          annotationsBySwarmAndName.set(key, []);
        }
        annotationsBySwarmAndName.get(key)!.push(node);
      }
    });
    
    const visibleAnnotationIds = new Set<bigint>();
    
    annotationsBySwarmAndName.forEach((group) => {
      if (group.length > 1) {
        const sorted = group.sort((a, b) => {
          const ratioA = Number(a.downvotes) > 0 
            ? Number(a.upvotes) / Number(a.downvotes) 
            : Number(a.upvotes);
          const ratioB = Number(b.downvotes) > 0 
            ? Number(b.upvotes) / Number(b.downvotes) 
            : Number(b.upvotes);
          return ratioB - ratioA;
        });
        
        const representative = sorted[0];
        visibleAnnotationIds.add(representative.id);
        
        for (let i = 1; i < sorted.length; i++) {
          duplicateMap.set(sorted[i].id, representative.id);
        }
      } else if (group.length === 1) {
        visibleAnnotationIds.add(group[0].id);
      }
    });
    
    nodes.forEach(node => {
      if (node.nodeType === NodeType.annotation) {
        if (visibleAnnotationIds.has(node.id)) {
          dedupedNodes.push(node);
        }
      } else {
        dedupedNodes.push(node);
      }
    });
    
    return { dedupedNodes, duplicateMap };
  };

  // Redirect relations from filtered-out duplicates to their visible representatives
  const redirectRelations = (relations: Relation[], duplicateMap: Map<bigint, bigint>): Relation[] => {
    return relations.map(relation => {
      let sourceId = relation.sourceNodeId;
      let targetId = relation.targetNodeId;
      
      if (duplicateMap.has(sourceId)) {
        sourceId = duplicateMap.get(sourceId)!;
      }
      
      if (duplicateMap.has(targetId)) {
        targetId = duplicateMap.get(targetId)!;
      }
      
      if (sourceId !== relation.sourceNodeId || targetId !== relation.targetNodeId) {
        return {
          ...relation,
          sourceNodeId: sourceId,
          targetNodeId: targetId,
        };
      }
      
      return relation;
    });
  };

  // Export functions
  const exportToJSONLD = () => {
    if (!graphData) {
      toast.error('No graph data to export');
      return;
    }

    const jsonLD = {
      '@context': {
        '@vocab': 'http://schema.org/',
        'hyvmind': 'http://hyvmind.io/ontology/',
      },
      '@graph': [
        ...graphData.nodes.map(node => ({
          '@id': `hyvmind:node/${node.id}`,
          '@type': `hyvmind:${node.nodeType}`,
          'name': node.title,
          'bracketedTokenSequence': node.bracketedTokenSequence,
          'owner': node.owner.toString(),
          'createdAt': new Date(Number(node.createdAt) / 1000000).toISOString(),
          'immutable': node.immutable,
          ...(node.parentId !== undefined && { 'parentId': `hyvmind:node/${node.parentId}` }),
          ...(node.swarmId !== undefined && { 'swarmId': `hyvmind:node/${node.swarmId}` }),
        })),
        ...graphData.tokens.map(token => ({
          '@id': `hyvmind:token/${token.id}`,
          '@type': 'hyvmind:Token',
          'name': token.name,
          'tokenType': token.tokenType,
          'buzzValue': token.buzzValue.toString(),
          'reuseCount': token.reuseCount.toString(),
          'creator': token.creator.toString(),
          'createdAt': new Date(Number(token.createdAt) / 1000000).toISOString(),
          'relatedAnnotations': token.relatedAnnotations.map(id => `hyvmind:node/${id}`),
        })),
        ...graphData.relations.map(([id, relation]) => ({
          '@id': `hyvmind:relation/${id}`,
          '@type': 'hyvmind:Relation',
          'sourceNode': `hyvmind:node/${relation.sourceNodeId}`,
          'targetNode': `hyvmind:node/${relation.targetNodeId}`,
          'relationType': relation.relationType,
          'owner': relation.owner.toString(),
          'createdAt': new Date(Number(relation.createdAt) / 1000000).toISOString(),
        })),
        ...graphData.links.map(link => ({
          '@id': `hyvmind:link/${link.id}`,
          '@type': 'hyvmind:LinkRelation',
          'sourceAnnotation': `hyvmind:node/${link.sourceAnnotationId}`,
          'targetAnnotation': `hyvmind:node/${link.targetAnnotationId}`,
          'relationName': link.relationName,
          'linkToken': `hyvmind:token/${link.linkTokenId}`,
          'creator': link.creator.toString(),
          'createdAt': new Date(Number(link.createdAt) / 1000000).toISOString(),
        })),
      ],
    };

    const dataStr = JSON.stringify(jsonLD, null, 2);
    const blob = new Blob([dataStr], { type: 'application/ld+json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `graph-data-${new Date().toISOString().split('T')[0]}.jsonld`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    toast.success('Graph data exported as JSON-LD');
  };

  const exportToCSV = () => {
    if (!graphData) {
      toast.error('No graph data to export');
      return;
    }

    const nodeHeaders = ['id', 'nodeType', 'title', 'bracketedTokenSequence', 'parentId', 'swarmId', 'owner', 'createdAt', 'immutable'];
    const nodeRows = graphData.nodes.map(node => [
      node.id.toString(),
      node.nodeType,
      `"${node.title.replace(/"/g, '""')}"`,
      `"${node.bracketedTokenSequence.replace(/"/g, '""')}"`,
      node.parentId !== undefined ? node.parentId.toString() : '',
      node.swarmId !== undefined ? node.swarmId.toString() : '',
      node.owner.toString(),
      new Date(Number(node.createdAt) / 1000000).toISOString(),
      node.immutable.toString(),
    ]);
    const nodesCsv = [nodeHeaders.join(','), ...nodeRows.map(row => row.join(','))].join('\n');

    const tokenHeaders = ['id', 'name', 'tokenType', 'buzzValue', 'reuseCount', 'creator', 'createdAt', 'relatedAnnotations'];
    const tokenRows = graphData.tokens.map(token => [
      token.id.toString(),
      `"${token.name.replace(/"/g, '""')}"`,
      token.tokenType,
      token.buzzValue.toString(),
      token.reuseCount.toString(),
      token.creator.toString(),
      new Date(Number(token.createdAt) / 1000000).toISOString(),
      `"${token.relatedAnnotations.map(id => id.toString()).join(';')}"`,
    ]);
    const tokensCsv = [tokenHeaders.join(','), ...tokenRows.map(row => row.join(','))].join('\n');

    const relationHeaders = ['id', 'sourceNodeId', 'targetNodeId', 'relationType', 'owner', 'createdAt'];
    const relationRows = graphData.relations.map(([id, relation]) => [
      id.toString(),
      relation.sourceNodeId.toString(),
      relation.targetNodeId.toString(),
      relation.relationType,
      relation.owner.toString(),
      new Date(Number(relation.createdAt) / 1000000).toISOString(),
    ]);
    const relationsCsv = [relationHeaders.join(','), ...relationRows.map(row => row.join(','))].join('\n');

    const linkHeaders = ['id', 'sourceAnnotationId', 'targetAnnotationId', 'relationName', 'linkTokenId', 'creator', 'createdAt'];
    const linkRows = graphData.links.map(link => [
      link.id.toString(),
      link.sourceAnnotationId.toString(),
      link.targetAnnotationId.toString(),
      `"${link.relationName.replace(/"/g, '""')}"`,
      link.linkTokenId.toString(),
      link.creator.toString(),
      new Date(Number(link.createdAt) / 1000000).toISOString(),
    ]);
    const linksCsv = [linkHeaders.join(','), ...linkRows.map(row => row.join(','))].join('\n');

    const combinedCsv = `# Nodes\n${nodesCsv}\n\n# Tokens\n${tokensCsv}\n\n# Relations\n${relationsCsv}\n\n# Link Relations\n${linksCsv}`;

    const blob = new Blob([combinedCsv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `graph-data-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    toast.success('Graph data exported as CSV');
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        
        if (file.name.endsWith('.jsonld')) {
          const importedData = JSON.parse(content);
          
          if (importedData['@graph']) {
            toast.info('JSON-LD import detected. Note: Data will be merged with existing graph visually only (backend import not implemented).');
          } else {
            toast.error('Invalid JSON-LD format. Expected @graph property.');
          }
        } else if (file.name.endsWith('.csv')) {
          toast.info('CSV import detected. Note: Data will be merged with existing graph visually only (backend import not implemented).');
        } else {
          toast.error('Unsupported file format. Please use JSON-LD or CSV.');
        }
      } catch (error) {
        toast.error('Failed to parse file: ' + (error as Error).message);
      }
    };

    reader.readAsText(file);
    event.target.value = '';
  };

  // Initialize graph elements with stable pre-simulation
  useEffect(() => {
    if (!graphData?.nodes || graphData.nodes.length === 0) {
      setElements([]);
      setIsInitialized(false);
      setIsRenderReady(false);
      setIsSimulationStable(false);
      if (renderTimeoutRef.current) {
        clearTimeout(renderTimeoutRef.current);
      }
      return;
    }

    const container = containerRef.current;
    if (!container) return;

    const centerX = container.clientWidth / 2;
    const centerY = container.clientHeight / 2;

    const { dedupedNodes, duplicateMap } = deduplicateAnnotations(graphData.nodes);
    const relations = graphData.relations.map(([_, relation]) => relation);
    const redirectedRelations = redirectRelations(relations, duplicateMap);

    // Create all elements: regular nodes + link token nodes positioned at midpoints
    const allElements: GraphElement[] = [];
    
    // Add regular nodes
    dedupedNodes.forEach((node, i) => {
      const angle = (i / dedupedNodes.length) * 2 * Math.PI;
      const radius = 150;
      allElements.push({
        ...node,
        x: centerX + Math.cos(angle) * radius,
        y: centerY + Math.sin(angle) * radius,
        vx: 0,
        vy: 0,
      } as GraphNode);
    });

    // Add link token nodes at midpoints between source and target annotations
    if (graphData.links) {
      graphData.links.forEach(link => {
        const sourceNode = allElements.find(e => e.id === link.sourceAnnotationId);
        const targetNode = allElements.find(e => e.id === link.targetAnnotationId);
        
        if (sourceNode && targetNode) {
          // Position link token at midpoint
          const midX = (sourceNode.x + targetNode.x) / 2;
          const midY = (sourceNode.y + targetNode.y) / 2;
          
          // Find the token name from the global token registry
          const linkToken = graphData.tokens.find(t => t.id === link.linkTokenId);
          const tokenName = linkToken?.name || link.relationName;
          
          const linkTokenNode: LinkTokenNode = {
            id: link.linkTokenId,
            nodeType: NodeType.token,
            title: tokenName,
            x: midX,
            y: midY,
            vx: 0,
            vy: 0,
            sourceAnnotationId: link.sourceAnnotationId,
            targetAnnotationId: link.targetAnnotationId,
            linkRelationId: link.id,
          };
          
          allElements.push(linkTokenNode);
        }
      });
    }

    // Pre-run simulation for stable initialization
    let simulationElements = allElements.map(e => ({ ...e }));
    
    for (let i = 0; i < 100; i++) {
      simulationElements = applyForcesStatic(simulationElements, redirectedRelations, centerX, centerY, forceConfig);
    }

    setElements(simulationElements);
    setIsInitialized(true);
    setIsSimulationStable(false);
    
    setIsRenderReady(false);
    if (renderTimeoutRef.current) {
      clearTimeout(renderTimeoutRef.current);
    }
    renderTimeoutRef.current = setTimeout(() => {
      setIsRenderReady(true);
    }, INITIAL_RENDER_DELAY);

    return () => {
      if (renderTimeoutRef.current) {
        clearTimeout(renderTimeoutRef.current);
      }
    };
  }, [graphData]);

  // Static force application for pre-simulation
  const applyForcesStatic = (
    currentElements: GraphElement[],
    relations: Relation[],
    centerX: number,
    centerY: number,
    config: ForceConfig
  ): GraphElement[] => {
    const newElements = currentElements.map((element) => ({ ...element }));

    // Center force - exclude link token nodes
    newElements.forEach((element) => {
      if (!isLinkTokenNode(element)) {
        const dx = centerX - element.x;
        const dy = centerY - element.y;
        element.vx += dx * 0.01;
        element.vy += dy * 0.01;
      }
    });

    // Charge force (repulsion) - exclude link token nodes
    for (let i = 0; i < newElements.length; i++) {
      if (isLinkTokenNode(newElements[i])) continue;
      
      for (let j = i + 1; j < newElements.length; j++) {
        if (isLinkTokenNode(newElements[j])) continue;
        
        const dx = newElements[j].x - newElements[i].x;
        const dy = newElements[j].y - newElements[i].y;
        const distance = Math.sqrt(dx * dx + dy * dy) || 1;
        const force = config.chargeStrength / (distance * distance);

        newElements[i].vx -= (dx / distance) * force;
        newElements[i].vy -= (dy / distance) * force;
        newElements[j].vx += (dx / distance) * force;
        newElements[j].vy += (dy / distance) * force;
      }
    }

    // Link force for regular relations with adjusted strength - exclude link token nodes
    relations.forEach((relation) => {
      const source = newElements.find((e) => e.id === relation.sourceNodeId);
      const target = newElements.find((e) => e.id === relation.targetNodeId);

      if (source && target && !isLinkTokenNode(source) && !isLinkTokenNode(target)) {
        const dx = target.x - source.x;
        const dy = target.y - source.y;
        const distance = Math.sqrt(dx * dx + dy * dy) || 1;
        const targetDistance = config.linkDistance;
        const force = (distance - targetDistance) * LINK_STRENGTH;

        source.vx += (dx / distance) * force;
        source.vy += (dy / distance) * force;
        target.vx -= (dx / distance) * force;
        target.vy -= (dy / distance) * force;
      }
    });

    // Link token nodes: anchor at midpoint (zero force influence)
    newElements.forEach((element) => {
      if (isLinkTokenNode(element)) {
        const source = newElements.find(e => e.id === element.sourceAnnotationId);
        const target = newElements.find(e => e.id === element.targetAnnotationId);
        
        if (source && target) {
          // Set position to exact midpoint, zero velocity
          element.x = (source.x + target.x) / 2;
          element.y = (source.y + target.y) / 2;
          element.vx = 0;
          element.vy = 0;
        }
      }
    });

    // Collision force - exclude link token nodes
    for (let i = 0; i < newElements.length; i++) {
      if (isLinkTokenNode(newElements[i])) continue;
      
      for (let j = i + 1; j < newElements.length; j++) {
        if (isLinkTokenNode(newElements[j])) continue;
        
        const dx = newElements[j].x - newElements[i].x;
        const dy = newElements[j].y - newElements[i].y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const minDistance = config.collisionRadius * 2;

        if (distance < minDistance && distance > 0) {
          const force = (minDistance - distance) / distance * 0.5;
          newElements[i].vx -= dx * force;
          newElements[i].vy -= dy * force;
          newElements[j].vx += dx * force;
          newElements[j].vy += dy * force;
        }
      }
    }

    // Apply velocity with increased damping (velocity decay) - exclude link token nodes
    newElements.forEach((element) => {
      if (!isLinkTokenNode(element)) {
        element.x += element.vx;
        element.y += element.vy;
        element.vx *= VELOCITY_DECAY;
        element.vy *= VELOCITY_DECAY;
      }
    });

    return newElements;
  };

  // Animation loop for force simulation with stability detection
  useEffect(() => {
    if (elements.length === 0 || !isInitialized || !graphData) return;

    const { duplicateMap } = deduplicateAnnotations(graphData.nodes);
    const relations = graphData.relations.map(([_, relation]) => relation);
    const redirectedRelations = redirectRelations(relations, duplicateMap);

    const animate = () => {
      applyForces(redirectedRelations);
      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [elements.length, graphData, forceConfig, isInitialized]);

  const applyForces = (relations: Relation[]) => {
    if (!containerRef.current || !graphData) return;

    const container = containerRef.current;
    const centerX = container.clientWidth / 2;
    const centerY = container.clientHeight / 2;

    setElements((prevElements) => {
      const newElements = prevElements.map((element) => ({ ...element }));

      // If simulation is stable, only update fixed positions and link token positions
      if (isSimulationStable) {
        newElements.forEach((element) => {
          if (element.fx !== undefined) {
            element.x = element.fx;
            element.y = element.fy!;
          } else if (isLinkTokenNode(element)) {
            // Keep link tokens at midpoint even when stable
            const source = newElements.find(e => e.id === element.sourceAnnotationId);
            const target = newElements.find(e => e.id === element.targetAnnotationId);
            if (source && target) {
              element.x = (source.x + target.x) / 2;
              element.y = (source.y + target.y) / 2;
              element.vx = 0;
              element.vy = 0;
            }
          }
        });
        return newElements;
      }

      // Center force - exclude link token nodes
      newElements.forEach((element) => {
        if (element.fx === undefined && !isLinkTokenNode(element)) {
          const dx = centerX - element.x;
          const dy = centerY - element.y;
          element.vx += dx * 0.01;
          element.vy += dy * 0.01;
        }
      });

      // Charge force (repulsion between elements) - exclude link token nodes
      for (let i = 0; i < newElements.length; i++) {
        if (isLinkTokenNode(newElements[i])) continue;
        
        for (let j = i + 1; j < newElements.length; j++) {
          if (isLinkTokenNode(newElements[j])) continue;
          
          const dx = newElements[j].x - newElements[i].x;
          const dy = newElements[j].y - newElements[i].y;
          const distance = Math.sqrt(dx * dx + dy * dy) || 1;
          const force = forceConfig.chargeStrength / (distance * distance);

          if (newElements[i].fx === undefined) {
            newElements[i].vx -= (dx / distance) * force;
            newElements[i].vy -= (dy / distance) * force;
          }
          if (newElements[j].fx === undefined) {
            newElements[j].vx += (dx / distance) * force;
            newElements[j].vy += (dx / distance) * force;
          }
        }
      }

      // Link force for regular relations with adjusted strength - exclude link token nodes
      relations.forEach((relation) => {
        const source = newElements.find((e) => e.id === relation.sourceNodeId);
        const target = newElements.find((e) => e.id === relation.targetNodeId);

        if (source && target && !isLinkTokenNode(source) && !isLinkTokenNode(target)) {
          const dx = target.x - source.x;
          const dy = target.y - source.y;
          const distance = Math.sqrt(dx * dx + dy * dy) || 1;
          const targetDistance = forceConfig.linkDistance;
          const force = (distance - targetDistance) * LINK_STRENGTH;

          if (source.fx === undefined) {
            source.vx += (dx / distance) * force;
            source.vy += (dy / distance) * force;
          }
          if (target.fx === undefined) {
            target.vx -= (dx / distance) * force;
            target.vy -= (dy / distance) * force;
          }
        }
      });

      // Link token nodes: anchor at midpoint (zero force influence)
      newElements.forEach((element) => {
        if (isLinkTokenNode(element)) {
          const source = newElements.find(e => e.id === element.sourceAnnotationId);
          const target = newElements.find(e => e.id === element.targetAnnotationId);
          
          if (source && target) {
            // Set position to exact midpoint, zero velocity
            element.x = (source.x + target.x) / 2;
            element.y = (source.y + target.y) / 2;
            element.vx = 0;
            element.vy = 0;
          }
        }
      });

      // Collision force - exclude link token nodes
      for (let i = 0; i < newElements.length; i++) {
        if (isLinkTokenNode(newElements[i])) continue;
        
        for (let j = i + 1; j < newElements.length; j++) {
          if (isLinkTokenNode(newElements[j])) continue;
          
          const dx = newElements[j].x - newElements[i].x;
          const dy = newElements[j].y - newElements[i].y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          const minDistance = forceConfig.collisionRadius * 2;

          if (distance < minDistance && distance > 0) {
            const force = (minDistance - distance) / distance * 0.5;
            if (newElements[i].fx === undefined) {
              newElements[i].vx -= dx * force;
              newElements[i].vy -= dy * force;
            }
            if (newElements[j].fx === undefined) {
              newElements[j].vx += dx * force;
              newElements[j].vy += dy * force;
            }
          }
        }
      }

      // Check if simulation is stable (only check non-link-token nodes)
      let maxVelocity = 0;
      newElements.forEach((element) => {
        if (element.fx === undefined && !isLinkTokenNode(element)) {
          const velocity = Math.sqrt(element.vx * element.vx + element.vy * element.vy);
          maxVelocity = Math.max(maxVelocity, velocity);
        }
      });

      // If stable, stop applying forces by setting velocities to zero
      if (maxVelocity < VELOCITY_THRESHOLD) {
        setIsSimulationStable(true);
        newElements.forEach((element) => {
          if (element.fx === undefined && !isLinkTokenNode(element)) {
            element.vx = 0;
            element.vy = 0;
          }
        });
      } else {
        // Apply velocity with increased damping (velocity decay) - exclude link token nodes
        newElements.forEach((element) => {
          if (element.fx === undefined && !isLinkTokenNode(element)) {
            element.x += element.vx;
            element.y += element.vy;
            element.vx *= VELOCITY_DECAY;
            element.vy *= VELOCITY_DECAY;
          } else if (element.fx !== undefined) {
            element.x = element.fx;
            element.y = element.fy!;
          }
        });
      }

      return newElements;
    });
  };

  const getConnectedElementIds = (elementId: bigint): Set<bigint> => {
    if (!graphData) return new Set();
    
    const { duplicateMap } = deduplicateAnnotations(graphData.nodes);
    const relations = graphData.relations.map(([_, relation]) => relation);
    const redirectedRelations = redirectRelations(relations, duplicateMap);
    
    const connected = new Set<bigint>();
    connected.add(elementId);
    
    // Check relations
    redirectedRelations.forEach(relation => {
      if (relation.sourceNodeId === elementId) {
        connected.add(relation.targetNodeId);
      }
      if (relation.targetNodeId === elementId) {
        connected.add(relation.sourceNodeId);
      }
    });

    // Check link relations - connect source, target, and link token
    graphData.links.forEach(link => {
      if (link.sourceAnnotationId === elementId) {
        connected.add(link.targetAnnotationId);
        connected.add(link.linkTokenId);
      }
      if (link.targetAnnotationId === elementId) {
        connected.add(link.sourceAnnotationId);
        connected.add(link.linkTokenId);
      }
      if (link.linkTokenId === elementId) {
        connected.add(link.sourceAnnotationId);
        connected.add(link.targetAnnotationId);
      }
    });

    // Check hierarchical includes relations
    if (graphData.includesRelations) {
      graphData.includesRelations.forEach(([_, relation]) => {
        if (relation.sourceNodeId === elementId) {
          connected.add(relation.targetNodeId);
        }
        if (relation.targetNodeId === elementId) {
          connected.add(relation.sourceNodeId);
        }
      });
    }
    
    return connected;
  };

  const isElementVisible = (element: GraphElement): boolean => {
    return filters.nodeTypes.has(element.nodeType);
  };

  const isRelationVisible = (relation: Relation): boolean => {
    const relType = getRelationType(relation);
    return filters.relationTypes.has(relType);
  };

  const getRelationColor = (relation: Relation): string => {
    const relType = getRelationType(relation);
    return relType === RelationType.retrieval ? HIERARCHICAL_COLOR : REASONING_COLOR;
  };

  const getElementColor = (element: GraphElement): string => {
    // For token nodes, use color based on token type
    if (element.nodeType === NodeType.token) {
      const tokenType = getTokenType(element);
      if (tokenType === TokenType.positiveLaw) {
        return nodeColors.positiveLaw;
      } else if (tokenType === TokenType.interpretation) {
        return nodeColors.interpretation;
      } else if (tokenType === TokenType.link) {
        return nodeColors.link;
      }
      return nodeColors[NodeType.token]; // Fallback
    }
    return nodeColors[element.nodeType];
  };

  const screenToSVG = (screenX: number, screenY: number) => {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const rect = svg.getBoundingClientRect();
    return {
      x: (screenX - rect.left - transform.x) / transform.scale,
      y: (screenY - rect.top - transform.y) / transform.scale,
    };
  };

  const handleMouseDown = (e: React.MouseEvent<SVGSVGElement>) => {
    const { x, y } = screenToSVG(e.clientX, e.clientY);
    
    const clickedElement = elements.find((element) => {
      if (!isElementVisible(element)) return false;
      const dx = element.x - x;
      const dy = element.y - y;
      return Math.sqrt(dx * dx + dy * dy) < forceConfig.nodeSize + 4;
    });

    if (clickedElement) {
      isDraggingElementRef.current = clickedElement;
      setIsSimulationStable(false); // Resume simulation when dragging
      setElements((prevElements) =>
        prevElements.map((e) =>
          e.id === clickedElement.id ? { ...e, fx: e.x, fy: e.y } : e
        )
      );
    } else {
      isPanningRef.current = true;
      panStartRef.current = { x: e.clientX - transform.x, y: e.clientY - transform.y };
    }
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (isDraggingElementRef.current) {
      const { x, y } = screenToSVG(e.clientX, e.clientY);
      setElements((prevElements) =>
        prevElements.map((e) =>
          e.id === isDraggingElementRef.current!.id
            ? { ...e, x, y, fx: x, fy: y, vx: 0, vy: 0 }
            : e
        )
      );
    } else if (isPanningRef.current) {
      setTransform((prev) => ({
        ...prev,
        x: e.clientX - panStartRef.current.x,
        y: e.clientY - panStartRef.current.y,
      }));
    }
  };

  const handleMouseUp = () => {
    if (isDraggingElementRef.current) {
      const elementId = isDraggingElementRef.current.id;
      setElements((prevElements) =>
        prevElements.map((e) => {
          if (e.id === elementId) {
            const { fx, fy, ...rest } = e;
            return rest;
          }
          return e;
        })
      );
      isDraggingElementRef.current = null;
    }
    isPanningRef.current = false;
  };

  const handleElementClick = (element: GraphElement) => {
    if (focusedElement?.id === element.id) {
      setFocusedElement(null);
      setSelectedElement(null);
    } else {
      setFocusedElement(element);
      setSelectedElement(element);
    }
  };

  const handleZoomIn = () => {
    setTransform((prev) => ({ ...prev, scale: Math.min(prev.scale * 1.2, 3) }));
  };

  const handleZoomOut = () => {
    setTransform((prev) => ({ ...prev, scale: Math.max(prev.scale / 1.2, 0.3) }));
  };

  const handleReset = () => {
    setTransform({ x: 0, y: 0, scale: 1 });
    setFocusedElement(null);
    setSelectedElement(null);
  };

  const handleWheel = (e: React.WheelEvent<SVGSVGElement>) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setTransform((prev) => ({
      ...prev,
      scale: Math.max(0.3, Math.min(3, prev.scale * delta)),
    }));
  };

  const canvasBackgroundColor = isDarkMode ? '#1a1a1a' : '#ffffff';
  const textColor = isDarkMode ? '#ffffff' : '#000000';
  const nodeStrokeColor = isDarkMode ? '#ffffff' : '#000000';
  const nodeHoverStrokeColor = isDarkMode ? '#d4a017' : '#8b6914';
  const textStrokeColor = isDarkMode ? 'none' : '#ffffff';
  const textStrokeWidth = isDarkMode ? 0 : 1;

  const getCursorStyle = () => {
    if (isPanningRef.current) return 'grabbing';
    if (isDraggingElementRef.current) return 'grabbing';
    return '';
  };

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center bg-background">
        <div className="text-center">
          <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-[#d4a017] border-t-transparent mx-auto" />
          <p className="text-muted-foreground">Loading graph...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto p-6 bg-background">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>Failed to load graph data: {error.message}</AlertDescription>
        </Alert>
      </div>
    );
  }

  if (!graphData || graphData.nodes.length === 0) {
    return (
      <div className="flex h-full items-center justify-center bg-background p-6">
        <div className="text-center space-y-4 max-w-md">
          <div className="flex justify-center">
            <div className="rounded-full bg-muted p-6">
              <Filter className="h-12 w-12 text-muted-foreground" />
            </div>
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-semibold">No Graph Data</h3>
            <p className="text-sm text-muted-foreground">
              Create curations, swarms, and annotations to see them visualized here with force-directed layout.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const connectedElementIds = focusedElement ? getConnectedElementIds(focusedElement.id) : null;
  const visibleElements = elements.filter(isElementVisible);
  
  const { duplicateMap } = deduplicateAnnotations(graphData.nodes);
  const relations = graphData.relations.map(([_, relation]) => relation);
  const redirectedRelations = redirectRelations(relations, duplicateMap);
  const visibleRelations = redirectedRelations.filter(isRelationVisible);

  // Count hierarchical relations
  const hierarchicalRelations = graphData.includesRelations || [];
  const hierarchicalCount = hierarchicalRelations.length;

  // Count reasoning relations (both regular and link relations)
  const reasoningCount = redirectedRelations.filter(r => getRelationType(r) === RelationType.reasoning).length + (graphData.links?.length || 0);

  return (
    <div ref={containerRef} className="relative h-full w-full overflow-hidden" style={{ backgroundColor: canvasBackgroundColor }}>
      <svg
        ref={svgRef}
        className={`w-full h-full ${getCursorStyle() ? '' : 'theme-cursor-crosshair'}`}
        style={{ 
          cursor: getCursorStyle() || undefined,
          shapeRendering: 'crispEdges'
        }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
      >
        <g transform={`translate(${transform.x},${transform.y}) scale(${transform.scale})`}>
          {/* Render hierarchical includes relations as solid gold lines */}
          {isRenderReady && filters.showHierarchical && hierarchicalRelations.map(([id, relation], idx) => {
            const source = elements.find((e) => e.id === relation.sourceNodeId);
            const target = elements.find((e) => e.id === relation.targetNodeId);
            if (!source || !target) return null;
            if (!isElementVisible(source) || !isElementVisible(target)) return null;

            const isConnected = connectedElementIds 
              ? (connectedElementIds.has(source.id) && connectedElementIds.has(target.id))
              : true;
            const opacity = connectedElementIds ? (isConnected ? 0.9 : 0.1) : 0.8;

            return (
              <line
                key={`hierarchical-${id.toString()}-${idx}`}
                x1={source.x}
                y1={source.y}
                x2={target.x}
                y2={target.y}
                stroke={HIERARCHICAL_COLOR}
                strokeWidth={forceConfig.lineWidth}
                strokeDasharray="0"
                opacity={opacity}
                style={{ shapeRendering: 'crispEdges' }}
              />
            );
          })}

          {/* Render regular relations */}
          {isRenderReady && visibleRelations.map((relation, idx) => {
            const source = elements.find((e) => e.id === relation.sourceNodeId);
            const target = elements.find((e) => e.id === relation.targetNodeId);
            if (!source || !target) return null;
            if (!isElementVisible(source) || !isElementVisible(target)) return null;

            const relType = getRelationType(relation);
            const isConnected = connectedElementIds 
              ? (connectedElementIds.has(source.id) && connectedElementIds.has(target.id))
              : true;
            const opacity = connectedElementIds ? (isConnected ? 0.9 : 0.1) : 0.8;

            const strokeDasharray = relType === RelationType.reasoning ? '4,4' : '0';

            return (
              <line
                key={`rel-${relation.id.toString()}-${idx}`}
                x1={source.x}
                y1={source.y}
                x2={target.x}
                y2={target.y}
                stroke={getRelationColor(relation)}
                strokeWidth={forceConfig.lineWidth}
                strokeDasharray={strokeDasharray}
                opacity={opacity}
                style={{ shapeRendering: 'crispEdges' }}
              />
            );
          })}

          {/* Render link relations as two dashed green lines: source→linkToken and linkToken→target */}
          {isRenderReady && filters.relationTypes.has(RelationType.reasoning) && graphData.links?.map((link, idx) => {
            const sourceElement = elements.find(e => e.id === link.sourceAnnotationId);
            const targetElement = elements.find(e => e.id === link.targetAnnotationId);
            const linkTokenElement = elements.find(e => isLinkTokenNode(e) && (e as LinkTokenNode).linkRelationId === link.id);

            if (!sourceElement || !targetElement || !linkTokenElement) return null;
            if (!isElementVisible(sourceElement) || !isElementVisible(targetElement) || !isElementVisible(linkTokenElement)) return null;

            const isConnected = connectedElementIds 
              ? (connectedElementIds.has(sourceElement.id) && connectedElementIds.has(targetElement.id) && connectedElementIds.has(linkTokenElement.id))
              : true;
            const opacity = connectedElementIds ? (isConnected ? 0.9 : 0.1) : 0.8;

            return (
              <g key={`link-${link.id.toString()}-${idx}`}>
                {/* Line from source to link token */}
                <line
                  x1={sourceElement.x}
                  y1={sourceElement.y}
                  x2={linkTokenElement.x}
                  y2={linkTokenElement.y}
                  stroke={REASONING_COLOR}
                  strokeWidth={forceConfig.lineWidth}
                  strokeDasharray="4,4"
                  opacity={opacity}
                  style={{ shapeRendering: 'crispEdges' }}
                />
                {/* Line from link token to target */}
                <line
                  x1={linkTokenElement.x}
                  y1={linkTokenElement.y}
                  x2={targetElement.x}
                  y2={targetElement.y}
                  stroke={REASONING_COLOR}
                  strokeWidth={forceConfig.lineWidth}
                  strokeDasharray="4,4"
                  opacity={opacity}
                  style={{ shapeRendering: 'crispEdges' }}
                />
              </g>
            );
          })}

          {/* Render nodes (including link token nodes) */}
          {visibleElements.map((element) => {
            const isSelected = selectedElement?.id === element.id;
            const isFocused = focusedElement?.id === element.id;
            const isConnected = connectedElementIds ? connectedElementIds.has(element.id) : true;
            const opacity = connectedElementIds ? (isConnected ? 1 : 0.15) : 1;
            const radius = isSelected ? forceConfig.nodeSize + 4 : forceConfig.nodeSize;
            
            const elementTitle = getElementTitle(element);

            return (
              <g
                key={element.id.toString()}
                transform={`translate(${element.x},${element.y})`}
                onClick={() => handleElementClick(element)}
                style={{ cursor: 'pointer' }}
                opacity={opacity}
              >
                <circle
                  r={radius}
                  fill={getElementColor(element)}
                  stroke={isFocused ? nodeHoverStrokeColor : nodeStrokeColor}
                  strokeWidth={isFocused ? 3 : 2}
                  style={{ shapeRendering: 'crispEdges' }}
                />
                {isRenderReady && (
                  <text
                    y={radius + 15}
                    textAnchor="middle"
                    fontSize={isSelected ? '12px' : '11px'}
                    fontWeight={isSelected ? 'bold' : 'normal'}
                    fill={textColor}
                    stroke={textStrokeColor}
                    strokeWidth={textStrokeWidth}
                    paintOrder="stroke"
                    style={{ shapeRendering: 'crispEdges' }}
                  >
                    {elementTitle}
                  </text>
                )}
              </g>
            );
          })}
        </g>
      </svg>

      {/* Zoom controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
        <Button variant="secondary" size="icon" onClick={handleZoomIn} title="Zoom in">
          <ZoomIn className="h-4 w-4" />
        </Button>
        <Button variant="secondary" size="icon" onClick={handleZoomOut} title="Zoom out">
          <ZoomOut className="h-4 w-4" />
        </Button>
        <Button variant="secondary" size="icon" onClick={handleReset} title="Reset view">
          <Maximize2 className="h-4 w-4" />
        </Button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="secondary" size="icon" title="Export graph data">
              <Download className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={exportToJSONLD}>
              Export as JSON-LD
            </DropdownMenuItem>
            <DropdownMenuItem onClick={exportToCSV}>
              Export as CSV
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button 
          variant="secondary" 
          size="icon" 
          onClick={handleImportClick}
          title="Import graph data"
        >
          <Upload className="h-4 w-4" />
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept=".jsonld,.csv"
          onChange={handleFileImport}
          className="hidden"
        />
      </div>

      {/* Selected element info */}
      {selectedElement && (
        <div className="absolute bottom-4 left-4 right-4 md:right-auto md:max-w-md bg-card border border-border rounded-lg p-4 shadow-lg z-10">
          <div className="flex items-start gap-3">
            <Badge variant="outline" className="bg-muted">
              {selectedElement.nodeType}
              {selectedElement.nodeType === NodeType.token && (() => {
                const tokenType = getTokenType(selectedElement);
                return tokenType ? ` (${tokenType})` : '';
              })()}
            </Badge>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold truncate text-card-foreground">{getElementTitle(selectedElement)}</h3>
              {isGraphNode(selectedElement) && selectedElement.bracketedTokenSequence && selectedElement.bracketedTokenSequence.trim() && (
                <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{selectedElement.bracketedTokenSequence}</p>
              )}
              {focusedElement && (
                <p className="text-xs text-muted-foreground mt-2">
                  Click again to clear focus • Connected elements highlighted
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Control panels container */}
      <div className="absolute top-4 left-4 flex flex-col gap-3 w-72 z-10" style={{ maxHeight: 'calc(100vh - 2rem)' }}>
        {/* Force controls */}
        <Card className="shadow-lg flex-shrink-0">
          <Collapsible open={forceControlsOpen} onOpenChange={setForceControlsOpen}>
            <CardHeader className="pb-3">
              <CollapsibleTrigger asChild>
                <div className="flex items-center justify-between cursor-pointer">
                  <CardTitle className="text-sm font-semibold">Forces</CardTitle>
                  {forceControlsOpen ? (
                    <ChevronUp className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </div>
              </CollapsibleTrigger>
            </CardHeader>
            <CollapsibleContent>
              <CardContent className="space-y-4 pt-0">
                <div className="space-y-2">
                  <Label className="text-xs">Charge strength</Label>
                  <Slider
                    value={[Math.abs(forceConfig.chargeStrength)]}
                    onValueChange={([value]) => {
                      setForceConfig(prev => ({ ...prev, chargeStrength: -value }));
                      setIsSimulationStable(false); // Resume simulation when config changes
                    }}
                    min={50}
                    max={1000}
                    step={10}
                    className="w-full"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Link distance</Label>
                  <Slider
                    value={[forceConfig.linkDistance]}
                    onValueChange={([value]) => {
                      setForceConfig(prev => ({ ...prev, linkDistance: value }));
                      setIsSimulationStable(false);
                    }}
                    min={50}
                    max={300}
                    step={10}
                    className="w-full"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Node collision radius</Label>
                  <Slider
                    value={[forceConfig.collisionRadius]}
                    onValueChange={([value]) => {
                      setForceConfig(prev => ({ ...prev, collisionRadius: value }));
                      setIsSimulationStable(false);
                    }}
                    min={10}
                    max={100}
                    step={5}
                    className="w-full"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Relation line width</Label>
                  <Slider
                    value={[forceConfig.lineWidth]}
                    onValueChange={([value]) => setForceConfig(prev => ({ ...prev, lineWidth: value }))}
                    min={0.5}
                    max={5}
                    step={0.5}
                    className="w-full"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Node size</Label>
                  <Slider
                    value={[forceConfig.nodeSize]}
                    onValueChange={([value]) => setForceConfig(prev => ({ ...prev, nodeSize: value }))}
                    min={4}
                    max={20}
                    step={1}
                    className="w-full"
                  />
                </div>
              </CardContent>
            </CollapsibleContent>
          </Collapsible>
        </Card>

        {/* Filter controls */}
        <Card className="shadow-lg flex flex-col min-h-0 overflow-hidden">
          <Collapsible open={filtersOpen} onOpenChange={setFiltersOpen}>
            <CardHeader className="pb-3 flex-shrink-0">
              <CollapsibleTrigger asChild>
                <div className="flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    <CardTitle className="text-sm font-semibold">Filters & Legend</CardTitle>
                  </div>
                  {filtersOpen ? (
                    <ChevronUp className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </div>
              </CollapsibleTrigger>
            </CardHeader>
            <CollapsibleContent className="flex-1 min-h-0">
              <ScrollArea className="h-full max-h-[40vh]">
                <CardContent className="space-y-4 pt-0 pr-4">
                  <div className="space-y-3">
                    <Label className="text-xs font-semibold">Node Types</Label>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="node-curation"
                        checked={filters.nodeTypes.has(NodeType.curation)}
                        onCheckedChange={() => toggleNodeTypeFilter(NodeType.curation)}
                      />
                      <label
                        htmlFor="node-curation"
                        className="text-sm cursor-pointer flex items-center gap-2"
                      >
                        <div
                          className="w-4 h-4 rounded-full border border-border flex-shrink-0"
                          style={{ backgroundColor: nodeColors[NodeType.curation] }}
                        />
                        <span>Curation</span>
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="node-swarm"
                        checked={filters.nodeTypes.has(NodeType.swarm)}
                        onCheckedChange={() => toggleNodeTypeFilter(NodeType.swarm)}
                      />
                      <label
                        htmlFor="node-swarm"
                        className="text-sm cursor-pointer flex items-center gap-2"
                      >
                        <div
                          className="w-4 h-4 rounded-full border border-border flex-shrink-0"
                          style={{ backgroundColor: nodeColors[NodeType.swarm] }}
                        />
                        <span>Swarm</span>
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="node-annotation"
                        checked={filters.nodeTypes.has(NodeType.annotation)}
                        onCheckedChange={() => toggleNodeTypeFilter(NodeType.annotation)}
                      />
                      <label
                        htmlFor="node-annotation"
                        className="text-sm cursor-pointer flex items-center gap-2"
                      >
                        <div
                          className="w-4 h-4 rounded-full border border-border flex-shrink-0"
                          style={{ backgroundColor: nodeColors[NodeType.annotation] }}
                        />
                        <span>Annotation</span>
                      </label>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-3">
                    <Label className="text-xs font-semibold">Token Type Colors</Label>
                    <div className="flex items-center gap-2">
                      <div
                        className="w-4 h-4 rounded-full border border-border flex-shrink-0"
                        style={{ backgroundColor: nodeColors.positiveLaw }}
                      />
                      <span className="text-sm">Positive Law (Blue)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div
                        className="w-4 h-4 rounded-full border border-border flex-shrink-0"
                        style={{ backgroundColor: nodeColors.interpretation }}
                      />
                      <span className="text-sm">Interpretation (Pink)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div
                        className="w-4 h-4 rounded-full border border-border flex-shrink-0"
                        style={{ backgroundColor: nodeColors.link }}
                      />
                      <span className="text-sm">Link Tokens (Cyan)</span>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-3">
                    <Label className="text-xs font-semibold">Relation Types</Label>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="relation-hierarchical"
                        checked={filters.showHierarchical}
                        onCheckedChange={toggleHierarchicalFilter}
                      />
                      <label
                        htmlFor="relation-hierarchical"
                        className="text-sm cursor-pointer flex items-center gap-2"
                      >
                        <div 
                          className="h-0.5 w-6 rounded flex-shrink-0" 
                          style={{ backgroundColor: HIERARCHICAL_COLOR }}
                        />
                        <span>Hierarchical ({hierarchicalCount})</span>
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        id="relation-reasoning"
                        checked={filters.relationTypes.has(RelationType.reasoning)}
                        onCheckedChange={() => toggleRelationTypeFilter(RelationType.reasoning)}
                      />
                      <label
                        htmlFor="relation-reasoning"
                        className="text-sm cursor-pointer flex items-center gap-2"
                      >
                        <svg width="24" height="2" className="flex-shrink-0">
                          <line 
                            x1="0" 
                            y1="1" 
                            x2="24" 
                            y2="1" 
                            stroke={REASONING_COLOR} 
                            strokeWidth="2" 
                            strokeDasharray="4,4"
                          />
                        </svg>
                        <span>Reasoning ({reasoningCount})</span>
                      </label>
                    </div>
                  </div>
                </CardContent>
              </ScrollArea>
            </CollapsibleContent>
          </Collapsible>
        </Card>
      </div>
    </div>
  );
}
