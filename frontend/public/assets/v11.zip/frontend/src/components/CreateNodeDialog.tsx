import { useState, useEffect, useMemo, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useCreateNode, useGetGraphData, useCreateAnnotationWithTokens, useGetAutocompleteResults, useGetCallerBuzzBalance } from '../hooks/useQueries';
import { useActorState } from '../hooks/useActorState';
import { NodeType } from '../types';
import { toast } from 'sonner';
import { Layers, FolderTree, FileText, AlertCircle, Coins } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

interface CreateNodeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  parentId?: bigint | null;
}

type AutocompleteType = 'positiveLaw' | 'interpretation' | 'rdf' | 'link' | null;

interface AutocompleteItem {
  type: AutocompleteType;
  display: string;
  insertText: string;
}

export default function CreateNodeDialog({ open, onOpenChange, parentId }: CreateNodeDialogProps) {
  const [title, setTitle] = useState('');
  const [tokenSequence, setTokenSequence] = useState('');
  const [nodeType, setNodeType] = useState<NodeType>(NodeType.curation);
  const [validationError, setValidationError] = useState<string>('');
  
  // Autocomplete state
  const [showAutocomplete, setShowAutocomplete] = useState(false);
  const [autocompleteType, setAutocompleteType] = useState<AutocompleteType>(null);
  const [autocompleteItems, setAutocompleteItems] = useState<AutocompleteItem[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [cursorPosition, setCursorPosition] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [bracketStartPos, setBracketStartPos] = useState(-1);
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  const { isActorReady, error: actorError } = useActorState();
  const { data: graphData } = useGetGraphData();
  const { data: autocompleteData } = useGetAutocompleteResults();
  const { data: buzzBalance } = useGetCallerBuzzBalance();
  const { mutate: createNode, isPending: isCreatingNode } = useCreateNode();
  const { mutate: createAnnotationWithTokens, isPending: isCreatingAnnotation } = useCreateAnnotationWithTokens();

  const isPending = isCreatingNode || isCreatingAnnotation;

  // Find parent node from graph data
  const parentNode = useMemo(() => {
    if (!parentId || !graphData?.nodes) return null;
    return graphData.nodes.find(node => node.id === parentId) || null;
  }, [parentId, graphData]);

  // Determine the correct child node type based on parent
  const getChildNodeType = (): NodeType => {
    if (!parentNode) {
      return NodeType.curation;
    }
    if (parentNode.nodeType === NodeType.curation) {
      return NodeType.swarm;
    }
    if (parentNode.nodeType === NodeType.swarm) {
      return NodeType.annotation;
    }
    return NodeType.curation;
  };

  // Calculate required BUZZ for annotation
  const calculateRequiredBuzz = (text: string): number => {
    if (!text.trim() || !autocompleteData) return 0;

    const positiveLawPattern = /\{[^}]+\}/g;
    const interpretationPattern = /\([^)]+\)/g;
    const positiveLawMatches = text.match(positiveLawPattern);
    const interpretationMatches = text.match(interpretationPattern);

    let totalBuzz = 0;
    const seenTokens = new Map<string, number>();

    // Calculate BUZZ for positive law tokens
    if (positiveLawMatches) {
      for (const match of positiveLawMatches) {
        const tokenName = match.slice(1, -1).toLowerCase().trim();
        if (tokenName) {
          const occurrences = (seenTokens.get(tokenName) || 0) + 1;
          seenTokens.set(tokenName, occurrences);

          const existingToken = autocompleteData.positiveLawTokens.find(
            t => t.name.toLowerCase() === tokenName
          );
          
          if (occurrences > 1) {
            totalBuzz += 10;
          } else if (existingToken) {
            totalBuzz += 5 + (5 * (Number(existingToken.buzzValue) / 5));
          } else {
            totalBuzz += 5;
          }
        }
      }
    }

    // Calculate BUZZ for interpretation tokens
    if (interpretationMatches) {
      for (const match of interpretationMatches) {
        const tokenName = match.slice(1, -1).toLowerCase().trim();
        if (tokenName) {
          const occurrences = (seenTokens.get(tokenName) || 0) + 1;
          seenTokens.set(tokenName, occurrences);

          const existingToken = autocompleteData.interpretationTokens.find(
            t => t.name.toLowerCase() === tokenName
          );
          
          if (occurrences > 1) {
            totalBuzz += 10;
          } else if (existingToken) {
            totalBuzz += 5 + (5 * (Number(existingToken.buzzValue) / 5));
          } else {
            totalBuzz += 5;
          }
        }
      }
    }

    return totalBuzz;
  };

  const requiredBuzz = useMemo(() => {
    if (nodeType === NodeType.annotation) {
      return calculateRequiredBuzz(tokenSequence);
    }
    return 0;
  }, [tokenSequence, nodeType, autocompleteData]);

  const currentBalance = Number(buzzBalance || 0n);
  const hasInsufficientBuzz = nodeType === NodeType.annotation && requiredBuzz > currentBalance;

  // Reset form when dialog opens/closes
  useEffect(() => {
    if (open) {
      setTitle('');
      setTokenSequence('');
      setValidationError('');
      setShowAutocomplete(false);
      setAutocompleteType(null);
      setSelectedIndex(0);
      setSearchQuery('');
      setBracketStartPos(-1);
      const childType = getChildNodeType();
      setNodeType(childType);
    }
  }, [open]);

  // Real-time validation for token sequence
  useEffect(() => {
    if (nodeType === NodeType.annotation && tokenSequence.trim()) {
      const positiveLawPattern = /\{[^}]+\}/g;
      const interpretationPattern = /\([^)]+\)/g;
      const positiveLawMatches = tokenSequence.match(positiveLawPattern);
      const interpretationMatches = tokenSequence.match(interpretationPattern);
      
      if ((!positiveLawMatches || positiveLawMatches.length === 0) && 
          (!interpretationMatches || interpretationMatches.length === 0)) {
        setValidationError('Token sequence must contain at least one properly formatted token (e.g., {token} or (token))');
      } else {
        setValidationError('');
      }
    } else if (nodeType === NodeType.annotation && !tokenSequence.trim()) {
      setValidationError('');
    } else {
      setValidationError('');
    }
  }, [tokenSequence, nodeType]);

  // Check if cursor is inside RDF brackets for link token autocomplete
  const isInsideRDFBrackets = (text: string, cursorPos: number): boolean => {
    let insideRDF = false;
    let lastOpenBracket = -1;
    
    for (let i = 0; i < cursorPos; i++) {
      if (text[i] === '[') {
        lastOpenBracket = i;
        insideRDF = true;
      } else if (text[i] === ']' && lastOpenBracket !== -1) {
        insideRDF = false;
        lastOpenBracket = -1;
      }
    }
    
    return insideRDF && lastOpenBracket !== -1;
  };

  // Filter autocomplete items based on search query with debouncing
  useEffect(() => {
    if (!showAutocomplete || !autocompleteType || !autocompleteData) {
      return;
    }

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    debounceTimerRef.current = setTimeout(() => {
      const query = searchQuery.toLowerCase().trim();
      let allItems: AutocompleteItem[] = [];

      if (autocompleteType === 'positiveLaw' && autocompleteData.positiveLawTokens) {
        allItems = autocompleteData.positiveLawTokens.map(token => ({
          type: 'positiveLaw' as AutocompleteType,
          display: `${token.name} (BUZZ: ${token.buzzValue})`,
          insertText: `{${token.name}}`,
        }));
      } else if (autocompleteType === 'interpretation' && autocompleteData.interpretationTokens) {
        allItems = autocompleteData.interpretationTokens.map(token => ({
          type: 'interpretation' as AutocompleteType,
          display: `${token.name} (BUZZ: ${token.buzzValue})`,
          insertText: `(${token.name})`,
        }));
      } else if (autocompleteType === 'rdf' && autocompleteData.rdfs) {
        allItems = autocompleteData.rdfs.map(rdf => ({
          type: 'rdf' as AutocompleteType,
          display: `[${rdf.subject}, ${rdf.predicate}, ${rdf.rdfObject}]`,
          insertText: `[${rdf.subject}, ${rdf.predicate}, ${rdf.rdfObject}]`,
        }));
      } else if (autocompleteType === 'link' && autocompleteData.linkTokens) {
        allItems = autocompleteData.linkTokens.map(token => ({
          type: 'link' as AutocompleteType,
          display: `${token.name} (BUZZ: ${token.buzzValue})`,
          insertText: `<${token.name}>`,
        }));
      }

      const filteredItems = query
        ? allItems.filter(item => {
            if (item.type === 'positiveLaw' || item.type === 'interpretation' || item.type === 'link') {
              const tokenName = item.insertText.slice(1, -1).toLowerCase();
              return tokenName.includes(query);
            }
            if (item.type === 'rdf') {
              return item.display.toLowerCase().includes(query);
            }
            return false;
          })
        : allItems;

      setAutocompleteItems(filteredItems);
      setSelectedIndex(0);
    }, 150);

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, [searchQuery, showAutocomplete, autocompleteType, autocompleteData]);

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    const newCursorPos = e.target.selectionStart;
    
    setTokenSequence(newValue);
    setCursorPosition(newCursorPos);
    
    if (newCursorPos > 0) {
      const charBeforeCursor = newValue[newCursorPos - 1];
      
      if (charBeforeCursor === '{' || charBeforeCursor === '(' || charBeforeCursor === '[' || charBeforeCursor === '<') {
        const textBeforeCursor = newValue.substring(0, newCursorPos);
        const lastOpenBracket = Math.max(
          textBeforeCursor.lastIndexOf('{'),
          textBeforeCursor.lastIndexOf('('),
          textBeforeCursor.lastIndexOf('['),
          textBeforeCursor.lastIndexOf('<')
        );
        
        if (lastOpenBracket === newCursorPos - 1) {
          let type: AutocompleteType = null;
          
          if (charBeforeCursor === '{') {
            type = 'positiveLaw';
          } else if (charBeforeCursor === '(') {
            type = 'interpretation';
          } else if (charBeforeCursor === '[') {
            type = 'rdf';
          } else if (charBeforeCursor === '<') {
            // Only show link token autocomplete if inside RDF brackets
            if (isInsideRDFBrackets(newValue, newCursorPos - 1)) {
              type = 'link';
            }
          }
          
          if (type && autocompleteData) {
            setAutocompleteType(type);
            setBracketStartPos(lastOpenBracket);
            setSearchQuery('');
            setShowAutocomplete(true);
            setSelectedIndex(0);
          }
        }
      } else if (showAutocomplete && bracketStartPos >= 0) {
        const textAfterBracket = newValue.substring(bracketStartPos + 1, newCursorPos);
        
        const closingBracket = autocompleteType === 'positiveLaw' ? '}' : 
                              autocompleteType === 'interpretation' ? ')' :
                              autocompleteType === 'link' ? '>' : ']';
        
        if (textAfterBracket.includes(closingBracket) || 
            textAfterBracket.includes('\n') ||
            newCursorPos <= bracketStartPos) {
          setShowAutocomplete(false);
          setSearchQuery('');
          setBracketStartPos(-1);
        } else {
          setSearchQuery(textAfterBracket);
        }
      } else {
        if (showAutocomplete) {
          setShowAutocomplete(false);
          setSearchQuery('');
          setBracketStartPos(-1);
        }
      }
    } else {
      if (showAutocomplete) {
        setShowAutocomplete(false);
        setSearchQuery('');
        setBracketStartPos(-1);
      }
    }
  };

  const handleTextareaKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (!showAutocomplete || autocompleteItems.length === 0) return;
    
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev + 1) % autocompleteItems.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev - 1 + autocompleteItems.length) % autocompleteItems.length);
    } else if (e.key === 'Enter' && autocompleteItems.length > 0) {
      e.preventDefault();
      handleAutocompleteSelect(autocompleteItems[selectedIndex]);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      setShowAutocomplete(false);
      setSearchQuery('');
      setBracketStartPos(-1);
    }
  };

  const handleAutocompleteSelect = (item: AutocompleteItem) => {
    if (!textareaRef.current || bracketStartPos < 0) return;
    
    const textarea = textareaRef.current;
    const text = tokenSequence;
    
    const newText = text.substring(0, bracketStartPos) + item.insertText + text.substring(cursorPosition);
    setTokenSequence(newText);
    
    const newCursorPos = bracketStartPos + item.insertText.length;
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
    
    setShowAutocomplete(false);
    setSearchQuery('');
    setBracketStartPos(-1);
  };

  const getNodeTypeDescription = (type: NodeType): string => {
    switch (type) {
      case NodeType.curation:
        return 'Top-level container for organizing knowledge';
      case NodeType.swarm:
        return 'Collection of related content within a Curation';
      case NodeType.annotation:
        return 'Content item with token extraction from bracketed sequences';
      default:
        return '';
    }
  };

  const getDialogTitle = (): string => {
    switch (nodeType) {
      case NodeType.swarm:
        return 'Create New Swarm';
      case NodeType.annotation:
        return 'Create New Annotation';
      case NodeType.curation:
      default:
        return 'Create New Curation';
    }
  };

  const getButtonText = (): string => {
    switch (nodeType) {
      case NodeType.swarm:
        return 'Create Swarm';
      case NodeType.annotation:
        return 'Create Annotation';
      case NodeType.curation:
      default:
        return 'Create Curation';
    }
  };

  const getDialogDescription = (): string => {
    if (!parentNode) {
      return 'Create a new top-level Curation to organize your knowledge';
    }
    
    const nodeTypeLabel = nodeType.charAt(0).toUpperCase() + nodeType.slice(1);
    return `Creating a ${nodeTypeLabel} under "${parentNode.title}"`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isActorReady) {
      toast.error('Connection not ready. Please wait a moment and try again.');
      return;
    }

    if (!title.trim()) {
      toast.error('Please enter a title');
      return;
    }

    if (nodeType === NodeType.annotation) {
      if (!tokenSequence.trim()) {
        toast.error('Please enter content');
        return;
      }

      const positiveLawPattern = /\{[^}]+\}/g;
      const interpretationPattern = /\([^)]+\)/g;
      const positiveLawMatches = tokenSequence.match(positiveLawPattern);
      const interpretationMatches = tokenSequence.match(interpretationPattern);
      
      if ((!positiveLawMatches || positiveLawMatches.length === 0) && 
          (!interpretationMatches || interpretationMatches.length === 0)) {
        toast.error('Content must contain at least one properly formatted token (e.g., {token} or (token))');
        return;
      }

      if (hasInsufficientBuzz) {
        toast.error(`Insufficient BUZZ balance. Required: ${requiredBuzz}, Available: ${currentBalance}`);
        return;
      }

      if (!parentId) {
        toast.error('Parent swarm is required for annotations');
        return;
      }

      createAnnotationWithTokens(
        {
          title: title.trim(),
          bracketedTokenSequence: tokenSequence.trim(),
          nodeType: NodeType.annotation,
          parentId: parentId ?? undefined,
        },
        {
          onSuccess: (result) => {
            toast.success('Annotation created successfully! BUZZ deducted from your balance.');
            onOpenChange(false);
          },
          onError: (error) => {
            const errorMessage = error.message || 'Failed to create annotation';
            toast.error(errorMessage);
          },
        }
      );
    } else {
      createNode(
        {
          title: title.trim(),
          bracketedTokenSequence: '',
          nodeType,
          parentId: parentId ?? undefined,
        },
        {
          onSuccess: () => {
            const nodeTypeLabel = nodeType.charAt(0).toUpperCase() + nodeType.slice(1);
            toast.success(`${nodeTypeLabel} created successfully`);
            onOpenChange(false);
          },
          onError: (error) => {
            toast.error(error.message || 'Failed to create node');
          },
        }
      );
    }
  };

  const getNodeTypeIcon = (type: NodeType) => {
    switch (type) {
      case NodeType.curation:
        return <Layers className="h-4 w-4" />;
      case NodeType.swarm:
        return <FolderTree className="h-4 w-4" />;
      case NodeType.annotation:
        return <FileText className="h-4 w-4" />;
      default:
        return null;
    }
  };

  const getNodeTypeLabel = (type: NodeType) => {
    return type.charAt(0).toUpperCase() + type.slice(1);
  };

  const isFormDisabled = !isActorReady || isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{getDialogTitle()}</DialogTitle>
          <DialogDescription>
            {getDialogDescription()}
          </DialogDescription>
        </DialogHeader>

        {!isActorReady && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {actorError || 'Connecting to the network... Please wait.'}
            </AlertDescription>
          </Alert>
        )}

        {nodeType === NodeType.annotation && (
          <div className="rounded-lg border bg-card p-4 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Coins className="h-5 w-5 text-primary" />
                <span className="font-semibold">BUZZ Balance</span>
              </div>
              <span className="text-2xl font-bold tabular-nums">{currentBalance}</span>
            </div>
            
            {requiredBuzz > 0 && (
              <>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Required for this annotation:</span>
                  <span className="font-semibold tabular-nums">{requiredBuzz}</span>
                </div>
                <div className="flex items-center justify-between text-sm border-t pt-2">
                  <span className="text-muted-foreground">Balance after creation:</span>
                  <span className={`font-semibold tabular-nums ${hasInsufficientBuzz ? 'text-destructive' : 'text-green-600 dark:text-green-400'}`}>
                    {currentBalance - requiredBuzz}
                  </span>
                </div>
              </>
            )}

            {hasInsufficientBuzz && (
              <Alert variant="destructive" className="mt-2">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Insufficient BUZZ balance. You need {requiredBuzz - currentBalance} more BUZZ to create this annotation.
                </AlertDescription>
              </Alert>
            )}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="nodeType">Node Type</Label>
            <Select
              value={nodeType}
              onValueChange={(value) => setNodeType(value as NodeType)}
              disabled={true}
            >
              <SelectTrigger id="nodeType">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={nodeType}>
                  <div className="flex items-center gap-2">
                    {getNodeTypeIcon(nodeType)}
                    {getNodeTypeLabel(nodeType)}
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              {getNodeTypeDescription(nodeType)}
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">
              {nodeType === NodeType.annotation ? 'Annotation Name' : 'Title'}
            </Label>
            <Input
              id="title"
              placeholder={nodeType === NodeType.annotation ? 'section of a statute, para of a case, etc.' : 'Enter node title'}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              disabled={isFormDisabled}
              maxLength={100}
              autoFocus
            />
            <p className="text-xs text-muted-foreground">{title.length}/100 characters</p>
          </div>

          {nodeType === NodeType.annotation && (
            <>
              <div className="space-y-2 relative">
                <Label htmlFor="tokenSequence">Content</Label>
                <Textarea
                  ref={textareaRef}
                  id="tokenSequence"
                  placeholder="Use curly brackets for positive law tokens, e.g. {appropriate authority} {means}{the State}. Use a combination of boxed, angled and round brackets to add your interpretation via custom links, e.g. [{the State} <is not> (the Nation in this context)]."
                  value={tokenSequence}
                  onChange={handleTextareaChange}
                  onKeyDown={handleTextareaKeyDown}
                  disabled={isFormDisabled}
                  rows={6}
                  className="resize-none"
                />
                
                {showAutocomplete && autocompleteItems.length > 0 && (
                  <div className="absolute z-50 w-full mt-1 bg-popover border border-border rounded-md shadow-lg max-h-60 overflow-y-auto">
                    {autocompleteItems.map((item, index) => (
                      <button
                        key={index}
                        type="button"
                        className={`w-full text-left px-3 py-2 text-sm hover:bg-accent hover:text-accent-foreground transition-colors ${
                          index === selectedIndex ? 'bg-accent text-accent-foreground' : ''
                        }`}
                        onClick={() => handleAutocompleteSelect(item)}
                        onMouseEnter={() => setSelectedIndex(index)}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono text-xs truncate">{item.display}</span>
                          <span className="text-xs text-muted-foreground shrink-0">
                            {item.type === 'positiveLaw' && 'Law'}
                            {item.type === 'interpretation' && 'Interp'}
                            {item.type === 'rdf' && 'RDF'}
                            {item.type === 'link' && 'Link'}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
                
                {showAutocomplete && autocompleteItems.length === 0 && searchQuery && (
                  <div className="absolute z-50 w-full mt-1 bg-popover border border-border rounded-md shadow-lg px-3 py-2">
                    <p className="text-xs text-muted-foreground">No matching items found</p>
                  </div>
                )}
                
                {validationError && (
                  <p className="text-xs text-destructive">{validationError}</p>
                )}
                {!validationError && tokenSequence.trim() && (
                  <p className="text-xs text-muted-foreground">
                    ✓ Valid token sequence detected
                  </p>
                )}
              </div>
            </>
          )}

          <div className="flex gap-2 justify-end pt-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)} 
              disabled={isPending}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isFormDisabled || (nodeType === NodeType.annotation && (!!validationError || hasInsufficientBuzz))}
            >
              {isPending ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                  Creating...
                </>
              ) : (
                getButtonText()
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
