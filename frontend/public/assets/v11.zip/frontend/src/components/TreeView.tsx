import { useMemo } from 'react';
import { useGetGraphData, useGetAllSwarmSummaries } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { NodeType, Node } from '../types';
import TreeNodeItem from './TreeNodeItem';
import { Alert, AlertDescription } from './ui/alert';
import { Skeleton } from './ui/skeleton';
import { AlertCircle, FolderPlus } from 'lucide-react';
import { Button } from './ui/button';

interface TreeViewProps {
  onCreateNode: (parentId?: bigint) => void;
}

export default function TreeView({ onCreateNode }: TreeViewProps) {
  const { data: graphData, isLoading, error } = useGetGraphData();
  const { data: allSwarmSummaries, isLoading: swarmSummariesLoading } = useGetAllSwarmSummaries();
  const { identity } = useInternetIdentity();

  // Build children map and compute swarm metrics with proper membership tracking
  const { childrenMap, swarmMemberCounts, userJoinedSwarms } = useMemo(() => {
    if (!graphData?.nodes || !allSwarmSummaries) {
      return {
        childrenMap: new Map<bigint, Node[]>(),
        swarmMemberCounts: new Map<bigint, number>(),
        userJoinedSwarms: new Set<bigint>(),
      };
    }

    const childrenMap = new Map<bigint, Node[]>();
    const swarmMemberCounts = new Map<bigint, number>();
    const userJoinedSwarms = new Set<bigint>();

    // Build children map - include ALL nodes with parentId
    graphData.nodes.forEach((node) => {
      if (node.parentId !== undefined) {
        const parentId = node.parentId;
        if (!childrenMap.has(parentId)) {
          childrenMap.set(parentId, []);
        }
        childrenMap.get(parentId)!.push(node);
      }
    });

    // Track swarm membership and member counts from backend-provided summaries
    allSwarmSummaries.forEach((swarm) => {
      swarmMemberCounts.set(swarm.id, Number(swarm.memberCount));
      if (swarm.isMember) {
        userJoinedSwarms.add(swarm.id);
      }
    });

    return { childrenMap, swarmMemberCounts, userJoinedSwarms };
  }, [graphData, allSwarmSummaries]);

  if (isLoading || swarmSummariesLoading) {
    return (
      <div className="container mx-auto p-6 space-y-4">
        <Skeleton className="h-12 w-64" />
        <Skeleton className="h-10 w-48 ml-6" />
        <Skeleton className="h-10 w-56 ml-12" />
        <Skeleton className="h-10 w-48 ml-6" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto p-6">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>Failed to load tree data: {error.message}</AlertDescription>
        </Alert>
      </div>
    );
  }

  // Get all nodes and filter root nodes
  const allNodes = graphData?.nodes || [];
  const rootNodes = allNodes.filter((node) => node.nodeType === NodeType.curation);

  // Only show empty state if data has loaded and there are no root nodes
  if (rootNodes.length === 0) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="rounded-full bg-muted p-6">
              <FolderPlus className="h-12 w-12 text-muted-foreground" />
            </div>
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-semibold">No Curations Yet</h3>
            <p className="text-sm text-muted-foreground max-w-sm">
              Get started by creating your first Curation to organize your knowledge.
            </p>
          </div>
          <Button onClick={() => onCreateNode()}>Create First Curation</Button>
        </div>
      </div>
    );
  }

  // Recursive function to get ALL descendants for a node (including tokens)
  const getAllDescendants = (nodeId: bigint): Node[] => {
    const directChildren = childrenMap.get(nodeId) || [];
    const allDescendants: Node[] = [...directChildren];
    
    // Recursively get descendants of each child
    directChildren.forEach(child => {
      const childDescendants = getAllDescendants(child.id);
      allDescendants.push(...childDescendants);
    });
    
    return allDescendants;
  };

  return (
    <div className="h-full overflow-auto">
      <div className="container mx-auto p-6 space-y-6">
        {/* Hierarchical tree structure */}
        <div className="space-y-2">
          {rootNodes.map((node) => (
            <TreeNodeItem
              key={node.id.toString()}
              node={node}
              children={getAllDescendants(node.id)}
              level={0}
              onNodeClick={onCreateNode}
              swarmMemberCounts={swarmMemberCounts}
              userJoinedSwarms={userJoinedSwarms}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
