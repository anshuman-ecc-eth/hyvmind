import type { Principal } from "@icp-sdk/core/principal";

export enum UserRole {
  admin = "admin",
  user = "user",
  guest = "guest"
}

export interface BuzzInterface {
  assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
  balanceOf(principal: Principal): Promise<bigint>;
  getCallerBalance(): Promise<bigint>;
  getCallerUserRole(): Promise<UserRole>;
  initialize(mainCanister: Principal, fleaMarketCanister: Principal): Promise<void>;
  initializeAccessControl(): Promise<void>;
  isCallerAdmin(): Promise<boolean>;
  mint(principal: Principal, amount: bigint): Promise<void>;
  transfer(from: Principal, to: Principal, amount: bigint): Promise<void>;
}
