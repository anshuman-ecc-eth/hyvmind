import type { Principal } from "@icp-sdk/core/principal";
import type { Time } from "./backend";

export enum UserRole {
  admin = "admin",
  user = "user",
  guest = "guest"
}

export interface PublishedRDF {
  id: bigint;
  creator: Principal;
  rdfId: bigint;
  tokenIds: Array<bigint>;
  price: bigint;
  published: boolean;
  buyer: Principal | null;
  createdAt: Time;
}

export interface FleaMarketInterface {
  assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
  getAllListings(): Promise<Array<PublishedRDF>>;
  getCallerUserRole(): Promise<UserRole>;
  getListing(listingId: bigint): Promise<PublishedRDF | null>;
  getListingsByCreator(creator: Principal): Promise<Array<PublishedRDF>>;
  initialize(mainCanister: Principal, buzzCanister: Principal): Promise<void>;
  initializeAccessControl(): Promise<void>;
  isCallerAdmin(): Promise<boolean>;
  publishRDF(rdfId: bigint, tokenIds: Array<bigint>, price: bigint): Promise<bigint>;
  purchaseRDF(listingId: bigint): Promise<void>;
}
