// Utility functions for BUZZ token formatting and validation

/**
 * Format BUZZ amount for display
 * @param buzz Amount in BUZZ as bigint
 * @param decimals Number of decimal places to show (default: 0)
 * @returns Formatted BUZZ string
 */
export function formatBuzz(buzz: bigint, decimals: number = 0): string {
  if (decimals === 0) {
    return buzz.toString();
  }
  // For decimal display, convert to number and format
  const buzzNum = Number(buzz);
  return buzzNum.toFixed(decimals);
}

/**
 * Parse BUZZ input string to bigint
 * @param buzzString String representation of BUZZ amount
 * @returns Amount in BUZZ as bigint
 */
export function parseBuzzInput(buzzString: string): bigint {
  const buzz = parseInt(buzzString, 10);
  if (isNaN(buzz)) {
    throw new Error('Invalid BUZZ amount');
  }
  return BigInt(buzz);
}

/**
 * Validate BUZZ input string
 * @param buzzString String representation of BUZZ amount
 * @returns true if valid, false otherwise
 */
export function isValidBuzzInput(buzzString: string): boolean {
  const buzz = parseInt(buzzString, 10);
  return !isNaN(buzz) && buzz >= 0;
}
