// Extended types for frontend use that complement the minimal backend interface
// These types represent the actual data structures returned by the backend

import type { Principal } from '@icp-sdk/core/principal';
import type { UserProfile as BackendUserProfile } from './backend';

// Re-export UserProfile from backend for convenience
export type UserProfile = BackendUserProfile;

// Basic type aliases
export type NodeId = bigint;
export type TokenId = bigint;
export type RelationId = bigint;

// Enums matching backend
export enum NodeType {
  curation = 'curation',
  swarm = 'swarm',
  annotation = 'annotation',
  token = 'token',
}

export enum RelationType {
  retrieval = 'retrieval',
  reasoning = 'reasoning',
}

export enum TokenType {
  positiveLaw = 'positiveLaw',
  interpretation = 'interpretation',
  link = 'link',
}

export enum VoteType {
  upvote = 'upvote',
  downvote = 'downvote',
}

export interface Node {
  id: NodeId;
  nodeType: NodeType;
  title: string;
  bracketedTokenSequence: string;
  parentId?: NodeId;
  createdAt: bigint;
  owner: Principal;
  swarmId?: NodeId;
  immutable: boolean;
  attributes: Array<[string, string]>;
  upvotes: bigint;
  downvotes: bigint;
  verified: boolean;
}

export interface Token {
  id: TokenId;
  name: string;
  tokenType: TokenType;
  creator: Principal;
  createdAt: bigint;
  buzzValue: bigint;
  reuseCount: bigint;
  relatedAnnotations: NodeId[];
  immutable: boolean;
}

export interface RDF {
  id: bigint;
  subject: string;
  predicate: string;
  rdfObject: string;
  creator: Principal;
  createdAt: bigint;
  cumulativeBuzz: bigint;
  originatingAnnotation: bigint;
}

export interface TokenStats {
  totalTokens: bigint;
  mostReusedTokens: Array<[string, bigint]>;
}

export interface Relation {
  id: bigint;
  sourceNodeId: NodeId;
  targetNodeId: NodeId;
  relationType: RelationType;
  relationStyle: RelationType;
  owner: Principal;
  createdAt: bigint;
}

export interface LinkRelation {
  id: bigint;
  sourceAnnotationId: bigint;
  targetAnnotationId: bigint;
  relationType: RelationType;
  relationName: string;
  creator: Principal;
  createdAt: bigint;
  linkTokenId: bigint;
}

// GraphData matches the backend interface exactly with includesRelations for hierarchical structure
export interface GraphData {
  nodes: Node[];
  tokens: Token[];
  relations: Array<[RelationId, Relation]>;
  links: LinkRelation[];
  includesRelations: Array<[RelationId, Relation]>;
}

export interface CreateNodeInput {
  title: string;
  bracketedTokenSequence: string;
  nodeType: NodeType;
  parentId?: NodeId;
}

export interface CreateNodeResult {
  success: boolean;
  nodeId?: NodeId;
}

export interface CreateAnnotationWithTokensInput {
  name: string;
  bracketedTokenSequence: string;
  parentSwarmId: NodeId;
  attributes: Array<[string, string]>;
}

export interface CreateRelationInput {
  sourceNodeId: NodeId;
  targetNodeId: NodeId;
  relationType: RelationType;
}

export interface RelationDefinition {
  name: string;
  description: string;
  usageCount: bigint;
  owner: Principal;
  createdAt: bigint;
}

export interface ComposeRDFInput {
  subjectId: bigint;
  predicate: string;
  objectId: bigint;
}

export interface PublishRDFInput {
  compositionId: bigint;
  instances: bigint;
  price: bigint;
}

export interface RDFComposition {
  id: bigint;
  subjectId: NodeId;
  predicate: string;
  objectId: NodeId;
  basePrice: bigint;
  createdAt: bigint;
  creator: Principal;
  level?: number;
}

export interface PublishedRDFListing {
  id: bigint;
  compositionId: bigint;
  creator: Principal;
  instances: bigint;
  price: bigint;
  createdAt: bigint;
  available: boolean;
}

export interface SwarmChatMessage {
  sender: Principal;
  timestamp: bigint;
  content: string;
}

export interface SwarmExtendedMetrics {
  id: NodeId;
  title: string;
  memberCount: bigint;
  annotationCount: bigint;
  totalBuzzEarned: bigint;
  activityStatus: string;
  buzzRegister: bigint;
  chat: SwarmChatMessage[];
}

export interface JoinRequest {
  requester: Principal;
  swarmId: bigint;
  timestamp: bigint;
  approvers: Principal[];
}

export interface JoinRequestStatus {
  requester: Principal;
  swarmId: bigint;
  timestamp: bigint;
  approvers: Principal[];
  totalMembers: bigint;
  approvalsNeeded: bigint;
  percentageApproved: bigint;
}

export interface SwarmSummary {
  id: bigint;
  title: string;
  memberCount: bigint;
  createdAt: bigint;
  creator: Principal;
  isMember: boolean;
}

export interface AutocompleteToken {
  name: string;
  buzzValue: bigint;
  relatedAnnotations: NodeId[];
}

export interface AutocompleteRDF {
  subject: string;
  predicate: string;
  rdfObject: string;
  originatingAnnotation: bigint;
}

export interface AutocompleteResults {
  positiveLawTokens: AutocompleteToken[];
  interpretationTokens: AutocompleteToken[];
  linkTokens: AutocompleteToken[];
  rdfs: AutocompleteRDF[];
}
