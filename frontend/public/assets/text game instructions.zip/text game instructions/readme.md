
Use the following instructions to navigate through the rest of the files in this folder and  generate the language game: 

- Always start with the "opening" file and read through it sequentially.
- While reading, follow this syntax:
	- '(M)' for messages 
	- '(P)' for available paths
	- '(S)' for sources
- Render all text after these symbols as is, with the following effects:
	- message: typed in effect with blinking cursor
	- path: navigable option buttons 
	- source: ascii box with text inside next to a monochrome book icon
	- question: ascii box with text inside next to a monochrome magnifying glass icon
- When you encounter a message, render it and wait for the user to continue.
- When you encounter a path, render active paths as buttons:
	- active: filename enclosed in double square brackets, e.g. [[path-file]]. 
		- once you encounter an active path file, read its contents to continue the game. 
	- inactive: filename not enclosed in double square brackets.
		- note that path's named "continue" should not be seen as inactive. 
		- when you encounter such a path, continue reading the rest of the file sequentially.
- End the game automatically when you:
	- are done traversing a file, or 
	- encounter an empty file. 


