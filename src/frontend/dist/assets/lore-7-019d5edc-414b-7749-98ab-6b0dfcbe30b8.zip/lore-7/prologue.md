- (AH) 989 days before the non-event, you were found dormant  
- (M) wake up
- (M) didn't you hear the siren?
	 - (P) [[not really]]
	 - (Q) [[what siren]]

 