https://government.economictimes.indiatimes.com/blog/redefining-digital-responsibility-a-new-era-for-indias-internet-users/129939182

