- (AH) 989 days before the non-event  
- (M) looks like you've been asleep a long time
- (M) did you hear the siren?
	 - (P) [[not really]]
	 - (Q) [[what siren]]

 